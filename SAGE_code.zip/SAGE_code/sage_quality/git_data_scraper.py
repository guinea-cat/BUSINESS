import os
import json
import time
import logging
import requests
from datetime import datetime
from typing import Dict, List, Optional, Union
from pathlib import Path
from dataclasses import dataclass
from urllib.parse import urlparse, urljoin
import aiohttp
import asyncio
from bs4 import BeautifulSoup

@dataclass
class GitHubData:
    repository: str
    data_type: str  # 'commits', 'issues', 'pull_requests', 'contributors', 'branches', 'tags'
    data: Union[List[Dict], Dict]
    scraped_at: datetime
    url: str

class GitDataScraper:
    def __init__(self, output_directory: str = "./research_data", 
                 delay_between_requests: int = 1,
                 max_retries: int = 3,
                 user_agent: str = "CodeQualityResearcher/1.0"):
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
        self.delay_between_requests = delay_between_requests
        self.max_retries = max_retries
        self.user_agent = user_agent
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # 设置请求会话
        token = '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'
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'token {token}',
            'User-Agent': user_agent,
            'Accept': 'application/vnd.github.v3+json'
        })
    
    def get_repository_info(self, repository_url: str) -> Dict:
        """
        获取仓库基本信息（包括star、fork数量等）
        
        Args:
            repository_url: 仓库URL
            
        Returns:
            Dict: 仓库基本信息
        """
        github_info = self.extract_github_info(repository_url)
        api_url = github_info['api_base']
        
        self.logger.info(f"开始获取仓库基本信息: {github_info['owner']}/{github_info['repo']}")
        
        try:
            response = self._make_request(api_url)
            if not response:
                return {}
            
            repo_data = response.json()
            
            repository_info = {
                'name': repo_data['name'],
                'full_name': repo_data['full_name'],
                'description': repo_data['description'],
                'html_url': repo_data['html_url'],
                'created_at': repo_data['created_at'],
                'updated_at': repo_data['updated_at'],
                'pushed_at': repo_data['pushed_at'],
                'size': repo_data['size'],
                'stargazers_count': repo_data['stargazers_count'],
                'watchers_count': repo_data['watchers_count'],
                'forks_count': repo_data['forks_count'],
                'open_issues_count': repo_data['open_issues_count'],
                'language': repo_data['language'],
                'default_branch': repo_data['default_branch'],
                'license': repo_data['license']['name'] if repo_data['license'] else None,
                'topics': repo_data['topics'],
                'archived': repo_data['archived'],
                'disabled': repo_data['disabled'],
                'visibility': repo_data['visibility'],
                'owner': {
                    'login': repo_data['owner']['login'],
                    'type': repo_data['owner']['type'],
                    'avatar_url': repo_data['owner']['avatar_url']
                }
            }
            
            self.logger.info(f"仓库基本信息获取成功:")
            self.logger.info(f"  - Stars: {repository_info['stargazers_count']}")
            self.logger.info(f"  - Forks: {repository_info['forks_count']}")
            self.logger.info(f"  - Open Issues: {repository_info['open_issues_count']}")
            self.logger.info(f"  - Language: {repository_info['language']}")
            
            return repository_info
            
        except Exception as e:
            self.logger.error(f"获取仓库基本信息失败: {str(e)}")
            return {}

    def extract_github_info(self, repository_url: str) -> Dict:
        """
        从GitHub URL提取仓库信息
        
        Args:
            repository_url: GitHub仓库URL
            
        Returns:
            Dict: 包含owner和repo的信息
        """
        parsed_url = urlparse(repository_url)
        path_parts = parsed_url.path.strip('/').split('/')
        
        if len(path_parts) >= 2:
            return {
                'owner': path_parts[0],
                'repo': path_parts[1].replace('.git', ''),
                'api_base': f"https://api.github.com/repos/{path_parts[0]}/{path_parts[1].replace('.git', '')}"
            }
        else:
            raise ValueError(f"无效的GitHub URL: {repository_url}")
    
    def scrape_commits(self, repository_url: str, max_commits: int = 100) -> GitHubData:
        """
        抓取提交历史
        
        Args:
            repository_url: 仓库URL
            max_commits: 最大提交数量
            
        Returns:
            GitHubData: 提交数据
        """
        github_info = self.extract_github_info(repository_url)
        api_url = f"{github_info['api_base']}/commits"
        
        self.logger.info(f"开始抓取提交历史: {github_info['owner']}/{github_info['repo']}")
        
        commits = []
        page = 1
        per_page = min(100, max_commits)
        
        try:
            while len(commits) < max_commits:
                params = {
                    'page': page,
                    'per_page': per_page
                }
                
                response = self._make_request(api_url, params=params)
                if not response:
                    break
                
                page_commits = response.json()
                if not page_commits:
                    break
                
                for commit in page_commits:
                    if len(commits) >= max_commits:
                        break
                    
                    commit_data = {
                        'sha': commit['sha'],
                        'message': commit['commit']['message'],
                        'author': {
                            'name': commit['commit']['author']['name'],
                            'email': commit['commit']['author']['email'],
                            'date': commit['commit']['author']['date']
                        },
                        'committer': {
                            'name': commit['commit']['committer']['name'],
                            'email': commit['commit']['committer']['email'],
                            'date': commit['commit']['committer']['date']
                        },
                        'url': commit['html_url'],
                        'stats': {
                            'additions': 0,
                            'deletions': 0,
                            'total': 0
                        }
                    }
                    
                    # 获取详细的统计信息
                    detail_url = f"{github_info['api_base']}/commits/{commit['sha']}"
                    detail_response = self._make_request(detail_url)
                    if detail_response:
                        detail_data = detail_response.json()
                        if 'stats' in detail_data:
                            commit_data['stats'] = detail_data['stats']
                    
                    commits.append(commit_data)
                
                page += 1
                time.sleep(self.delay_between_requests)
            
            self.logger.info(f"成功抓取 {len(commits)} 条提交记录")
            
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='commits',
                data=commits,
                scraped_at=datetime.now(),
                url=api_url
            )
            
        except Exception as e:
            self.logger.error(f"抓取提交历史失败: {str(e)}")
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='commits',
                data=[],
                scraped_at=datetime.now(),
                url=api_url
            )
    
    def scrape_issues(self, repository_url: str, max_issues: int = 100) -> GitHubData:
        """
        抓取Issues
        
        Args:
            repository_url: 仓库URL
            max_issues: 最大Issue数量
            
        Returns:
            GitHubData: Issue数据
        """
        github_info = self.extract_github_info(repository_url)
        api_url = f"{github_info['api_base']}/issues"
        
        self.logger.info(f"开始抓取Issues: {github_info['owner']}/{github_info['repo']}")
        
        issues = []
        page = 1
        per_page = min(100, max_issues)
        
        try:
            while len(issues) < max_issues:
                params = {
                    'page': page,
                    'per_page': per_page,
                    'state': 'all',  # 获取所有状态的issues
                    'sort': 'created',
                    'direction': 'desc'
                }
                
                response = self._make_request(api_url, params=params)
                if not response:
                    break
                
                page_issues = response.json()
                if not page_issues:
                    break
                
                for issue in page_issues:
                    if len(issues) >= max_issues:
                        break
                    
                    # 跳过pull requests（GitHub的API中PR也作为issue返回）
                    if 'pull_request' in issue:
                        continue
                    
                    issue_data = {
                        'number': issue['number'],
                        'title': issue['title'],
                        'body': issue['body'] or '',
                        'state': issue['state'],
                        'created_at': issue['created_at'],
                        'updated_at': issue['updated_at'],
                        'closed_at': issue['closed_at'],
                        'author': {
                            'login': issue['user']['login'],
                            'id': issue['user']['id']
                        },
                        'labels': [label['name'] for label in issue['labels']],
                        'comments': issue['comments'],
                        'html_url': issue['html_url']
                    }
                    
                    issues.append(issue_data)
                
                page += 1
                time.sleep(self.delay_between_requests)
            
            self.logger.info(f"成功抓取 {len(issues)} 条Issue记录")
            
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='issues',
                data=issues,
                scraped_at=datetime.now(),
                url=api_url
            )
            
        except Exception as e:
            self.logger.error(f"抓取Issues失败: {str(e)}")
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='issues',
                data=[],
                scraped_at=datetime.now(),
                url=api_url
            )
    
    def scrape_pull_requests(self, repository_url: str, max_prs: int = 100) -> GitHubData:
        """
        抓取Pull Requests
        
        Args:
            repository_url: 仓库URL
            max_prs: 最大PR数量
            
        Returns:
            GitHubData: PR数据
        """
        github_info = self.extract_github_info(repository_url)
        api_url = f"{github_info['api_base']}/pulls"
        
        self.logger.info(f"开始抓取Pull Requests: {github_info['owner']}/{github_info['repo']}")
        
        pull_requests = []
        page = 1
        per_page = min(100, max_prs)
        
        try:
            while len(pull_requests) < max_prs:
                params = {
                    'page': page,
                    'per_page': per_page,
                    'state': 'all',  # 获取所有状态的PRs
                    'sort': 'created',
                    'direction': 'desc'
                }
                
                response = self._make_request(api_url, params=params)
                if not response:
                    break
                
                page_prs = response.json()
                if not page_prs:
                    break
                
                for pr in page_prs:
                    if len(pull_requests) >= max_prs:
                        break
                    
                    pr_data = {
                        'number': pr['number'],
                        'title': pr['title'],
                        'body': pr['body'] or '',
                        'state': pr['state'],
                        'created_at': pr['created_at'],
                        'updated_at': pr['updated_at'],
                        'closed_at': pr['closed_at'],
                        'merged_at': pr['merged_at'],
                        'author': {
                            'login': pr['user']['login'],
                            'id': pr['user']['id']
                        },
                        'head': {
                            'ref': pr['head']['ref'],
                            'sha': pr['head']['sha']
                        },
                        'base': {
                            'ref': pr['base']['ref'],
                            'sha': pr['base']['sha']
                        },
                        'mergeable': pr['mergeable'],
                        'merged': pr['merged'],
                        'comments': pr['comments'],
                        'review_comments': pr['review_comments'],
                        'commits': pr['commits'],
                        'additions': pr['additions'],
                        'deletions': pr['deletions'],
                        'changed_files': pr['changed_files'],
                        'html_url': pr['html_url']
                    }
                    
                    pull_requests.append(pr_data)
                
                page += 1
                time.sleep(self.delay_between_requests)
            
            self.logger.info(f"成功抓取 {len(pull_requests)} 条Pull Request记录")
            
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='pull_requests',
                data=pull_requests,
                scraped_at=datetime.now(),
                url=api_url
            )
            
        except Exception as e:
            self.logger.error(f"抓取Pull Requests失败: {str(e)}")
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='pull_requests',
                data=[],
                scraped_at=datetime.now(),
                url=api_url
            )
    
    def scrape_contributors(self, repository_url: str) -> GitHubData:
        """
        抓取贡献者信息
        
        Args:
            repository_url: 仓库URL
            
        Returns:
            GitHubData: 贡献者数据
        """
        github_info = self.extract_github_info(repository_url)
        api_url = f"{github_info['api_base']}/contributors"
        
        self.logger.info(f"开始抓取贡献者: {github_info['owner']}/{github_info['repo']}")
        
        try:
            contributors = []
            page = 1
            per_page = 100
            
            while True:
                params = {
                    'page': page,
                    'per_page': per_page
                }
                
                response = self._make_request(api_url, params=params)
                if not response:
                    break
                
                page_contributors = response.json()
                if not page_contributors:
                    break
                
                for contributor in page_contributors:
                    contributor_data = {
                        'login': contributor['login'],
                        'id': contributor['id'],
                        'contributions': contributor['contributions'],
                        'avatar_url': contributor['avatar_url'],
                        'html_url': contributor['html_url'],
                        'type': contributor['type']
                    }
                    contributors.append(contributor_data)
                
                page += 1
                time.sleep(self.delay_between_requests)
            
            self.logger.info(f"成功抓取 {len(contributors)} 个贡献者")
            
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='contributors',
                data=contributors,
                scraped_at=datetime.now(),
                url=api_url
            )
            
        except Exception as e:
            self.logger.error(f"抓取贡献者失败: {str(e)}")
            return GitHubData(
                repository=f"{github_info['owner']}/{github_info['repo']}",
                data_type='contributors',
                data=[],
                scraped_at=datetime.now(),
                url=api_url
            )
    
    def _make_request(self, url: str, params: Optional[Dict] = None) -> Optional[requests.Response]:
        """
        发送HTTP请求
        
        Args:
            url: 请求URL
            params: 请求参数
            
        Returns:
            Optional[requests.Response]: 响应对象或None
        """
        for attempt in range(self.max_retries):
            try:
                response = self.session.get(url, params=params, timeout=30)
                
                if response.status_code == 200:
                    return response
                elif response.status_code == 403:
                    self.logger.warning(f"请求被限制 (403)，等待后重试...")
                    time.sleep(self.delay_between_requests * (attempt + 1))
                else:
                    self.logger.warning(f"请求失败，状态码: {response.status_code}")
                    
            except Exception as e:
                self.logger.warning(f"请求异常 (尝试 {attempt + 1}/{self.max_retries}): {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.delay_between_requests * (attempt + 1))
        
        self.logger.error(f"请求失败，已达到最大重试次数: {url}")
        return None
    
    def save_data(self, data: GitHubData, filename: Optional[str] = None):
        """
        保存抓取的数据到文件（使用固定文件名，不包含时间戳）
        
        Args:
            data: GitHub数据
            filename: 文件名，如果为None则自动生成（不包含时间戳）
        """
        if not filename:
            # 移除时间戳，使用固定文件名
            filename = f"{data.repository.replace('/', '_')}_{data.data_type}.json"
        
        file_path = self.output_directory / filename
        
        try:
            output_data = {
                'repository': data.repository,
                'data_type': data.data_type,
                'scraped_at': data.scraped_at.isoformat(),
                'url': data.url,
                'data_count': len(data.data) if isinstance(data.data, list) else 1,
                'data': data.data
            }
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"数据已保存到: {file_path}")
            
        except Exception as e:
            self.logger.error(f"保存数据失败: {str(e)}")
    
    def scrape_all_data(self, repository_url: str, config: Dict) -> Dict[str, GitHubData]:
        """
        抓取所有配置的Git数据
        
        Args:
            repository_url: 仓库URL
            config: 配置字典
            
        Returns:
            Dict[str, GitHubData]: 抓取的数据字典
        """
        results = {}
        
        if config.get('commits', True):
            results['commits'] = self.scrape_commits(repository_url)
            self.save_data(results['commits'])
        
        if config.get('issues', True):
            results['issues'] = self.scrape_issues(repository_url)
            self.save_data(results['issues'])
        
        if config.get('pull_requests', True):
            results['pull_requests'] = self.scrape_pull_requests(repository_url)
            self.save_data(results['pull_requests'])
        
        if config.get('contributors', True):
            results['contributors'] = self.scrape_contributors(repository_url)
            self.save_data(results['contributors'])
        
        return results

if __name__ == "__main__":
    # 测试Git数据抓取器
    scraper = GitDataScraper()
    
    # 测试仓库URL
    test_repo_url = "https://github.com/gitpython-developers/GitPython.git"
    
    print("开始测试Git数据抓取功能...")
    
    # 抓取所有数据
    config = {
        'commits': True,
        'issues': True,
        'pull_requests': True,
        'contributors': True
    }
    
    results = scraper.scrape_all_data(test_repo_url, config)
    
    for data_type, data in results.items():
        print(f"\n{data_type}:")
        print(f"  数据条数: {len(data.data) if isinstance(data.data, list) else 1}")
        print(f"  抓取时间: {data.scraped_at}")
        
        # 显示部分数据示例
        if isinstance(data.data, list) and data.data:
            print(f"  示例数据: {data.data[0] if data.data else '无'}")

