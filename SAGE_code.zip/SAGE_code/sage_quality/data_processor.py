"""
数据处理模块
用于分析、统计和聚合预处理后的Git数据
"""

import json
import logging
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict


@dataclass
class ProcessingStats:
    """处理统计信息"""
    total_records: int
    processed_records: int
    analysis_time: float
    generated_metrics: int


class DataProcessor:
    """数据处理器"""
    
    def __init__(self, output_directory: str = "./results/research_data/analyzed"):
        """
        初始化数据处理器
        
        Args:
            output_directory: 处理后数据的输出目录
        """
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def process_commits(self, commits_data: List[Dict]) -> Dict[str, Any]:
        """
        处理提交数据，生成统计和分析结果
        
        Args:
            commits_data: 预处理后的提交数据列表
            
        Returns:
            Dict: 处理后的分析结果
        """
        self.logger.info(f"开始处理提交数据，共 {len(commits_data)} 条记录")
        
        start_time = datetime.now()
        
        # 基础统计
        total_commits = len(commits_data)
        total_additions = sum(c.get('stats', {}).get('additions', 0) for c in commits_data)
        total_deletions = sum(c.get('stats', {}).get('deletions', 0) for c in commits_data)
        total_changes = sum(c.get('stats', {}).get('total', 0) for c in commits_data)
        
        # 时间分析
        time_analysis = self._analyze_commit_timeline(commits_data)
        
        # 作者分析
        author_analysis = self._analyze_commit_authors(commits_data)
        
        # 提交消息分析
        message_analysis = self._analyze_commit_messages(commits_data)
        
        # 变更规模分析
        change_analysis = self._analyze_commit_changes(commits_data)
        
        # 活跃度分析
        activity_analysis = self._analyze_commit_activity(commits_data)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        result = {
            'summary': {
                'total_commits': total_commits,
                'total_additions': total_additions,
                'total_deletions': total_deletions,
                'total_changes': total_changes,
                'avg_changes_per_commit': total_changes / total_commits if total_commits > 0 else 0,
                'net_changes': total_additions - total_deletions
            },
            'time_analysis': time_analysis,
            'author_analysis': author_analysis,
            'message_analysis': message_analysis,
            'change_analysis': change_analysis,
            'activity_analysis': activity_analysis,
            'processing_stats': {
                'total_records': total_commits,
                'processed_records': total_commits,
                'analysis_time': processing_time,
                'generated_metrics': 5
            }
        }
        
        self.logger.info(f"提交数据处理完成，耗时 {processing_time:.2f} 秒")
        
        return result
    
    def process_issues(self, issues_data: List[Dict]) -> Dict[str, Any]:
        """
        处理Issues数据，生成统计和分析结果
        
        Args:
            issues_data: 预处理后的Issues数据列表
            
        Returns:
            Dict: 处理后的分析结果
        """
        self.logger.info(f"开始处理Issues数据，共 {len(issues_data)} 条记录")
        
        start_time = datetime.now()
        
        # 基础统计
        total_issues = len(issues_data)
        open_issues = sum(1 for i in issues_data if i.get('state') == 'open')
        closed_issues = sum(1 for i in issues_data if i.get('state') == 'closed')
        
        # 状态分析
        state_analysis = self._analyze_issue_states(issues_data)
        
        # 时间分析
        time_analysis = self._analyze_issue_timeline(issues_data)
        
        # 作者分析
        author_analysis = self._analyze_issue_authors(issues_data)
        
        # 标签分析
        label_analysis = self._analyze_issue_labels(issues_data)
        
        # 持续时间分析
        duration_analysis = self._analyze_issue_durations(issues_data)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        result = {
            'summary': {
                'total_issues': total_issues,
                'open_issues': open_issues,
                'closed_issues': closed_issues,
                'closure_rate': closed_issues / total_issues if total_issues > 0 else 0,
                'avg_comments_per_issue': sum(i.get('comments', 0) for i in issues_data) / total_issues if total_issues > 0 else 0
            },
            'state_analysis': state_analysis,
            'time_analysis': time_analysis,
            'author_analysis': author_analysis,
            'label_analysis': label_analysis,
            'duration_analysis': duration_analysis,
            'processing_stats': {
                'total_records': total_issues,
                'processed_records': total_issues,
                'analysis_time': processing_time,
                'generated_metrics': 5
            }
        }
        
        self.logger.info(f"Issues数据处理完成，耗时 {processing_time:.2f} 秒")
        
        return result
    
    def process_pull_requests(self, prs_data: List[Dict]) -> Dict[str, Any]:
        """
        处理Pull Requests数据，生成统计和分析结果
        
        Args:
            prs_data: 预处理后的PR数据列表
            
        Returns:
            Dict: 处理后的分析结果
        """
        self.logger.info(f"开始处理Pull Requests数据，共 {len(prs_data)} 条记录")
        
        start_time = datetime.now()
        
        # 基础统计
        total_prs = len(prs_data)
        open_prs = sum(1 for pr in prs_data if pr.get('state') == 'open')
        closed_prs = sum(1 for pr in prs_data if pr.get('state') == 'closed')
        merged_prs = sum(1 for pr in prs_data if pr.get('merged', False))
        
        # 状态分析
        state_analysis = self._analyze_pr_states(prs_data)
        
        # 时间分析
        time_analysis = self._analyze_pr_timeline(prs_data)
        
        # 作者分析
        author_analysis = self._analyze_pr_authors(prs_data)
        
        # 代码变更分析
        change_analysis = self._analyze_pr_changes(prs_data)
        
        # 合并分析
        merge_analysis = self._analyze_pr_merges(prs_data)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        result = {
            'summary': {
                'total_prs': total_prs,
                'open_prs': open_prs,
                'closed_prs': closed_prs,
                'merged_prs': merged_prs,
                'merge_rate': merged_prs / total_prs if total_prs > 0 else 0,
                'avg_changes_per_pr': (
                    sum(pr.get('stats', {}).get('changed_files', 0) for pr in prs_data) / total_prs
                    if total_prs > 0 else 0
                )
            },
            'state_analysis': state_analysis,
            'time_analysis': time_analysis,
            'author_analysis': author_analysis,
            'change_analysis': change_analysis,
            'merge_analysis': merge_analysis,
            'processing_stats': {
                'total_records': total_prs,
                'processed_records': total_prs,
                'analysis_time': processing_time,
                'generated_metrics': 5
            }
        }
        
        self.logger.info(f"Pull Requests数据处理完成，耗时 {processing_time:.2f} 秒")
        
        return result
    
    def process_contributors(self, contributors_data: List[Dict]) -> Dict[str, Any]:
        """
        处理贡献者数据，生成统计和分析结果
        
        Args:
            contributors_data: 预处理后的贡献者数据列表
            
        Returns:
            Dict: 处理后的分析结果
        """
        self.logger.info(f"开始处理贡献者数据，共 {len(contributors_data)} 条记录")
        
        start_time = datetime.now()
        
        # 基础统计
        total_contributors = len(contributors_data)
        total_contributions = sum(c.get('contributions', 0) for c in contributors_data)
        
        # 贡献分布分析
        contribution_distribution = self._analyze_contribution_distribution(contributors_data)
        
        # 贡献者等级分析
        level_analysis = self._analyze_contributor_levels(contributors_data)
        
        # Top贡献者
        top_contributors = self._get_top_contributors(contributors_data)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        result = {
            'summary': {
                'total_contributors': total_contributors,
                'total_contributions': total_contributions,
                'avg_contributions_per_contributor': total_contributions / total_contributors if total_contributors > 0 else 0
            },
            'contribution_distribution': contribution_distribution,
            'level_analysis': level_analysis,
            'top_contributors': top_contributors,
            'processing_stats': {
                'total_records': total_contributors,
                'processed_records': total_contributors,
                'analysis_time': processing_time,
                'generated_metrics': 3
            }
        }
        
        self.logger.info(f"贡献者数据处理完成，耗时 {processing_time:.2f} 秒")
        
        return result
    
    def _analyze_commit_timeline(self, commits: List[Dict]) -> Dict:
        """分析提交时间线"""
        dates = []
        for commit in commits:
            date_str = commit.get('date')
            if date_str:
                try:
                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                    dates.append(dt)
                except:
                    pass
        
        if not dates:
            return {}
        
        dates.sort()
        
        return {
            'first_commit': dates[0].isoformat() if dates else None,
            'last_commit': dates[-1].isoformat() if dates else None,
            'commit_span_days': (dates[-1] - dates[0]).days if len(dates) > 1 else 0,
            'commits_per_day': len(commits) / max((dates[-1] - dates[0]).days, 1) if len(dates) > 1 else len(commits),
            'commits_by_month': self._group_by_month(dates),
            'commits_by_weekday': self._group_by_weekday(dates)
        }
    
    def _analyze_commit_authors(self, commits: List[Dict]) -> Dict:
        """分析提交作者"""
        authors = Counter()
        author_commits = defaultdict(list)
        
        for commit in commits:
            author_name = commit.get('author', {}).get('name', 'Unknown')
            authors[author_name] += 1
            author_commits[author_name].append(commit)
        
        top_authors = authors.most_common(10)
        
        return {
            'total_unique_authors': len(authors),
            'top_authors': [
                {
                    'name': name,
                    'commit_count': count,
                    'percentage': count / len(commits) * 100 if commits else 0
                }
                for name, count in top_authors
            ],
            'author_distribution': dict(authors)
        }
    
    def _analyze_commit_messages(self, commits: List[Dict]) -> Dict:
        """分析提交消息"""
        messages = [c.get('message', '') for c in commits]
        message_lengths = [len(m) for m in messages]
        
        # 常见关键词
        keywords = Counter()
        for message in messages:
            words = message.lower().split()
            for word in words:
                if len(word) > 3:
                    keywords[word] += 1
        
        return {
            'avg_message_length': sum(message_lengths) / len(message_lengths) if message_lengths else 0,
            'max_message_length': max(message_lengths) if message_lengths else 0,
            'min_message_length': min(message_lengths) if message_lengths else 0,
            'top_keywords': dict(keywords.most_common(20))
        }
    
    def _analyze_commit_changes(self, commits: List[Dict]) -> Dict:
        """分析提交变更"""
        additions = [c.get('stats', {}).get('additions', 0) for c in commits]
        deletions = [c.get('stats', {}).get('deletions', 0) for c in commits]
        totals = [c.get('stats', {}).get('total', 0) for c in commits]
        
        return {
            'avg_additions': sum(additions) / len(additions) if additions else 0,
            'avg_deletions': sum(deletions) / len(deletions) if deletions else 0,
            'avg_total_changes': sum(totals) / len(totals) if totals else 0,
            'max_additions': max(additions) if additions else 0,
            'max_deletions': max(deletions) if deletions else 0,
            'large_commits': sum(1 for t in totals if t > 1000)
        }
    
    def _analyze_commit_activity(self, commits: List[Dict]) -> Dict:
        """分析提交活跃度"""
        dates = []
        for commit in commits:
            date_str = commit.get('date')
            if date_str:
                try:
                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                    dates.append(dt)
                except:
                    pass
        
        if not dates:
            return {}
        
        # 按小时分组
        hourly_activity = defaultdict(int)
        for dt in dates:
            hourly_activity[dt.hour] += 1
        
        return {
            'hourly_distribution': dict(hourly_activity),
            'most_active_hour': max(hourly_activity.items(), key=lambda x: x[1])[0] if hourly_activity else None
        }
    
    def _analyze_issue_states(self, issues: List[Dict]) -> Dict:
        """分析Issue状态"""
        states = Counter(i.get('state', 'unknown') for i in issues)
        
        return {
            'state_distribution': dict(states),
            'open_rate': states.get('open', 0) / len(issues) if issues else 0,
            'closed_rate': states.get('closed', 0) / len(issues) if issues else 0
        }
    
    def _analyze_issue_timeline(self, issues: List[Dict]) -> Dict:
        """分析Issue时间线"""
        created_dates = []
        for issue in issues:
            date_str = issue.get('created_at')
            if date_str:
                try:
                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                    created_dates.append(dt)
                except:
                    pass
        
        if not created_dates:
            return {}
        
        created_dates.sort()
        
        return {
            'first_issue': created_dates[0].isoformat() if created_dates else None,
            'last_issue': created_dates[-1].isoformat() if created_dates else None,
            'issues_by_month': self._group_by_month(created_dates)
        }
    
    def _analyze_issue_authors(self, issues: List[Dict]) -> Dict:
        """分析Issue作者"""
        authors = Counter(i.get('author', {}).get('login', 'Unknown') for i in issues)
        
        return {
            'total_unique_authors': len(authors),
            'top_authors': [
                {'login': login, 'issue_count': count}
                for login, count in authors.most_common(10)
            ]
        }
    
    def _analyze_issue_labels(self, issues: List[Dict]) -> Dict:
        """分析Issue标签"""
        all_labels = []
        for issue in issues:
            all_labels.extend(issue.get('labels', []))
        
        label_counts = Counter(all_labels)
        
        return {
            'total_unique_labels': len(label_counts),
            'top_labels': [
                {'label': label, 'count': count}
                for label, count in label_counts.most_common(20)
            ],
            'avg_labels_per_issue': len(all_labels) / len(issues) if issues else 0
        }
    
    def _analyze_issue_durations(self, issues: List[Dict]) -> Dict:
        """分析Issue持续时间"""
        durations = [i.get('duration_days') for i in issues if i.get('duration_days') is not None]
        
        if not durations:
            return {}
        
        return {
            'avg_duration_days': sum(durations) / len(durations),
            'median_duration_days': sorted(durations)[len(durations) // 2] if durations else 0,
            'min_duration_days': min(durations),
            'max_duration_days': max(durations)
        }
    
    def _analyze_pr_states(self, prs: List[Dict]) -> Dict:
        """分析PR状态"""
        states = Counter(pr.get('state', 'unknown') for pr in prs)
        merged_count = sum(1 for pr in prs if pr.get('merged', False))
        
        return {
            'state_distribution': dict(states),
            'merged_count': merged_count,
            'merge_rate': merged_count / len(prs) if prs else 0
        }
    
    def _analyze_pr_timeline(self, prs: List[Dict]) -> Dict:
        """分析PR时间线"""
        created_dates = []
        for pr in prs:
            date_str = pr.get('created_at')
            if date_str:
                try:
                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                    created_dates.append(dt)
                except:
                    pass
        
        if not created_dates:
            return {}
        
        created_dates.sort()
        
        return {
            'first_pr': created_dates[0].isoformat() if created_dates else None,
            'last_pr': created_dates[-1].isoformat() if created_dates else None,
            'prs_by_month': self._group_by_month(created_dates)
        }
    
    def _analyze_pr_authors(self, prs: List[Dict]) -> Dict:
        """分析PR作者"""
        authors = Counter(pr.get('author', {}).get('login', 'Unknown') for pr in prs)
        
        return {
            'total_unique_authors': len(authors),
            'top_authors': [
                {'login': login, 'pr_count': count}
                for login, count in authors.most_common(10)
            ]
        }
    
    def _analyze_pr_changes(self, prs: List[Dict]) -> Dict:
        """分析PR代码变更"""
        additions = []
        deletions = []
        changed_files = []
        
        for pr in prs:
            stats = pr.get('stats', {})
            additions.append(stats.get('additions', 0))
            deletions.append(stats.get('deletions', 0))
            changed_files.append(stats.get('changed_files', 0))
        
        return {
            'avg_additions': sum(additions) / len(additions) if additions else 0,
            'avg_deletions': sum(deletions) / len(deletions) if deletions else 0,
            'avg_changed_files': sum(changed_files) / len(changed_files) if changed_files else 0,
            'total_additions': sum(additions),
            'total_deletions': sum(deletions)
        }
    
    def _analyze_pr_merges(self, prs: List[Dict]) -> Dict:
        """分析PR合并情况"""
        merged_prs = [pr for pr in prs if pr.get('merged', False)]
        durations = [pr.get('duration_days') for pr in merged_prs if pr.get('duration_days') is not None]
        
        return {
            'merged_count': len(merged_prs),
            'avg_merge_duration_days': sum(durations) / len(durations) if durations else 0,
            'merge_rate': len(merged_prs) / len(prs) if prs else 0
        }
    
    def _analyze_contribution_distribution(self, contributors: List[Dict]) -> Dict:
        """分析贡献分布"""
        contributions = [c.get('contributions', 0) for c in contributors]
        
        if not contributions:
            return {}
        
        contributions.sort(reverse=True)
        
        return {
            'total_contributions': sum(contributions),
            'max_contributions': max(contributions),
            'min_contributions': min(contributions),
            'median_contributions': contributions[len(contributions) // 2],
            'top_10_percent_contribution': sum(contributions[:len(contributions)//10]) if contributions else 0
        }
    
    def _analyze_contributor_levels(self, contributors: List[Dict]) -> Dict:
        """分析贡献者等级"""
        levels = Counter(c.get('contribution_level', 'unknown') for c in contributors)
        
        return {
            'level_distribution': dict(levels),
            'high_contributors': levels.get('high', 0),
            'medium_contributors': levels.get('medium', 0),
            'low_contributors': levels.get('low', 0)
        }
    
    def _get_top_contributors(self, contributors: List[Dict], top_n: int = 10) -> List[Dict]:
        """获取Top贡献者"""
        sorted_contributors = sorted(
            contributors,
            key=lambda x: x.get('contributions', 0),
            reverse=True
        )
        
        return [
            {
                'login': c.get('login'),
                'contributions': c.get('contributions', 0),
                'level': c.get('contribution_level', 'unknown')
            }
            for c in sorted_contributors[:top_n]
        ]
    
    def _group_by_month(self, dates: List[datetime]) -> Dict[str, int]:
        """按月份分组"""
        monthly = defaultdict(int)
        for dt in dates:
            key = dt.strftime('%Y-%m')
            monthly[key] += 1
        return dict(monthly)
    
    def _group_by_weekday(self, dates: List[datetime]) -> Dict[str, int]:
        """按星期分组"""
        weekday_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        weekday_counts = defaultdict(int)
        for dt in dates:
            weekday_counts[weekday_names[dt.weekday()]] += 1
        return dict(weekday_counts)
    
    def save_analysis_result(self, analysis_result: Dict, filename: Optional[str] = None):
        """
        保存分析结果
        
        Args:
            analysis_result: 分析结果
            filename: 文件名，如果为None则自动生成
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"analysis_result_{timestamp}.json"
        
        file_path = self.output_directory / filename
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(analysis_result, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"分析结果已保存到: {file_path}")
            
        except Exception as e:
            self.logger.error(f"保存分析结果失败: {str(e)}")
    
    def load_and_process(self, input_file: Union[str, Path]) -> Dict[str, Any]:
        """
        加载预处理后的数据并进行处理
        
        Args:
            input_file: 输入文件路径
            
        Returns:
            Dict: 处理后的分析结果
        """
        self.logger.info(f"加载并处理数据文件: {input_file}")
        
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                processed_data = json.load(f)
            
            # 确定数据类型
            data_type = processed_data.get('data_type', '')
            data = processed_data.get('data', [])
            
            # 根据数据类型进行处理
            if data_type == 'commits':
                return self.process_commits(data)
            elif data_type == 'issues':
                return self.process_issues(data)
            elif data_type == 'pull_requests':
                return self.process_pull_requests(data)
            elif data_type == 'contributors':
                return self.process_contributors(data)
            else:
                self.logger.warning(f"未知的数据类型: {data_type}")
                return {'error': f'Unknown data type: {data_type}'}
                
        except Exception as e:
            self.logger.error(f"加载和处理数据失败: {str(e)}")
            raise


if __name__ == "__main__":
    # 测试数据处理器
    processor = DataProcessor()
    
    # 示例：处理提交数据
    sample_commits = [
        {
            'sha': 'abc123',
            'message': 'Fix bug',
            'author': {'name': 'John', 'email': 'john@example.com'},
            'date': '2024-01-01T00:00:00Z',
            'stats': {'additions': 10, 'deletions': 5, 'total': 15}
        }
    ]
    
    result = processor.process_commits(sample_commits)
    print(f"处理结果摘要: {result['summary']}")

