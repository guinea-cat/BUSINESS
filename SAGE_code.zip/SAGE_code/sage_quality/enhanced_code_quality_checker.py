"""
增强的代码质量检查器
基于demand.md中的要求，实现全面的代码质量评估
"""

import os
import re
import ast
import json
import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from datetime import datetime
from collections import Counter, defaultdict


@dataclass
class StaticAnalysisMetrics:
    """静态分析指标"""
    lint_issues: List[Dict[str, Any]]
    avg_cyclomatic_complexity: float
    max_cyclomatic_complexity: int
    high_complexity_functions: List[Dict[str, Any]]
    code_duplication_rate: float
    duplicate_blocks: List[Dict[str, Any]]


@dataclass
class TestingMetrics:
    """测试指标"""
    test_coverage: float
    test_files_count: int
    test_functions_count: int
    test_pass_rate: float
    uncovered_lines: List[Dict[str, Any]]


@dataclass
class CodeReviewMetrics:
    """代码评审指标"""
    design_patterns: List[str]
    readability_score: float
    naming_quality_score: float
    security_issues: List[Dict[str, Any]]
    code_smells: List[Dict[str, Any]]


@dataclass
class ArchitectureMetrics:
    """架构评估指标"""
    coupling_score: float
    cohesion_score: float
    layer_separation_score: float
    dependency_health: float
    outdated_dependencies: List[str]
    vulnerable_dependencies: List[str]


@dataclass
class ISO25010Metrics:
    """ISO/IEC 25010 质量模型指标"""
    functional_suitability: float
    performance_efficiency: float
    compatibility: float
    usability: float
    reliability: float
    security: float
    maintainability: float
    portability: float


@dataclass
class SonarQubeMetrics:
    """SonarQube质量门禁指标"""
    reliability_rating: str  # A-E
    security_rating: str  # A-E
    maintainability_rating: str  # A-E
    bugs_count: int
    vulnerabilities_count: int
    code_smells_count: int
    technical_debt_ratio: float


@dataclass
class EnhancedCodeQualityReport:
    """增强的代码质量报告"""
    repository_name: str
    analysis_date: str
    static_analysis: StaticAnalysisMetrics
    testing_metrics: TestingMetrics
    code_review: CodeReviewMetrics
    architecture: ArchitectureMetrics
    iso25010: ISO25010Metrics
    sonarqube: SonarQubeMetrics
    overall_score: float
    recommendations: List[str]


class EnhancedCodeQualityChecker:
    """增强的代码质量检查器"""
    
    def __init__(self, repository_path: str):
        """
        初始化增强的代码质量检查器
        
        Args:
            repository_path: 仓库路径
        """
        self.repository_path = Path(repository_path)
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # 质量阈值
        self.thresholds = {
            'max_cyclomatic_complexity': 10,
            'high_cyclomatic_complexity': 15,
            'max_function_length': 50,
            'max_line_length': 120,
            'min_test_coverage': 0.7,
            'max_code_duplication': 0.1,
            'max_nesting_depth': 4
        }
    
    def analyze_repository(self, repository_name: str) -> EnhancedCodeQualityReport:
        """
        全面分析仓库代码质量
        
        Args:
            repository_name: 仓库名称
            
        Returns:
            EnhancedCodeQualityReport: 增强的代码质量报告
        """
        self.logger.info(f"开始全面分析代码质量: {repository_name}")
        
        # 1. 静态代码分析
        static_analysis = self._perform_static_analysis()
        
        # 2. 测试指标分析
        testing_metrics = self._analyze_testing_metrics()
        
        # 3. 代码评审分析
        code_review = self._perform_code_review()
        
        # 4. 架构评估
        architecture = self._evaluate_architecture()
        
        # 5. ISO/IEC 25010 评估
        iso25010 = self._evaluate_iso25010(static_analysis, testing_metrics, code_review, architecture)
        
        # 6. SonarQube质量门禁评估
        sonarqube = self._evaluate_sonarqube(static_analysis, code_review)
        
        # 7. 计算总体评分（100分制，带权重）
        overall_score = self._calculate_overall_score(
            static_analysis, testing_metrics, code_review, architecture, iso25010, sonarqube
        )
        
        # 8. 生成建议
        recommendations = self._generate_recommendations(
            static_analysis, testing_metrics, code_review, architecture, iso25010, sonarqube
        )
        
        report = EnhancedCodeQualityReport(
            repository_name=repository_name,
            analysis_date=datetime.now().isoformat(),
            static_analysis=static_analysis,
            testing_metrics=testing_metrics,
            code_review=code_review,
            architecture=architecture,
            iso25010=iso25010,
            sonarqube=sonarqube,
            overall_score=overall_score,
            recommendations=recommendations
        )
        
        self.logger.info(f"代码质量分析完成，总体评分: {overall_score:.2f}/100")
        
        return report
    
    def _perform_static_analysis(self) -> StaticAnalysisMetrics:
        """执行静态代码分析"""
        self.logger.info("执行静态代码分析...")
        
        lint_issues = []
        cyclomatic_complexities = []
        high_complexity_functions = []
        duplicate_blocks = []
        
        python_files = list(self.repository_path.rglob("*.py"))
        
        for file_path in python_files:
            if self._should_ignore_file(file_path):
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Lint检查
                lint_issues.extend(self._check_lint_issues(file_path, content))
                
                # 圈复杂度分析
                try:
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.FunctionDef):
                            complexity = self._calculate_cyclomatic_complexity(node)
                            cyclomatic_complexities.append(complexity)
                            
                            if complexity > self.thresholds['high_cyclomatic_complexity']:
                                high_complexity_functions.append({
                                    'file': str(file_path.relative_to(self.repository_path)),
                                    'function': node.name,
                                    'complexity': complexity,
                                    'line': node.lineno
                                })
                except SyntaxError:
                    pass
                
            except Exception as e:
                self.logger.warning(f"分析文件失败 {file_path}: {str(e)}")
        
        # 代码重复检测
        code_duplication_rate, duplicate_blocks = self._detect_code_duplication(python_files)
        
        avg_complexity = sum(cyclomatic_complexities) / len(cyclomatic_complexities) if cyclomatic_complexities else 0
        max_complexity = max(cyclomatic_complexities) if cyclomatic_complexities else 0
        
        return StaticAnalysisMetrics(
            lint_issues=lint_issues,
            avg_cyclomatic_complexity=avg_complexity,
            max_cyclomatic_complexity=max_complexity,
            high_complexity_functions=high_complexity_functions,
            code_duplication_rate=code_duplication_rate,
            duplicate_blocks=duplicate_blocks
        )
    
    def _check_lint_issues(self, file_path: Path, content: str) -> List[Dict[str, Any]]:
        """检查Lint问题"""
        issues = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            # 检查行长度
            if len(line) > self.thresholds['max_line_length']:
                issues.append({
                    'file': str(file_path.relative_to(self.repository_path)),
                    'line': i,
                    'type': 'line_too_long',
                    'message': f'行长度超过{self.thresholds["max_line_length"]}字符'
                })
            
            # 检查尾随空格
            if line.rstrip() != line:
                issues.append({
                    'file': str(file_path.relative_to(self.repository_path)),
                    'line': i,
                    'type': 'trailing_whitespace',
                    'message': '行尾有多余空格'
                })
            
            # 检查制表符
            if '\t' in line:
                issues.append({
                    'file': str(file_path.relative_to(self.repository_path)),
                    'line': i,
                    'type': 'tab_character',
                    'message': '使用了制表符，建议使用空格'
                })
        
        return issues
    
    def _calculate_cyclomatic_complexity(self, node: ast.AST) -> int:
        """计算圈复杂度"""
        complexity = 1
        
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.AsyncFor)):
                complexity += 1
            elif isinstance(child, ast.ExceptHandler):
                complexity += 1
            elif isinstance(child, (ast.With, ast.AsyncWith)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        
        return complexity
    
    def _detect_code_duplication(self, files: List[Path]) -> Tuple[float, List[Dict[str, Any]]]:
        """检测代码重复"""
        code_blocks = []
        duplicate_blocks = []
        
        for file_path in files:
            if self._should_ignore_file(file_path):
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                try:
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.FunctionDef):
                            func_body = ast.get_source_segment(content, node)
                            if func_body:
                                code_blocks.append({
                                    'file': str(file_path.relative_to(self.repository_path)),
                                    'function': node.name,
                                    'code': func_body.strip()
                                })
                except SyntaxError:
                    pass
            except Exception:
                pass
        
        # 简单的重复检测（基于代码块相似度）
        duplicates = []
        for i, block1 in enumerate(code_blocks):
            for j, block2 in enumerate(code_blocks[i+1:], i+1):
                similarity = self._calculate_similarity(block1['code'], block2['code'])
                if similarity > 0.8:  # 80%相似度阈值
                    duplicates.append({
                        'block1': block1,
                        'block2': block2,
                        'similarity': similarity
                    })
        
        duplication_rate = len(duplicates) / len(code_blocks) if code_blocks else 0
        
        return duplication_rate, duplicates
    
    def _calculate_similarity(self, code1: str, code2: str) -> float:
        """计算代码相似度"""
        lines1 = set(code1.lower().split('\n'))
        lines2 = set(code2.lower().split('\n'))
        
        if not lines1 or not lines2:
            return 0.0
        
        intersection = lines1.intersection(lines2)
        union = lines1.union(lines2)
        
        return len(intersection) / len(union) if union else 0.0
    
    def _analyze_testing_metrics(self) -> TestingMetrics:
        """分析测试指标"""
        self.logger.info("分析测试指标...")
        
        test_files = []
        test_functions = 0
        uncovered_lines = []
        
        # 查找测试文件
        for file_path in self.repository_path.rglob("*.py"):
            if 'test' in file_path.name.lower() or 'test' in str(file_path.parent):
                test_files.append(file_path)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    tree = ast.parse(content)
                    test_functions += len([n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)])
                except:
                    pass
        
        # 计算测试覆盖率（简化版本）
        total_files = len(list(self.repository_path.rglob("*.py")))
        test_coverage = len(test_files) / total_files if total_files > 0 else 0
        
        # 测试通过率（假设为1.0，实际需要运行测试）
        test_pass_rate = 1.0
        
        return TestingMetrics(
            test_coverage=test_coverage,
            test_files_count=len(test_files),
            test_functions_count=test_functions,
            test_pass_rate=test_pass_rate,
            uncovered_lines=uncovered_lines
        )
    
    def _perform_code_review(self) -> CodeReviewMetrics:
        """执行代码评审"""
        self.logger.info("执行代码评审...")
        
        design_patterns = []
        security_issues = []
        code_smells = []
        naming_scores = []
        
        for file_path in self.repository_path.rglob("*.py"):
            if self._should_ignore_file(file_path):
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检测设计模式
                detected_patterns = self._detect_design_patterns(content)
                design_patterns.extend(detected_patterns)
                
                # 安全检查
                security_issues.extend(self._check_security_issues(file_path, content))
                
                # 代码异味检测
                code_smells.extend(self._detect_code_smells(file_path, content))
                
                # 命名质量
                naming_scores.append(self._evaluate_naming_quality(content))
                
            except Exception as e:
                self.logger.warning(f"代码评审失败 {file_path}: {str(e)}")
        
        readability_score = self._calculate_readability_score()
        naming_quality_score = sum(naming_scores) / len(naming_scores) if naming_scores else 0
        
        return CodeReviewMetrics(
            design_patterns=list(set(design_patterns)),
            readability_score=readability_score,
            naming_quality_score=naming_quality_score,
            security_issues=security_issues,
            code_smells=code_smells
        )
    
    def _detect_design_patterns(self, content: str) -> List[str]:
        """检测设计模式"""
        patterns = []
        
        # 简单的模式检测
        if re.search(r'class\s+\w+\(.*Factory.*\)', content):
            patterns.append('Factory Pattern')
        if re.search(r'class\s+\w+\(.*Singleton.*\)', content):
            patterns.append('Singleton Pattern')
        if re.search(r'class\s+\w+\(.*Observer.*\)', content):
            patterns.append('Observer Pattern')
        if re.search(r'class\s+\w+\(.*Strategy.*\)', content):
            patterns.append('Strategy Pattern')
        
        return patterns
    
    def _check_security_issues(self, file_path: Path, content: str) -> List[Dict[str, Any]]:
        """检查安全问题"""
        issues = []
        
        # SQL注入风险
        if re.search(r'execute\s*\(\s*[^)]*%[^)]*\)', content):
            issues.append({
                'file': str(file_path.relative_to(self.repository_path)),
                'type': 'sql_injection',
                'severity': 'high',
                'message': '潜在的SQL注入风险'
            })
        
        # 硬编码密码
        if re.search(r'(password|passwd|pwd)\s*=\s*[\'"][^\'"]{1,20}[\'"]', content, re.IGNORECASE):
            issues.append({
                'file': str(file_path.relative_to(self.repository_path)),
                'type': 'hardcoded_password',
                'severity': 'high',
                'message': '可能的硬编码密码'
            })
        
        # 不安全的反序列化
        if 'pickle.loads' in content or 'yaml.load' in content:
            issues.append({
                'file': str(file_path.relative_to(self.repository_path)),
                'type': 'unsafe_deserialization',
                'severity': 'medium',
                'message': '不安全的反序列化操作'
            })
        
        return issues
    
    def _detect_code_smells(self, file_path: Path, content: str) -> List[Dict[str, Any]]:
        """检测代码异味"""
        smells = []
        
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_lines = len(ast.get_source_segment(content, node).split('\n'))
                    if func_lines > self.thresholds['max_function_length']:
                        smells.append({
                            'file': str(file_path.relative_to(self.repository_path)),
                            'type': 'long_function',
                            'function': node.name,
                            'lines': func_lines,
                            'severity': 'medium'
                        })
        except SyntaxError:
            pass
        
        return smells
    
    def _evaluate_naming_quality(self, content: str) -> float:
        """评估命名质量"""
        score = 1.0
        
        # 检查是否有单字母变量名（除了循环变量）
        if re.search(r'\b[a-z]\s*=', content):
            score -= 0.1
        
        # 检查是否有下划线开头的变量（可能是私有变量，需要检查命名规范）
        # 这里简化处理
        
        return max(0, score)
    
    def _calculate_readability_score(self) -> float:
        """计算可读性分数"""
        # 简化版本，实际应该基于更多指标
        return 0.75
    
    def _evaluate_architecture(self) -> ArchitectureMetrics:
        """评估架构"""
        self.logger.info("评估架构...")
        
        # 依赖分析
        dependency_health, outdated_deps, vulnerable_deps = self._analyze_dependencies()
        
        # 耦合度和内聚性（简化评估）
        coupling_score = 0.7  # 需要更复杂的分析
        cohesion_score = 0.75
        layer_separation_score = 0.7
        
        return ArchitectureMetrics(
            coupling_score=coupling_score,
            cohesion_score=cohesion_score,
            layer_separation_score=layer_separation_score,
            dependency_health=dependency_health,
            outdated_dependencies=outdated_deps,
            vulnerable_dependencies=vulnerable_deps
        )
    
    def _analyze_dependencies(self) -> Tuple[float, List[str], List[str]]:
        """分析依赖"""
        outdated_deps = []
        vulnerable_deps = []
        
        # 检查requirements.txt
        req_file = self.repository_path / "requirements.txt"
        if req_file.exists():
            try:
                with open(req_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                # 检查是否有版本锁定
                if '==' not in content and '~=' not in content:
                    outdated_deps.append('缺少版本锁定')
            except:
                pass
        
        dependency_health = 0.8 if not outdated_deps else 0.5
        
        return dependency_health, outdated_deps, vulnerable_deps
    
    def _evaluate_iso25010(self, static: StaticAnalysisMetrics, testing: TestingMetrics,
                          review: CodeReviewMetrics, arch: ArchitectureMetrics) -> ISO25010Metrics:
        """评估ISO/IEC 25010质量模型"""
        
        # 功能合法性
        functional_suitability = 0.8
        
        # 性能效率
        performance_efficiency = 0.75
        
        # 兼容性
        compatibility = 0.8
        
        # 易用性
        usability = review.readability_score
        
        # 可靠性
        reliability = min(1.0, testing.test_coverage * 1.2)
        
        # 安全性
        security_score = 1.0 - (len(review.security_issues) * 0.1)
        security = max(0, security_score)
        
        # 可维护性
        maintainability = (
            (1.0 - static.code_duplication_rate) * 0.3 +
            (1.0 - min(1.0, static.avg_cyclomatic_complexity / 20)) * 0.3 +
            arch.dependency_health * 0.2 +
            review.readability_score * 0.2
        )
        
        # 可移植性
        portability = 0.8
        
        return ISO25010Metrics(
            functional_suitability=functional_suitability,
            performance_efficiency=performance_efficiency,
            compatibility=compatibility,
            usability=usability,
            reliability=reliability,
            security=security,
            maintainability=maintainability,
            portability=portability
        )
    
    def _evaluate_sonarqube(self, static: StaticAnalysisMetrics, review: CodeReviewMetrics) -> SonarQubeMetrics:
        """评估SonarQube质量门禁"""
        
        bugs_count = len([i for i in review.code_smells if i.get('severity') == 'high'])
        vulnerabilities_count = len([i for i in review.security_issues if i.get('severity') == 'high'])
        code_smells_count = len(review.code_smells)
        
        # 计算技术债务比率
        technical_debt_ratio = (
            bugs_count * 0.3 +
            vulnerabilities_count * 0.4 +
            code_smells_count * 0.1 +
            static.code_duplication_rate * 0.2
        )
        
        # 评级（A-E）
        def get_rating(score: float) -> str:
            if score < 0.1:
                return 'A'
            elif score < 0.2:
                return 'B'
            elif score < 0.3:
                return 'C'
            elif score < 0.5:
                return 'D'
            else:
                return 'E'
        
        reliability_score = bugs_count / 100.0
        security_score = vulnerabilities_count / 50.0
        maintainability_score = technical_debt_ratio
        
        return SonarQubeMetrics(
            reliability_rating=get_rating(reliability_score),
            security_rating=get_rating(security_score),
            maintainability_rating=get_rating(maintainability_score),
            bugs_count=bugs_count,
            vulnerabilities_count=vulnerabilities_count,
            code_smells_count=code_smells_count,
            technical_debt_ratio=technical_debt_ratio
        )
    
    def _calculate_overall_score(self, static: StaticAnalysisMetrics, testing: TestingMetrics,
                                review: CodeReviewMetrics, arch: ArchitectureMetrics,
                                iso25010: ISO25010Metrics, sonarqube: SonarQubeMetrics) -> float:
        """
        计算总体评分（100分制，简化权重分配，参照 demand.md）
        
        简化权重分配方案：
        =================
        1. 静态代码分析（Static Analysis）: 25分
           - Lint工具检查、圈复杂度、代码重复率
           - 综合评分：基于三个指标的平均表现
        
        2. 自动化测试指标（Testing Metrics）: 25分
           - 单元测试覆盖率、测试通过率
           - 综合评分：覆盖率权重70%，通过率权重30%
        
        3. 代码评审（Code Review）: 20分
           - 设计模式应用、可读性、安全性
           - 综合评分：三个维度等权重（各33.3%）
        
        4. 架构与设计评估（Architecture）: 20分
           - 耦合度与内聚性（合并为一个维度）、分层架构、依赖管理
           - 综合评分：耦合度与内聚性40%，分层架构30%，依赖管理30%
        
        5. SonarQube质量门禁: 10分
           - 可靠性、安全性、可维护性三个维度
           - 综合评分：三个维度等权重（各33.3%）
        
        总分 = 25 + 25 + 20 + 20 + 10 = 100分
        
        注意：去除了ISO25010质量模型，避免与SonarQube重复评估
        """
        # 1. 静态代码分析评分（25分）
        # 基于Lint问题、圈复杂度、代码重复率，三个指标等权重
        lint_score = max(0.0, 100.0 - min(100.0, len(static.lint_issues) * 2.0))  # 每个问题扣2分
        complexity_score = max(0.0, 100.0 - min(100.0, static.avg_cyclomatic_complexity * 5.0))  # 复杂度越高扣分越多
        duplication_score = max(0.0, 100.0 - static.code_duplication_rate * 100.0)  # 重复率直接扣分
        static_score = (lint_score + complexity_score + duplication_score) / 3.0
        static_weighted = static_score * 0.25
        
        # 2. 自动化测试指标评分（25分）
        # 测试覆盖率权重70%，测试通过率权重30%
        testing_score = testing.test_coverage * 70.0 + testing.test_pass_rate * 30.0
        testing_weighted = testing_score * 0.25
        
        # 3. 代码评审评分（20分）
        # 设计模式、可读性、安全性三个维度等权重
        design_pattern_score = 0.7 if len(review.design_patterns) > 0 else 0.3  # 有设计模式应用得0.7，无则0.3
        review_score = (
            design_pattern_score * 33.3 +
            review.readability_score * 33.3 +
            (1.0 - min(1.0, len(review.security_issues) * 0.2)) * 33.4  # 安全问题扣分
        )
        review_weighted = review_score * 0.20
        
        # 4. 架构与设计评估评分（20分）
        # 耦合度与内聚性合并（40%），分层架构（30%），依赖管理（30%）
        coupling_cohesion_score = (arch.coupling_score + arch.cohesion_score) / 2.0  # 耦合度和内聚性平均
        dependency_score = arch.dependency_health * (1.0 - min(1.0, (len(arch.outdated_dependencies) + len(arch.vulnerable_dependencies)) * 0.1))
        arch_score = (
            coupling_cohesion_score * 40.0 +
            arch.layer_separation_score * 30.0 +
            dependency_score * 30.0
        )
        arch_weighted = arch_score * 0.20
        
        # 5. SonarQube质量门禁评分（10分）
        # 可靠性、安全性、可维护性三个维度等权重
        rating_scores = {'A': 100.0, 'B': 80.0, 'C': 60.0, 'D': 40.0, 'E': 20.0}
        sonarqube_score = (
            rating_scores.get(sonarqube.reliability_rating, 50.0) +
            rating_scores.get(sonarqube.security_rating, 50.0) +
            rating_scores.get(sonarqube.maintainability_rating, 50.0)
        ) / 3.0
        sonarqube_weighted = sonarqube_score * 0.10
        
        # 综合评分（100分制）
        overall = (
            static_weighted +
            testing_weighted +
            review_weighted +
            arch_weighted +
            sonarqube_weighted
        )
        
        return min(100.0, max(0.0, overall))
    
    def _generate_recommendations(self, static: StaticAnalysisMetrics, testing: TestingMetrics,
                                 review: CodeReviewMetrics, arch: ArchitectureMetrics,
                                 iso25010: ISO25010Metrics, sonarqube: SonarQubeMetrics) -> List[str]:
        """生成改进建议"""
        recommendations = []
        
        # 静态分析建议
        if static.avg_cyclomatic_complexity > self.thresholds['max_cyclomatic_complexity']:
            recommendations.append(f"降低圈复杂度：当前平均复杂度{static.avg_cyclomatic_complexity:.1f}，建议控制在{self.thresholds['max_cyclomatic_complexity']}以下")
        
        if static.code_duplication_rate > self.thresholds['max_code_duplication']:
            recommendations.append(f"减少代码重复：当前重复率{static.code_duplication_rate:.2%}，建议控制在{self.thresholds['max_code_duplication']:.2%}以下")
        
        # 测试建议
        if testing.test_coverage < self.thresholds['min_test_coverage']:
            recommendations.append(f"提高测试覆盖率：当前覆盖率{testing.test_coverage:.2%}，建议达到{self.thresholds['min_test_coverage']:.2%}以上")
        
        # 安全建议
        if review.security_issues:
            recommendations.append(f"修复安全问题：发现{len(review.security_issues)}个安全问题需要处理")
        
        # 架构建议
        if arch.outdated_dependencies:
            recommendations.append("更新依赖：存在过时的依赖包，建议更新到最新版本")
        
        # SonarQube建议
        if sonarqube.reliability_rating in ['D', 'E']:
            recommendations.append(f"提高可靠性：当前可靠性评级为{sonarqube.reliability_rating}，建议修复{sonarqube.bugs_count}个Bug")
        
        if sonarqube.security_rating in ['D', 'E']:
            recommendations.append(f"提高安全性：当前安全性评级为{sonarqube.security_rating}，建议修复{sonarqube.vulnerabilities_count}个安全漏洞")
        
        return recommendations
    
    def _should_ignore_file(self, file_path: Path) -> bool:
        """判断是否应该忽略文件"""
        ignore_patterns = [
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.idea', '.vscode', 'build', 'dist', '*.pyc', '*.pyo'
        ]
        
        path_str = str(file_path)
        for pattern in ignore_patterns:
            if pattern in path_str:
                return True
        
        return False
    
    def save_report(self, report: EnhancedCodeQualityReport, output_file: Optional[str] = None):
        """保存报告（使用固定文件名，不包含时间戳）"""
        if output_file is None:
            output_file = f"./results/research_data/{report.repository_name}_enhanced_quality.json"
        
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 转换为字典
        report_dict = {
            'repository_name': report.repository_name,
            'analysis_date': report.analysis_date,
            'static_analysis': asdict(report.static_analysis),
            'testing_metrics': asdict(report.testing_metrics),
            'code_review': asdict(report.code_review),
            'architecture': asdict(report.architecture),
            'iso25010': asdict(report.iso25010),
            'sonarqube': asdict(report.sonarqube),
            'overall_score': report.overall_score,
            'recommendations': report.recommendations
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report_dict, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"增强代码质量报告已保存到: {output_path}")


if __name__ == "__main__":
    # 测试
    checker = EnhancedCodeQualityChecker("./repo/mnist-classification")
    report = checker.analyze_repository("mnist-classification")
    checker.save_report(report)
    
    print(f"\n总体评分: {report.overall_score:.2f}/100")
    print(f"\n建议:")
    for rec in report.recommendations:
        print(f"  - {rec}")

