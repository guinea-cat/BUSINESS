# SAGE代码质量评估系统

## 项目简介

SAGE（Smart AI Grading Engine）代码质量评估系统是一款专为AI黑客松比赛评委设计的代码质量评估工具，通过多维度分析为评委提供专业、客观的代码质量评估报告。

## 核心功能

- **📥 Git数据抓取**：自动抓取GitHub仓库的Commits、Issues、Pull Requests、Contributors数据
- **🔄 数据预处理**：清洗、转换、验证原始数据
- **📊 数据分析**：统计分析、趋势分析、关键指标计算
- **🔍 代码质量检查**：自动克隆代码并执行全面的代码质量分析
  - 静态分析（Lint、圈复杂度、代码重复）
  - 测试指标（覆盖率、通过率）
  - 代码评审（设计模式、可读性、安全性）
  - 架构评估（耦合度、内聚度、依赖管理）
  - ISO/IEC 25010 质量模型
  - SonarQube质量门禁
- **🤖 AI项目评价**：基于所有分析数据生成专业的AI评价报告（JSON和Markdown格式）

## 技术栈

- **前端**：Gradio Web界面
- **后端**：Python 3.7+
- **AI模型**：ModelScope Qwen/Qwen3-8B
- **代码分析**：AST解析、静态分析工具

## 快速开始

### 1. 环境配置

```bash
# 安装依赖
pip install -r requirements.txt

# 设置环境变量（可选）
export GITHUB_TOKEN=your_github_token
export MODELSCOPE_API_TOKEN=your_modelscope_token
```

### 2. 使用Gradio界面

```bash
# 启动Gradio服务器
python start_app.py

# 或直接运行
python app.py
```

访问 http://localhost:7863 使用Web界面。

### 3. 使用命令行

```bash
# 完整流程（包含AI评价）
python main.py --repo https://github.com/user/repo.git --name repo-name

# 仅数据研究（不生成AI评价）
python main.py --repo https://github.com/user/repo.git --name repo-name --no-ai

# 仅AI评价（基于已有数据）
python main.py --evaluate-only --project repo-name
```

## 评估流程

1. **数据抓取**：从GitHub API抓取仓库数据
2. **数据预处理**：清洗和转换数据
3. **数据分析**：统计分析和关键指标计算
4. **代码质量检查**：自动克隆代码并执行全面分析
5. **AI评价**：基于所有数据生成AI评价报告

## 输出文件

所有结果保存在 `results/research_data/<项目名>/` 目录：

- `*_complete_research.json` - 完整研究结果
- `*_enhanced_quality.json` - 代码质量报告（100分制）
- `*_ai_evaluation.json` - AI评价结果（JSON）
- `*_ai_evaluation.md` - AI评价报告（Markdown）
- `*_ai_evaluation_radar.png` - 质量雷达图（如果启用）

## 评分体系

代码质量评估采用100分制，包含以下维度：

- **静态分析**（30分）：Lint问题、圈复杂度、代码重复
- **测试指标**（25分）：测试覆盖率、通过率
- **代码评审**（25分）：设计模式、可读性、安全性
- **架构评估**（20分）：耦合度、内聚度、依赖管理

## 注意事项

- 支持公开的GitHub仓库，私有仓库需提供访问Token
- 评估时间取决于仓库大小，通常需要1-5分钟
- 代码质量检查需要自动克隆代码，确保有足够的磁盘空间
- AI评价需要ModelScope API访问权限
- 本工具仅供参考，评估结果应结合人工判断使用

