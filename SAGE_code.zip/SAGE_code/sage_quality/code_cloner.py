import os
import git
import logging
import shutil
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime
from dataclasses import dataclass

@dataclass
class CloneResult:
    success: bool
    repository_name: str
    repository_url: str
    local_path: str
    error_message: Optional[str] = None
    clone_time: Optional[datetime] = None
    repository_size: Optional[int] = None

class CodeCloner:
    def __init__(self, base_clone_directory: str = "./cloned_repos"):
        self.base_clone_directory = Path(base_clone_directory)
        self.base_clone_directory.mkdir(parents=True, exist_ok=True)
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def clone_repository(self, repository_url: str, repository_name: str, 
                        branch: str = "master", depth: Optional[int] = None, 
                        skip_if_exists: bool = False) -> CloneResult:
        """
        克隆Git仓库（默认覆盖已存在的项目）
        
        Args:
            repository_url: 仓库URL
            repository_name: 仓库名称（用于本地目录命名）
            branch: 要克隆的分支，默认为master
            depth: 克隆深度，None表示完整克隆
            skip_if_exists: 如果目录已存在是否跳过（默认False，会覆盖）
            
        Returns:
            CloneResult: 克隆结果
        """
        start_time = datetime.now()
        local_path = self.base_clone_directory / repository_name
        
        try:
            self.logger.info(f"开始克隆仓库: {repository_name} ({repository_url})")
            
            # 如果目录已存在，根据参数决定是跳过还是删除
            if local_path.exists():
                if skip_if_exists:
                    self.logger.info(f"目录已存在，跳过克隆: {local_path}")
                    # 获取已存在仓库的信息
                    repo_size = self._calculate_directory_size(local_path)
                    return CloneResult(
                        success=True,
                        repository_name=repository_name,
                        repository_url=repository_url,
                        local_path=str(local_path),
                        clone_time=datetime.now() - start_time,
                        repository_size=repo_size
                    )
                else:
                    self.logger.info(f"目录已存在，正在删除以覆盖: {local_path}")
                    shutil.rmtree(local_path)
            
            # 克隆选项
            clone_options = {
                'url': repository_url,
                'to_path': str(local_path),
                'branch': branch
            }
            
            # 如果指定了深度，添加深度参数
            if depth:
                clone_options['depth'] = depth
            
            # 执行克隆
            repo = git.Repo.clone_from(**clone_options)
            
            # 计算仓库大小
            repo_size = self._calculate_directory_size(local_path)
            
            clone_time = datetime.now() - start_time
            
            self.logger.info(f"仓库克隆成功: {repository_name}")
            self.logger.info(f"克隆耗时: {clone_time}")
            self.logger.info(f"仓库大小: {self._format_size(repo_size)}")
            
            return CloneResult(
                success=True,
                repository_name=repository_name,
                repository_url=repository_url,
                local_path=str(local_path),
                clone_time=clone_time,
                repository_size=repo_size
            )
            
        except git.GitCommandError as e:
            error_msg = f"Git命令错误: {str(e)}"
            self.logger.error(error_msg)
            return CloneResult(
                success=False,
                repository_name=repository_name,
                repository_url=repository_url,
                local_path=str(local_path),
                error_message=error_msg,
                clone_time=datetime.now() - start_time
            )
            
        except Exception as e:
            error_msg = f"克隆失败: {str(e)}"
            self.logger.error(error_msg)
            return CloneResult(
                success=False,
                repository_name=repository_name,
                repository_url=repository_url,
                local_path=str(local_path),
                error_message=error_msg,
                clone_time=datetime.now() - start_time
            )
    
    def clone_multiple_repositories(self, repositories: List[Dict[str, str]], 
                                  skip_if_exists: bool = False) -> List[CloneResult]:
        """
        批量克隆多个仓库
        
        Args:
            repositories: 仓库列表，每个仓库包含url和name
            skip_if_exists: 如果目录已存在是否跳过（默认False，会覆盖）
            
        Returns:
            List[CloneResult]: 克隆结果列表
        """
        results = []
        
        for repo_info in repositories:
            url = repo_info.get('url')
            name = repo_info.get('name')
            branch = repo_info.get('branch', 'master')
            depth = repo_info.get('depth')
            
            if not url or not name:
                self.logger.error(f"仓库信息不完整: {repo_info}")
                continue
            
            result = self.clone_repository(url, name, branch, depth, skip_if_exists)
            results.append(result)
            
            # 如果克隆失败，记录错误但不中断其他仓库的克隆
            if not result.success:
                self.logger.error(f"仓库克隆失败: {name} - {result.error_message}")
        
        return results
    
    def get_repository_info(self, local_path: str) -> Dict:
        """
        获取本地仓库信息
        
        Args:
            local_path: 本地仓库路径
            
        Returns:
            Dict: 仓库信息
        """
        try:
            repo = git.Repo(local_path)
            
            # 获取远程仓库信息
            remote_urls = []
            for remote in repo.remotes:
                remote_urls.extend(remote.urls)
            
            # 获取分支信息
            branches = [str(branch) for branch in repo.branches]
            
            # 获取标签信息
            tags = [str(tag) for tag in repo.tags]
            
            # 获取最近的提交信息
            try:
                last_commit = repo.head.commit
                last_commit_info = {
                    'hash': str(last_commit.hexsha),
                    'author': str(last_commit.author),
                    'date': str(last_commit.committed_datetime),
                    'message': str(last_commit.message.strip())
                }
            except:
                last_commit_info = None
            
            # 获取贡献者信息
            try:
                contributors = set()
                for commit in repo.iter_commits():
                    contributors.add(str(commit.author))
                contributors = list(contributors)
            except:
                contributors = []
            
            return {
                'remote_urls': remote_urls,
                'branches': branches,
                'tags': tags,
                'last_commit': last_commit_info,
                'contributors': contributors,
                'total_commits': len(list(repo.iter_commits())),
                'is_bare': repo.bare
            }
            
        except Exception as e:
            self.logger.error(f"获取仓库信息失败: {str(e)}")
            return {}
    
    def _calculate_directory_size(self, path: Path) -> int:
        """计算目录大小（字节）"""
        total_size = 0
        try:
            for file_path in path.rglob('*'):
                if file_path.is_file():
                    total_size += file_path.stat().st_size
        except Exception as e:
            self.logger.warning(f"计算目录大小失败: {str(e)}")
        
        return total_size
    
    def _format_size(self, size_in_bytes: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_in_bytes < 1024.0:
                return f"{size_in_bytes:.2f} {unit}"
            size_in_bytes /= 1024.0
        return f"{size_in_bytes:.2f} TB"
    
    def list_cloned_repositories(self) -> List[Dict]:
        """
        列出已克隆的仓库
        
        Returns:
            List[Dict]: 仓库信息列表
        """
        cloned_repos = []
        
        if not self.base_clone_directory.exists():
            return cloned_repos
        
        for item in self.base_clone_directory.iterdir():
            if item.is_dir():
                repo_info = self.get_repository_info(str(item))
                repo_info['name'] = item.name
                repo_info['path'] = str(item)
                repo_info['size'] = self._format_size(self._calculate_directory_size(item))
                cloned_repos.append(repo_info)
        
        return cloned_repos
    
    def remove_repository(self, repository_name: str) -> bool:
        """
        删除已克隆的仓库
        
        Args:
            repository_name: 仓库名称
            
        Returns:
            bool: 是否成功删除
        """
        repo_path = self.base_clone_directory / repository_name
        
        if not repo_path.exists():
            self.logger.warning(f"仓库不存在: {repository_name}")
            return False
        
        try:
            shutil.rmtree(repo_path)
            self.logger.info(f"仓库已删除: {repository_name}")
            return True
        except Exception as e:
            self.logger.error(f"删除仓库失败: {str(e)}")
            return False

if __name__ == "__main__":
    # 测试代码克隆器
    cloner = CodeCloner()
    
    # 测试单个仓库克隆
    test_repos = [
        {
            'url': 'https://github.com/hysts/pytorch_image_classification.git',
            'name': 'gitpython-test',
            'branch': 'master',
            'depth': 10  # 只克隆最近的10个提交
        }
    ]
    
    print("开始测试代码克隆功能...")
    results = cloner.clone_multiple_repositories(test_repos)
    
    for result in results:
        print(f"\n克隆结果:")
        print(f"仓库: {result.repository_name}")
        print(f"成功: {result.success}")
        if result.success:
            print(f"路径: {result.local_path}")
            print(f"大小: {cloner._format_size(result.repository_size) if result.repository_size else '未知'}")
            print(f"耗时: {result.clone_time}")
        else:
            print(f"错误: {result.error_message}")
    
    # 列出已克隆的仓库
    print("\n已克隆的仓库:")
    cloned_repos = cloner.list_cloned_repositories()
    for repo in cloned_repos:
        print(f"- {repo['name']} ({repo['size']})")

