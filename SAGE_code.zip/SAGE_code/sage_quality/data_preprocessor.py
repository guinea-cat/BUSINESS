"""
数据预处理模块
用于清洗、转换和验证从Git网页抓取的数据
"""

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict


@dataclass
class PreprocessingStats:
    """预处理统计信息"""
    total_records: int
    cleaned_records: int
    removed_records: int
    transformed_records: int
    validation_errors: List[str]
    processing_time: float


class DataPreprocessor:
    """数据预处理器"""
    
    def __init__(self, output_directory: str = "./results/research_data/processed"):
        """
        初始化数据预处理器
        
        Args:
            output_directory: 处理后数据的输出目录
        """
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # 数据清洗规则
        self.cleaning_rules = {
            'remove_empty_fields': True,
            'normalize_dates': True,
            'sanitize_text': True,
            'remove_duplicates': True,
            'validate_required_fields': True
        }
    
    def preprocess_commits(self, commits_data: List[Dict]) -> Dict[str, Any]:
        """
        预处理提交数据
        
        Args:
            commits_data: 原始提交数据列表
            
        Returns:
            Dict: 预处理后的数据和统计信息
        """
        self.logger.info(f"开始预处理提交数据，共 {len(commits_data)} 条记录")
        
        start_time = datetime.now()
        cleaned_commits = []
        removed_count = 0
        validation_errors = []
        
        for commit in commits_data:
            try:
                # 清洗数据
                cleaned_commit = self._clean_commit(commit)
                
                # 验证数据
                if self._validate_commit(cleaned_commit):
                    # 转换数据格式
                    transformed_commit = self._transform_commit(cleaned_commit)
                    cleaned_commits.append(transformed_commit)
                else:
                    removed_count += 1
                    validation_errors.append(f"提交 {commit.get('sha', 'unknown')} 验证失败")
                    
            except Exception as e:
                self.logger.warning(f"处理提交数据失败: {str(e)}")
                removed_count += 1
                validation_errors.append(f"处理提交时出错: {str(e)}")
        
        # 去重
        if self.cleaning_rules['remove_duplicates']:
            cleaned_commits = self._remove_duplicate_commits(cleaned_commits)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        stats = PreprocessingStats(
            total_records=len(commits_data),
            cleaned_records=len(cleaned_commits),
            removed_records=removed_count,
            transformed_records=len(cleaned_commits),
            validation_errors=validation_errors,
            processing_time=processing_time
        )
        
        self.logger.info(f"提交数据预处理完成: {stats.cleaned_records}/{stats.total_records} 条记录通过")
        
        return {
            'data': cleaned_commits,
            'stats': asdict(stats),
            'data_type': 'commits'
        }
    
    def preprocess_issues(self, issues_data: List[Dict]) -> Dict[str, Any]:
        """
        预处理Issues数据
        
        Args:
            issues_data: 原始Issues数据列表
            
        Returns:
            Dict: 预处理后的数据和统计信息
        """
        self.logger.info(f"开始预处理Issues数据，共 {len(issues_data)} 条记录")
        
        start_time = datetime.now()
        cleaned_issues = []
        removed_count = 0
        validation_errors = []
        
        for issue in issues_data:
            try:
                # 清洗数据
                cleaned_issue = self._clean_issue(issue)
                
                # 验证数据
                if self._validate_issue(cleaned_issue):
                    # 转换数据格式
                    transformed_issue = self._transform_issue(cleaned_issue)
                    cleaned_issues.append(transformed_issue)
                else:
                    removed_count += 1
                    validation_errors.append(f"Issue {issue.get('number', 'unknown')} 验证失败")
                    
            except Exception as e:
                self.logger.warning(f"处理Issue数据失败: {str(e)}")
                removed_count += 1
                validation_errors.append(f"处理Issue时出错: {str(e)}")
        
        # 去重
        if self.cleaning_rules['remove_duplicates']:
            cleaned_issues = self._remove_duplicate_issues(cleaned_issues)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        stats = PreprocessingStats(
            total_records=len(issues_data),
            cleaned_records=len(cleaned_issues),
            removed_records=removed_count,
            transformed_records=len(cleaned_issues),
            validation_errors=validation_errors,
            processing_time=processing_time
        )
        
        self.logger.info(f"Issues数据预处理完成: {stats.cleaned_records}/{stats.total_records} 条记录通过")
        
        return {
            'data': cleaned_issues,
            'stats': asdict(stats),
            'data_type': 'issues'
        }
    
    def preprocess_pull_requests(self, prs_data: List[Dict]) -> Dict[str, Any]:
        """
        预处理Pull Requests数据
        
        Args:
            prs_data: 原始PR数据列表
            
        Returns:
            Dict: 预处理后的数据和统计信息
        """
        self.logger.info(f"开始预处理Pull Requests数据，共 {len(prs_data)} 条记录")
        
        start_time = datetime.now()
        cleaned_prs = []
        removed_count = 0
        validation_errors = []
        
        for pr in prs_data:
            try:
                # 清洗数据
                cleaned_pr = self._clean_pull_request(pr)
                
                # 验证数据
                if self._validate_pull_request(cleaned_pr):
                    # 转换数据格式
                    transformed_pr = self._transform_pull_request(cleaned_pr)
                    cleaned_prs.append(transformed_pr)
                else:
                    removed_count += 1
                    validation_errors.append(f"PR {pr.get('number', 'unknown')} 验证失败")
                    
            except Exception as e:
                self.logger.warning(f"处理PR数据失败: {str(e)}")
                removed_count += 1
                validation_errors.append(f"处理PR时出错: {str(e)}")
        
        # 去重
        if self.cleaning_rules['remove_duplicates']:
            cleaned_prs = self._remove_duplicate_pull_requests(cleaned_prs)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        stats = PreprocessingStats(
            total_records=len(prs_data),
            cleaned_records=len(cleaned_prs),
            removed_records=removed_count,
            transformed_records=len(cleaned_prs),
            validation_errors=validation_errors,
            processing_time=processing_time
        )
        
        self.logger.info(f"Pull Requests数据预处理完成: {stats.cleaned_records}/{stats.total_records} 条记录通过")
        
        return {
            'data': cleaned_prs,
            'stats': asdict(stats),
            'data_type': 'pull_requests'
        }
    
    def preprocess_contributors(self, contributors_data: List[Dict]) -> Dict[str, Any]:
        """
        预处理贡献者数据
        
        Args:
            contributors_data: 原始贡献者数据列表
            
        Returns:
            Dict: 预处理后的数据和统计信息
        """
        self.logger.info(f"开始预处理贡献者数据，共 {len(contributors_data)} 条记录")
        
        start_time = datetime.now()
        cleaned_contributors = []
        removed_count = 0
        validation_errors = []
        
        for contributor in contributors_data:
            try:
                # 清洗数据
                cleaned_contributor = self._clean_contributor(contributor)
                
                # 验证数据
                if self._validate_contributor(cleaned_contributor):
                    # 转换数据格式
                    transformed_contributor = self._transform_contributor(cleaned_contributor)
                    cleaned_contributors.append(transformed_contributor)
                else:
                    removed_count += 1
                    validation_errors.append(f"贡献者 {contributor.get('login', 'unknown')} 验证失败")
                    
            except Exception as e:
                self.logger.warning(f"处理贡献者数据失败: {str(e)}")
                removed_count += 1
                validation_errors.append(f"处理贡献者时出错: {str(e)}")
        
        # 去重
        if self.cleaning_rules['remove_duplicates']:
            cleaned_contributors = self._remove_duplicate_contributors(cleaned_contributors)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        stats = PreprocessingStats(
            total_records=len(contributors_data),
            cleaned_records=len(cleaned_contributors),
            removed_records=removed_count,
            transformed_records=len(cleaned_contributors),
            validation_errors=validation_errors,
            processing_time=processing_time
        )
        
        self.logger.info(f"贡献者数据预处理完成: {stats.cleaned_records}/{stats.total_records} 条记录通过")
        
        return {
            'data': cleaned_contributors,
            'stats': asdict(stats),
            'data_type': 'contributors'
        }
    
    def _clean_commit(self, commit: Dict) -> Dict:
        """清洗提交数据"""
        cleaned = {}
        
        # 必需字段
        cleaned['sha'] = commit.get('sha', '').strip()
        cleaned['message'] = self._sanitize_text(commit.get('message', ''))
        cleaned['author'] = self._clean_author(commit.get('author', {}))
        cleaned['committer'] = self._clean_committer(commit.get('committer', {}))
        cleaned['date'] = self._normalize_date(commit.get('author', {}).get('date') or 
                                               commit.get('committer', {}).get('date'))
        cleaned['url'] = commit.get('url', '').strip()
        
        # 统计信息
        stats = commit.get('stats', {})
        cleaned['stats'] = {
            'additions': int(stats.get('additions', 0)) if stats.get('additions') else 0,
            'deletions': int(stats.get('deletions', 0)) if stats.get('deletions') else 0,
            'total': int(stats.get('total', 0)) if stats.get('total') else 0
        }
        
        # 移除空字段（如果配置了）
        if self.cleaning_rules['remove_empty_fields']:
            cleaned = {k: v for k, v in cleaned.items() if v or k in ['stats']}
        
        return cleaned
    
    def _clean_issue(self, issue: Dict) -> Dict:
        """清洗Issue数据"""
        cleaned = {}
        
        # 必需字段
        cleaned['number'] = int(issue.get('number', 0))
        cleaned['title'] = self._sanitize_text(issue.get('title', ''))
        cleaned['body'] = self._sanitize_text(issue.get('body', ''))
        cleaned['state'] = issue.get('state', 'open').lower()
        cleaned['created_at'] = self._normalize_date(issue.get('created_at'))
        cleaned['updated_at'] = self._normalize_date(issue.get('updated_at'))
        cleaned['closed_at'] = self._normalize_date(issue.get('closed_at'))
        
        # 作者信息
        author = issue.get('author', {})
        cleaned['author'] = {
            'login': author.get('login', '').strip(),
            'id': int(author.get('id', 0)) if author.get('id') else 0
        }
        
        # 标签
        cleaned['labels'] = [label.get('name', '').strip() for label in issue.get('labels', []) 
                            if label.get('name')]
        
        # 其他字段
        cleaned['comments'] = int(issue.get('comments', 0)) if issue.get('comments') else 0
        cleaned['html_url'] = issue.get('html_url', '').strip()
        
        return cleaned
    
    def _clean_pull_request(self, pr: Dict) -> Dict:
        """清洗Pull Request数据"""
        cleaned = {}
        
        # 必需字段
        cleaned['number'] = int(pr.get('number', 0))
        cleaned['title'] = self._sanitize_text(pr.get('title', ''))
        cleaned['body'] = self._sanitize_text(pr.get('body', ''))
        cleaned['state'] = pr.get('state', 'open').lower()
        cleaned['created_at'] = self._normalize_date(pr.get('created_at'))
        cleaned['updated_at'] = self._normalize_date(pr.get('updated_at'))
        cleaned['closed_at'] = self._normalize_date(pr.get('closed_at'))
        cleaned['merged_at'] = self._normalize_date(pr.get('merged_at'))
        cleaned['merged'] = bool(pr.get('merged', False))
        
        # 作者信息
        author = pr.get('author', {})
        cleaned['author'] = {
            'login': author.get('login', '').strip(),
            'id': int(author.get('id', 0)) if author.get('id') else 0
        }
        
        # 分支信息
        cleaned['head'] = {
            'ref': pr.get('head', {}).get('ref', '').strip(),
            'sha': pr.get('head', {}).get('sha', '').strip()
        }
        cleaned['base'] = {
            'ref': pr.get('base', {}).get('ref', '').strip(),
            'sha': pr.get('base', {}).get('sha', '').strip()
        }
        
        # 统计信息
        cleaned['stats'] = {
            'comments': int(pr.get('comments', 0)) if pr.get('comments') else 0,
            'review_comments': int(pr.get('review_comments', 0)) if pr.get('review_comments') else 0,
            'commits': int(pr.get('commits', 0)) if pr.get('commits') else 0,
            'additions': int(pr.get('additions', 0)) if pr.get('additions') else 0,
            'deletions': int(pr.get('deletions', 0)) if pr.get('deletions') else 0,
            'changed_files': int(pr.get('changed_files', 0)) if pr.get('changed_files') else 0
        }
        
        cleaned['html_url'] = pr.get('html_url', '').strip()
        
        return cleaned
    
    def _clean_contributor(self, contributor: Dict) -> Dict:
        """清洗贡献者数据"""
        cleaned = {}
        
        cleaned['login'] = contributor.get('login', '').strip()
        cleaned['id'] = int(contributor.get('id', 0)) if contributor.get('id') else 0
        cleaned['contributions'] = int(contributor.get('contributions', 0)) if contributor.get('contributions') else 0
        cleaned['avatar_url'] = contributor.get('avatar_url', '').strip()
        cleaned['html_url'] = contributor.get('html_url', '').strip()
        cleaned['type'] = contributor.get('type', 'User').strip()
        
        return cleaned
    
    def _clean_author(self, author: Dict) -> Dict:
        """清洗作者信息"""
        if isinstance(author, dict):
            return {
                'name': self._sanitize_text(author.get('name', '')),
                'email': author.get('email', '').strip().lower(),
                'date': self._normalize_date(author.get('date'))
            }
        return {'name': '', 'email': '', 'date': None}
    
    def _clean_committer(self, committer: Dict) -> Dict:
        """清洗提交者信息"""
        return self._clean_author(committer)
    
    def _sanitize_text(self, text: str) -> str:
        """清理文本内容"""
        if not text:
            return ''
        
        if not self.cleaning_rules['sanitize_text']:
            return text.strip()
        
        # 移除多余的空白字符
        text = re.sub(r'\s+', ' ', text)
        # 移除控制字符
        text = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
        # 移除HTML标签（如果有）
        text = re.sub(r'<[^>]+>', '', text)
        
        return text.strip()
    
    def _normalize_date(self, date_str: Optional[str]) -> Optional[str]:
        """标准化日期格式"""
        if not date_str or not self.cleaning_rules['normalize_dates']:
            return date_str
        
        try:
            # 尝试解析ISO格式日期
            if isinstance(date_str, str):
                # 移除时区信息，统一为UTC
                date_str = date_str.replace('Z', '+00:00')
                dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                return dt.isoformat()
        except Exception as e:
            self.logger.warning(f"日期格式转换失败: {date_str}, 错误: {str(e)}")
        
        return date_str
    
    def _validate_commit(self, commit: Dict) -> bool:
        """验证提交数据"""
        if not self.cleaning_rules['validate_required_fields']:
            return True
        
        required_fields = ['sha', 'message', 'date']
        return all(commit.get(field) for field in required_fields)
    
    def _validate_issue(self, issue: Dict) -> bool:
        """验证Issue数据"""
        if not self.cleaning_rules['validate_required_fields']:
            return True
        
        required_fields = ['number', 'title', 'state', 'created_at']
        return all(issue.get(field) for field in required_fields)
    
    def _validate_pull_request(self, pr: Dict) -> bool:
        """验证Pull Request数据"""
        if not self.cleaning_rules['validate_required_fields']:
            return True
        
        required_fields = ['number', 'title', 'state', 'created_at']
        return all(pr.get(field) for field in required_fields)
    
    def _validate_contributor(self, contributor: Dict) -> bool:
        """验证贡献者数据"""
        if not self.cleaning_rules['validate_required_fields']:
            return True
        
        required_fields = ['login', 'contributions']
        return all(contributor.get(field) for field in required_fields)
    
    def _transform_commit(self, commit: Dict) -> Dict:
        """转换提交数据格式"""
        # 添加计算字段
        commit['lines_changed'] = commit.get('stats', {}).get('total', 0)
        commit['change_ratio'] = (
            commit.get('stats', {}).get('additions', 0) / 
            max(commit.get('stats', {}).get('deletions', 0), 1)
            if commit.get('stats', {}).get('deletions', 0) > 0 else 0
        )
        
        return commit
    
    def _transform_issue(self, issue: Dict) -> Dict:
        """转换Issue数据格式"""
        # 计算持续时间（如果已关闭）
        if issue.get('closed_at') and issue.get('created_at'):
            try:
                created = datetime.fromisoformat(issue['created_at'].replace('Z', '+00:00'))
                closed = datetime.fromisoformat(issue['closed_at'].replace('Z', '+00:00'))
                issue['duration_days'] = (closed - created).days
            except:
                issue['duration_days'] = None
        else:
            issue['duration_days'] = None
        
        # 计算标签数量
        issue['label_count'] = len(issue.get('labels', []))
        
        return issue
    
    def _transform_pull_request(self, pr: Dict) -> Dict:
        """转换Pull Request数据格式"""
        # 计算持续时间
        if pr.get('closed_at') or pr.get('merged_at'):
            end_date = pr.get('merged_at') or pr.get('closed_at')
            if end_date and pr.get('created_at'):
                try:
                    created = datetime.fromisoformat(pr['created_at'].replace('Z', '+00:00'))
                    closed = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
                    pr['duration_days'] = (closed - created).days
                except:
                    pr['duration_days'] = None
            else:
                pr['duration_days'] = None
        else:
            pr['duration_days'] = None
        
        # 计算代码变更比例
        stats = pr.get('stats', {})
        total_changes = stats.get('additions', 0) + stats.get('deletions', 0)
        pr['change_ratio'] = (
            stats.get('additions', 0) / max(total_changes, 1)
            if total_changes > 0 else 0
        )
        
        return pr
    
    def _transform_contributor(self, contributor: Dict) -> Dict:
        """转换贡献者数据格式"""
        # 可以添加贡献等级等计算字段
        contributions = contributor.get('contributions', 0)
        if contributions >= 100:
            contributor['contribution_level'] = 'high'
        elif contributions >= 10:
            contributor['contribution_level'] = 'medium'
        else:
            contributor['contribution_level'] = 'low'
        
        return contributor
    
    def _remove_duplicate_commits(self, commits: List[Dict]) -> List[Dict]:
        """移除重复的提交"""
        seen_shas = set()
        unique_commits = []
        
        for commit in commits:
            sha = commit.get('sha')
            if sha and sha not in seen_shas:
                seen_shas.add(sha)
                unique_commits.append(commit)
        
        return unique_commits
    
    def _remove_duplicate_issues(self, issues: List[Dict]) -> List[Dict]:
        """移除重复的Issues"""
        seen_numbers = set()
        unique_issues = []
        
        for issue in issues:
            number = issue.get('number')
            if number and number not in seen_numbers:
                seen_numbers.add(number)
                unique_issues.append(issue)
        
        return unique_issues
    
    def _remove_duplicate_pull_requests(self, prs: List[Dict]) -> List[Dict]:
        """移除重复的Pull Requests"""
        seen_numbers = set()
        unique_prs = []
        
        for pr in prs:
            number = pr.get('number')
            if number and number not in seen_numbers:
                seen_numbers.add(number)
                unique_prs.append(pr)
        
        return unique_prs
    
    def _remove_duplicate_contributors(self, contributors: List[Dict]) -> List[Dict]:
        """移除重复的贡献者"""
        seen_logins = set()
        unique_contributors = []
        
        for contributor in contributors:
            login = contributor.get('login')
            if login and login not in seen_logins:
                seen_logins.add(login)
                unique_contributors.append(contributor)
        
        return unique_contributors
    
    def save_processed_data(self, processed_data: Dict, filename: Optional[str] = None):
        """
        保存预处理后的数据
        
        Args:
            processed_data: 预处理后的数据
            filename: 文件名，如果为None则自动生成
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            data_type = processed_data.get('data_type', 'unknown')
            filename = f"processed_{data_type}_{timestamp}.json"
        
        file_path = self.output_directory / filename
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(processed_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"预处理数据已保存到: {file_path}")
            
        except Exception as e:
            self.logger.error(f"保存预处理数据失败: {str(e)}")
    
    def load_and_preprocess(self, input_file: Union[str, Path]) -> Dict[str, Any]:
        """
        加载原始数据并进行预处理
        
        Args:
            input_file: 输入文件路径
            
        Returns:
            Dict: 预处理后的数据
        """
        self.logger.info(f"加载并预处理数据文件: {input_file}")
        
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                raw_data = json.load(f)
            
            # 确定数据类型
            data_type = raw_data.get('data_type', '')
            data = raw_data.get('data', [])
            
            # 根据数据类型进行预处理
            if data_type == 'commits':
                return self.preprocess_commits(data)
            elif data_type == 'issues':
                return self.preprocess_issues(data)
            elif data_type == 'pull_requests':
                return self.preprocess_pull_requests(data)
            elif data_type == 'contributors':
                return self.preprocess_contributors(data)
            else:
                self.logger.warning(f"未知的数据类型: {data_type}")
                return {'data': data, 'stats': {}, 'data_type': data_type}
                
        except Exception as e:
            self.logger.error(f"加载和预处理数据失败: {str(e)}")
            raise


if __name__ == "__main__":
    # 测试数据预处理器
    preprocessor = DataPreprocessor()
    
    # 示例：预处理提交数据
    sample_commits = [
        {
            'sha': 'abc123',
            'message': 'Fix bug in data processing',
            'author': {'name': 'John Doe', 'email': 'john@example.com', 'date': '2024-01-01T00:00:00Z'},
            'committer': {'name': 'John Doe', 'email': 'john@example.com', 'date': '2024-01-01T00:00:00Z'},
            'url': 'https://github.com/example/repo/commit/abc123',
            'stats': {'additions': 10, 'deletions': 5, 'total': 15}
        }
    ]
    
    result = preprocessor.preprocess_commits(sample_commits)
    print(f"预处理结果: {result['stats']}")
    print(f"处理后的数据: {result['data']}")

