"""
Code Quality Researcher 主程序
整合Git网页数据抓取、数据预处理和数据处理功能
"""

import json
import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime

# 导入现有模块
try:
    from git_data_scraper import GitDataScraper, GitHubData
except ImportError:
    # 如果导入失败，尝试直接导入
    sys.path.insert(0, str(Path(__file__).parent))
    from git_data_scraper import GitDataScraper, GitHubData

# 导入代码克隆器（用于为质量检查准备本地仓库）
try:
    from code_cloner import CodeCloner, CloneResult
    HAS_CODE_CLONER = True
except ImportError:
    HAS_CODE_CLONER = False
    import warnings
    warnings.warn("code_cloner 模块未找到，将无法自动克隆仓库用于代码质量检查")

# 导入新创建的模块
from data_preprocessor import DataPreprocessor
from data_processor import DataProcessor

# 导入增强的代码质量检查器
try:
    from enhanced_code_quality_checker import EnhancedCodeQualityChecker
    HAS_QUALITY_CHECKER = True
except ImportError:
    HAS_QUALITY_CHECKER = False
    import warnings
    warnings.warn("enhanced_code_quality_checker 模块未找到，代码质量检查功能将不可用")


class CodeQualityResearcher:
    """代码质量研究主类 - 整合抓取、预处理和处理功能"""
    
    def __init__(self, 
                 output_directory: str = "./results/research_data",
                 delay_between_requests: int = 1,
                 max_retries: int = 3):
        """
        初始化Code Quality Researcher
        
        Args:
            output_directory: 数据输出目录
            delay_between_requests: 请求间隔（秒）
            max_retries: 最大重试次数
        """
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
        # 设置日志
        self._setup_logging()
        
        # 初始化组件
        self.git_scraper = GitDataScraper(
            output_directory=str(self.output_directory / "raw"),
            delay_between_requests=delay_between_requests,
            max_retries=max_retries
        )
        
        self.data_preprocessor = DataPreprocessor(
            output_directory=str(self.output_directory / "processed")
        )
        
        self.data_processor = DataProcessor(
            output_directory=str(self.output_directory / "analyzed")
        )
        
        # 如果支持代码克隆，则初始化克隆器（默认克隆到 ./repo）
        self.code_cloner = CodeCloner(base_clone_directory="./repo") if HAS_CODE_CLONER else None
        
        self.logger.info("Code Quality Researcher 初始化完成")
    
    def _setup_logging(self):
        """设置日志配置"""
        log_directory = Path("logs")
        log_directory.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_directory / f"code_quality_research_{timestamp}.log"
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"日志文件: {log_file}")
    
    def research_repository(self, 
                           repository_url: str,
                           repository_name: Optional[str] = None,
                           scrape_config: Optional[Dict] = None) -> Dict[str, Any]:
        """
        完整的研究流程：抓取 -> 预处理 -> 处理 -> 代码质量检查（自动执行）
        
        Args:
            repository_url: 仓库URL
            repository_name: 仓库名称（可选）
            scrape_config: 抓取配置
            
        Returns:
            Dict: 完整的研究结果
        """
        if not repository_name:
            # 从URL提取仓库名称
            parts = repository_url.rstrip('/').split('/')
            repository_name = parts[-1].replace('.git', '') if parts else 'unknown'
        
        # 规范化项目名称（用于目录名）
        safe_repo_name = repository_name.replace('/', '_').replace('\\', '_')
        
        self.logger.info(f"开始研究仓库: {repository_name} ({repository_url})")
        self.logger.info(f"数据将保存到: {self.output_directory / safe_repo_name}")

        # 检查代码质量检查依赖（模块和克隆器），如果缺失则给出警告但不中断流程
        if not HAS_QUALITY_CHECKER:
            self.logger.warning("未找到 enhanced_code_quality_checker 模块，将跳过代码质量检查")
        if not HAS_CODE_CLONER:
            self.logger.warning("未找到 code_cloner 模块，将跳过代码质量检查（无法自动克隆仓库）")
        
        # 为当前项目创建子目录结构
        project_dir = self.output_directory / safe_repo_name
        project_dir.mkdir(parents=True, exist_ok=True)
        
        # 更新各组件的输出目录为项目子目录
        project_raw_dir = project_dir / "raw"
        project_processed_dir = project_dir / "processed"
        project_analyzed_dir = project_dir / "analyzed"
        
        # 创建临时组件实例，使用项目特定的目录
        git_scraper = GitDataScraper(
            output_directory=str(project_raw_dir),
            delay_between_requests=self.git_scraper.delay_between_requests,
            max_retries=self.git_scraper.max_retries
        )
        
        data_preprocessor = DataPreprocessor(
            output_directory=str(project_processed_dir)
        )
        
        data_processor = DataProcessor(
            output_directory=str(project_analyzed_dir)
        )
        
        # 默认抓取配置
        if not scrape_config:
            scrape_config = {
                'commits': True,
                'issues': True,
                'pull_requests': True,
                'contributors': True
            }
        
        results = {
            'repository_name': repository_name,
            'repository_url': repository_url,
            'research_date': datetime.now().isoformat(),
            'scraping': {},
            'preprocessing': {},
            'processing': {},
            'summary': {}
        }
        
        try:
            # 步骤1: 抓取Git网页数据
            self.logger.info("=" * 60)
            self.logger.info("步骤1: 抓取Git网页数据")
            self.logger.info("=" * 60)
            
            scraped_data = git_scraper.scrape_all_data(repository_url, scrape_config)
            results['scraping'] = {
                'status': 'success',
                'data_types': list(scraped_data.keys()),
                'data_counts': {
                    data_type: len(data.data) if isinstance(data.data, list) else 1
                    for data_type, data in scraped_data.items()
                }
            }
            
            # 步骤2: 数据预处理
            self.logger.info("=" * 60)
            self.logger.info("步骤2: 数据预处理")
            self.logger.info("=" * 60)
            
            preprocessed_data = {}
            for data_type, github_data in scraped_data.items():
                if isinstance(github_data.data, list) and github_data.data:
                    self.logger.info(f"预处理 {data_type} 数据...")
                    
                    if data_type == 'commits':
                        preprocessed = data_preprocessor.preprocess_commits(github_data.data)
                    elif data_type == 'issues':
                        preprocessed = data_preprocessor.preprocess_issues(github_data.data)
                    elif data_type == 'pull_requests':
                        preprocessed = data_preprocessor.preprocess_pull_requests(github_data.data)
                    elif data_type == 'contributors':
                        preprocessed = data_preprocessor.preprocess_contributors(github_data.data)
                    else:
                        continue
                    
                    preprocessed_data[data_type] = preprocessed
                    
                    # 保存预处理数据（使用固定文件名，不包含时间戳）
                    filename = f"{safe_repo_name}_{data_type}_processed.json"
                    data_preprocessor.save_processed_data(preprocessed, filename)
            
            results['preprocessing'] = {
                'status': 'success',
                'processed_types': list(preprocessed_data.keys()),
                'stats': {
                    data_type: preprocessed.get('stats', {})
                    for data_type, preprocessed in preprocessed_data.items()
                }
            }
            
            # 步骤3: 数据处理和分析
            self.logger.info("=" * 60)
            self.logger.info("步骤3: 数据处理和分析")
            self.logger.info("=" * 60)
            
            analyzed_data = {}
            for data_type, preprocessed in preprocessed_data.items():
                if preprocessed.get('data'):
                    self.logger.info(f"处理和分析 {data_type} 数据...")
                    
                    if data_type == 'commits':
                        analyzed = data_processor.process_commits(preprocessed['data'])
                    elif data_type == 'issues':
                        analyzed = data_processor.process_issues(preprocessed['data'])
                    elif data_type == 'pull_requests':
                        analyzed = data_processor.process_pull_requests(preprocessed['data'])
                    elif data_type == 'contributors':
                        analyzed = data_processor.process_contributors(preprocessed['data'])
                    else:
                        continue
                    
                    analyzed_data[data_type] = analyzed
                    
                    # 保存分析结果（使用固定文件名，不包含时间戳）
                    filename = f"{safe_repo_name}_{data_type}_analysis.json"
                    data_processor.save_analysis_result(analyzed, filename)
            
            results['processing'] = {
                'status': 'success',
                'analyzed_types': list(analyzed_data.keys()),
                'analysis_summaries': {
                    data_type: analyzed.get('summary', {})
                    for data_type, analyzed in analyzed_data.items()
                }
            }
            
            # 步骤4: 代码质量检查（自动执行，如果依赖可用）
            quality_check_result = None
            if HAS_QUALITY_CHECKER and HAS_CODE_CLONER:
                quality_check_result = self._perform_code_quality_check(
                    repository_url, repository_name, project_dir
                )
                if quality_check_result:
                    results['code_quality'] = {
                        'status': 'success',
                        'overall_score': quality_check_result.get('overall_score', 0),
                        'has_report': True
                    }
                else:
                    results['code_quality'] = {
                        'status': 'failed',
                        'reason': 'code quality check failed, see logs for details'
                    }
            else:
                results['code_quality'] = {
                    'status': 'skipped',
                    'reason': 'code quality checker or code cloner not available'
                }
            
            # 生成总结报告
            results['summary'] = self._generate_summary(results, analyzed_data)
            
            # 保存完整研究结果（所有本地分析结果已保存，可以用于后续AI评价）
            self._save_research_result(results, repository_name, project_dir)
            
            self.logger.info("=" * 60)
            self.logger.info("研究完成！所有本地分析结果已保存到文件")
            self.logger.info("=" * 60)
            
            return results
            
        except Exception as e:
            self.logger.error(f"研究过程出错: {str(e)}")
            results['error'] = str(e)
            results['status'] = 'failed'
            raise
    
    def _generate_summary(self, results: Dict, analyzed_data: Dict) -> Dict:
        """生成研究总结"""
        summary = {
            'total_data_types': len(analyzed_data),
            'overall_status': 'success',
            'key_metrics': {}
        }
        
        # 提取关键指标
        if 'commits' in analyzed_data:
            commit_summary = analyzed_data['commits'].get('summary', {})
            summary['key_metrics']['commits'] = {
                'total': commit_summary.get('total_commits', 0),
                'total_changes': commit_summary.get('total_changes', 0),
                'net_changes': commit_summary.get('net_changes', 0)
            }
        
        if 'issues' in analyzed_data:
            issue_summary = analyzed_data['issues'].get('summary', {})
            summary['key_metrics']['issues'] = {
                'total': issue_summary.get('total_issues', 0),
                'open': issue_summary.get('open_issues', 0),
                'closed': issue_summary.get('closed_issues', 0),
                'closure_rate': issue_summary.get('closure_rate', 0)
            }
        
        if 'pull_requests' in analyzed_data:
            pr_summary = analyzed_data['pull_requests'].get('summary', {})
            summary['key_metrics']['pull_requests'] = {
                'total': pr_summary.get('total_prs', 0),
                'merged': pr_summary.get('merged_prs', 0),
                'merge_rate': pr_summary.get('merge_rate', 0)
            }
        
        if 'contributors' in analyzed_data:
            contributor_summary = analyzed_data['contributors'].get('summary', {})
            summary['key_metrics']['contributors'] = {
                'total': contributor_summary.get('total_contributors', 0),
                'total_contributions': contributor_summary.get('total_contributions', 0)
            }
        
        return summary
    
    def _perform_code_quality_check(self, repository_url: str, repository_name: str, project_dir: Path) -> Optional[Dict[str, Any]]:
        """
        执行代码质量检查
        
        Args:
            repository_url: 仓库URL（用于克隆）
            repository_name: 仓库名称
            project_dir: 项目目录
            
        Returns:
            Optional[Dict]: 代码质量检查结果
        """
        if not HAS_QUALITY_CHECKER or not HAS_CODE_CLONER or self.code_cloner is None:
            return None
        
        self.logger.info("=" * 60)
        self.logger.info("步骤4: 代码质量检查")
        self.logger.info("=" * 60)
        
        try:
            # 1. 确定本地克隆路径（./repo/{safe_repo_name}）
            safe_repo_name = repository_name.replace('/', '_').replace('\\', '_')
            # 使用 CodeCloner 的 base_clone_directory 配置（默认 ./repo）
            # 默认覆盖已存在的项目（skip_if_exists=False）
            clone_result: CloneResult = self.code_cloner.clone_repository(
                repository_url=repository_url,
                repository_name=safe_repo_name,
                branch="master",
                depth=None,
                skip_if_exists=False  # 默认覆盖已存在的项目
            )

            if not clone_result.success:
                self.logger.error(f"代码克隆失败，无法执行质量检查: {clone_result.error_message}")
                return None

            repo_path = Path(clone_result.local_path)
            if not repo_path.exists():
                self.logger.warning(f"本地仓库路径不存在: {repo_path}，跳过代码质量检查")
                return None
            
            # 2. 创建代码质量检查器
            quality_checker = EnhancedCodeQualityChecker(str(repo_path))
            
            # 3. 执行代码质量分析
            quality_report = quality_checker.analyze_repository(repository_name)
            
            # 4. 保存代码质量报告到项目目录
            safe_repo_name = repository_name.replace('/', '_').replace('\\', '_')
            # 使用固定文件名，不包含时间戳
            output_file = str(project_dir / f"{safe_repo_name}_enhanced_quality.json")
            quality_checker.save_report(quality_report, output_file)
            
            self.logger.info(f"代码质量检查完成，总体评分: {quality_report.overall_score:.2f}/100")
            self.logger.info(f"代码质量报告已保存到: {output_file}")
            
            # 返回摘要信息
            return {
                'overall_score': quality_report.overall_score,
                'static_analysis': {
                    'avg_cyclomatic_complexity': quality_report.static_analysis.avg_cyclomatic_complexity,
                    'code_duplication_rate': quality_report.static_analysis.code_duplication_rate,
                    'lint_issues_count': len(quality_report.static_analysis.lint_issues)
                },
                'testing_metrics': {
                    'test_coverage': quality_report.testing_metrics.test_coverage,
                    'test_files_count': quality_report.testing_metrics.test_files_count
                },
                'sonarqube': {
                    'reliability_rating': quality_report.sonarqube.reliability_rating,
                    'security_rating': quality_report.sonarqube.security_rating,
                    'maintainability_rating': quality_report.sonarqube.maintainability_rating
                },
                'recommendations_count': len(quality_report.recommendations),
                'report_file': output_file
            }
            
        except Exception as e:
            self.logger.error(f"代码质量检查失败: {str(e)}")
            import traceback
            self.logger.error(traceback.format_exc())
            return None
    
    def _save_research_result(self, results: Dict, repository_name: str, project_dir: Optional[Path] = None):
        """保存完整研究结果（使用固定文件名，不包含时间戳）"""
        safe_repo_name = repository_name.replace('/', '_').replace('\\', '_')
        filename = f"{safe_repo_name}_complete_research.json"
        
        if project_dir:
            file_path = project_dir / filename
        else:
            file_path = self.output_directory / filename
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"完整研究结果已保存到: {file_path}")
            
        except Exception as e:
            self.logger.error(f"保存研究结果失败: {str(e)}")
    
    def research_from_file(self, input_file: str, data_type: str) -> Dict[str, Any]:
        """
        从已保存的文件开始研究（跳过抓取步骤）
        
        Args:
            input_file: 输入文件路径
            data_type: 数据类型（commits, issues, pull_requests, contributors）
            
        Returns:
            Dict: 处理结果
        """
        self.logger.info(f"从文件加载数据: {input_file}")
        
        # 预处理
        preprocessed = self.data_preprocessor.load_and_preprocess(input_file)
        
        # 处理
        if preprocessed.get('data'):
            if data_type == 'commits':
                analyzed = self.data_processor.process_commits(preprocessed['data'])
            elif data_type == 'issues':
                analyzed = self.data_processor.process_issues(preprocessed['data'])
            elif data_type == 'pull_requests':
                analyzed = self.data_processor.process_pull_requests(preprocessed['data'])
            elif data_type == 'contributors':
                analyzed = self.data_processor.process_contributors(preprocessed['data'])
            else:
                raise ValueError(f"未知的数据类型: {data_type}")
            
            return analyzed
        
        return {}


def main():
    """主函数 - 示例用法"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Code Quality Researcher - Git数据抓取、预处理和处理')
    parser.add_argument('--repo', type=str, help='GitHub仓库URL')
    parser.add_argument('--name', type=str, help='仓库名称（可选）')
    parser.add_argument('--file', type=str, help='从文件加载数据（跳过抓取）')
    parser.add_argument('--type', type=str, choices=['commits', 'issues', 'pull_requests', 'contributors'],
                       help='数据类型（当使用--file时）')
    
    args = parser.parse_args()
    
    # 创建研究器
    researcher = CodeQualityResearcher()
    
    if args.file:
        # 从文件处理
        if not args.type:
            print("错误: 使用 --file 时必须指定 --type")
            return
        
        result = researcher.research_from_file(args.file, args.type)
        print(f"\n处理结果:")
        print(json.dumps(result.get('summary', {}), indent=2, ensure_ascii=False))
    
    elif args.repo:
        # 完整研究流程（自动执行代码质量检查：会将仓库克隆到 ./repo/{name}）
        result = researcher.research_repository(
            args.repo, 
            args.name
        )
        print(f"\n研究完成！")
        print(f"仓库: {result['repository_name']}")
        print(f"状态: {result.get('status', 'success')}")
        print(f"\n摘要:")
        print(json.dumps(result.get('summary', {}), indent=2, ensure_ascii=False))
        
        # 显示代码质量检查结果
        if 'code_quality' in result:
            quality_info = result['code_quality']
            if quality_info.get('status') == 'success':
                print(f"\n代码质量检查:")
                print(f"  总体评分: {quality_info.get('overall_score', 0):.2f}/100")
            elif quality_info.get('status') == 'skipped':
                print(f"\n代码质量检查: 已跳过 ({quality_info.get('reason', 'unknown')})")
    
    else:
        # 示例用法
        print("Code Quality Researcher - Git数据抓取、预处理和处理工具")
        print("\n用法示例:")
        print("  python main_researcher.py --repo https://github.com/user/repo.git")
        print("  python main_researcher.py --file data.json --type commits")
        print("\n完整研究流程:")
        print("  1. 抓取Git网页数据")
        print("  2. 数据预处理（清洗、转换、验证）")
        print("  3. 数据处理和分析（统计、聚合）")


if __name__ == "__main__":
    main()

