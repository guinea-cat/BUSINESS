"""
AI项目评价模块
基于research_data文件夹的内容，调用大模型API生成项目评价
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
from openai import OpenAI
import math

# 可选导入：用于绘制雷达图
try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except Exception:  # pragma: no cover - 绘图库缺失时降级
    HAS_MATPLOTLIB = False

# from api import client, extra_body

client = OpenAI(
    base_url='https://api-inference.modelscope.cn/v1',
    api_key='ms-a9b6efab-71d3-4305-9777-8aa26166ca83', # ModelScope Token
)

extra_body = {
    # enable thinking, set to False to disable test
    "enable_thinking": False,
    # use thinking_budget to contorl num of tokens used for thinking
    # "thinking_budget": 4096
}

class AIProjectEvaluator:
    """AI项目评价器"""
    
    def __init__(self, research_data_dir: str = "./results/research_data", project_name: Optional[str] = None):
        """
        初始化AI项目评价器
        
        Args:
            research_data_dir: 研究数据目录
            project_name: 项目名称（可选），如果指定则只加载该项目的数据
        """
        self.research_data_dir = Path(research_data_dir)
        self.project_name = project_name
        
        # 设置日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def load_research_data(self) -> Dict[str, Any]:
        """
        加载research_data文件夹中的所有研究数据
        
        Returns:
            Dict: 整合后的研究数据
        """
        self.logger.info("加载研究数据...")
        
        # 兼容两种 data-dir 用法：
        # 1) 传父目录：如 ./results/research_data（其下每个子目录是一个项目）
        # 2) 直接传项目目录：如 ./results/research_data/<project>（其下包含 raw/processed/analyzed 或 complete_research 文件）
        if not self.research_data_dir.exists():
            raise FileNotFoundError(f"data-dir 不存在: {self.research_data_dir}")

        def _is_project_dir(p: Path) -> bool:
            if not p.is_dir():
                return False
            # 排除通用子目录名（这些一般是项目目录内部结构，不是项目本身）
            if p.name in {"raw", "processed", "analyzed"}:
                return False
            # 项目目录判定：存在 complete_research 文件 或者同时存在 raw/processed/analyzed 目录
            has_complete = any(p.glob("*_complete_research_*.json"))
            has_structure = (p / "raw").exists() or (p / "processed").exists() or (p / "analyzed").exists()
            return has_complete or has_structure

        # 确定要加载的项目目录
        if self.project_name:
            # 如果指定了项目名称，只加载该项目的数据
            safe_project_name = self.project_name.replace('/', '_').replace('\\', '_')
            project_dir = self.research_data_dir / safe_project_name
            search_dirs = [project_dir] if project_dir.exists() else []
            self.logger.info(f"加载指定项目数据: {self.project_name}")
        else:
            # 如果 data-dir 本身就是一个项目目录：直接使用它
            if _is_project_dir(self.research_data_dir):
                search_dirs = [self.research_data_dir]
                self.logger.info(f"data-dir 作为项目目录加载: {self.research_data_dir}")
            else:
                # 否则把 data-dir 当成父目录：枚举其下项目目录
                try:
                    search_dirs = [d for d in self.research_data_dir.iterdir() if _is_project_dir(d)]
                except Exception as e:
                    raise RuntimeError(f"无法遍历 data-dir: {self.research_data_dir}, 错误: {e}")

                # 如果没有找到项目目录，则使用根目录（兼容旧格式：raw/processed/analyzed 在根目录）
                if not search_dirs:
                    search_dirs = [self.research_data_dir]
                    self.logger.info("未发现项目子目录，将按旧格式（根目录）加载")
                else:
                    self.logger.info(f"发现 {len(search_dirs)} 个项目目录")
        
        research_data = {
            'complete_research': None,
            'analyzed_data': {},
            'processed_data': {},
            'raw_data': {}
        }
        
        # 从所有项目目录中加载数据
        for search_dir in search_dirs:
            # 加载完整研究报告（从项目目录或根目录）
            # 支持两种文件名格式：带时间戳的旧格式和固定文件名的新格式
            complete_files = list(search_dir.glob("*_complete_research*.json"))
            if not complete_files and search_dir != self.research_data_dir:
                # 如果项目目录中没有，尝试从根目录查找
                complete_files = list(self.research_data_dir.glob(f"{search_dir.name}*_complete_research*.json"))
            
            if complete_files:
                latest_file = max(complete_files, key=lambda x: x.stat().st_mtime)
                try:
                    with open(latest_file, 'r', encoding='utf-8') as f:
                        research_data['complete_research'] = json.load(f)
                    self.logger.info(f"加载完整研究报告: {latest_file.name}")
                except Exception as e:
                    self.logger.warning(f"加载完整研究报告失败: {str(e)}")
            
            # 加载分析数据
            analyzed_dir = search_dir / "analyzed"
            if not analyzed_dir.exists() and search_dir != self.research_data_dir:
                analyzed_dir = self.research_data_dir / "analyzed"
            
            if analyzed_dir.exists():
                for file in analyzed_dir.glob("*.json"):
                    # 如果指定了项目名称，只加载匹配的文件
                    if self.project_name and self.project_name.replace('/', '_') not in file.stem:
                        continue
                    
                    try:
                        with open(file, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            # 从文件名提取数据类型
                            filename = file.stem
                            if 'commits' in filename:
                                research_data['analyzed_data']['commits'] = data
                            elif 'issues' in filename:
                                research_data['analyzed_data']['issues'] = data
                            elif 'pull_requests' in filename or 'pr' in filename:
                                research_data['analyzed_data']['pull_requests'] = data
                            elif 'contributors' in filename:
                                research_data['analyzed_data']['contributors'] = data
                        self.logger.info(f"加载分析数据: {file.name}")
                    except Exception as e:
                        self.logger.warning(f"加载分析数据失败 {file.name}: {str(e)}")
            
            # 加载预处理数据
            processed_dir = search_dir / "processed"
            if not processed_dir.exists() and search_dir != self.research_data_dir:
                processed_dir = self.research_data_dir / "processed"
            
            if processed_dir.exists():
                for file in processed_dir.glob("*.json"):
                    # 如果指定了项目名称，只加载匹配的文件
                    if self.project_name and self.project_name.replace('/', '_') not in file.stem:
                        continue
                    
                    try:
                        with open(file, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            data_type = data.get('data_type', 'unknown')
                            research_data['processed_data'][data_type] = data
                        self.logger.info(f"加载预处理数据: {file.name}")
                    except Exception as e:
                        self.logger.warning(f"加载预处理数据失败 {file.name}: {str(e)}")
            
            # 加载增强的代码质量报告
            # 支持两种文件名格式：带时间戳的旧格式和固定文件名的新格式
            enhanced_quality_files = list(search_dir.glob("*_enhanced_quality*.json"))
            if not enhanced_quality_files and search_dir != self.research_data_dir:
                enhanced_quality_files = list(self.research_data_dir.glob(f"{search_dir.name}*_enhanced_quality*.json"))
            
            if enhanced_quality_files:
                latest_file = max(enhanced_quality_files, key=lambda x: x.stat().st_mtime)
                try:
                    with open(latest_file, 'r', encoding='utf-8') as f:
                        research_data['enhanced_quality'] = json.load(f)
                    self.logger.info(f"加载增强代码质量报告: {latest_file.name}")
                except Exception as e:
                    self.logger.warning(f"加载增强代码质量报告失败: {str(e)}")
            
            # 如果指定了项目名称，只处理第一个匹配的项目
            if self.project_name:
                break
        
        return research_data
    
    def build_evaluation_prompt(self, research_data: Dict[str, Any]) -> str:
        """
        构建评价提示词
        
        Args:
            research_data: 研究数据
            
        Returns:
            str: 评价提示词
        """
        prompt_parts = []
        
        # 项目基本信息
        # 确保 complete_research 不是 None（如果值为 None 则使用空字典）
        complete_research = research_data.get('complete_research') or {}
        if complete_research and isinstance(complete_research, dict):
            repo_name = complete_research.get('repository_name', 'Unknown')
            repo_url = complete_research.get('repository_url', 'Unknown')
            research_date = complete_research.get('research_date', 'Unknown')
            
            prompt_parts.append(f"## 项目基本信息")
            prompt_parts.append(f"- 仓库名称: {repo_name}")
            prompt_parts.append(f"- 仓库URL: {repo_url}")
            prompt_parts.append(f"- 研究日期: {research_date}")
            prompt_parts.append("")
        
        # 数据抓取情况
        scraping_info = complete_research.get('scraping', {}) if complete_research else {}
        if scraping_info:
            prompt_parts.append(f"## 数据抓取情况")
            prompt_parts.append(f"- 状态: {scraping_info.get('status', 'unknown')}")
            prompt_parts.append(f"- 数据类型: {', '.join(scraping_info.get('data_types', []))}")
            data_counts = scraping_info.get('data_counts', {})
            for data_type, count in data_counts.items():
                prompt_parts.append(f"- {data_type}: {count} 条记录")
            prompt_parts.append("")
        
        # 关键指标摘要
        summary = complete_research.get('summary', {}) if complete_research else {}
        if summary:
            prompt_parts.append(f"## 关键指标摘要")
            key_metrics = summary.get('key_metrics', {})
            
            if 'commits' in key_metrics:
                commits_metrics = key_metrics['commits']
                prompt_parts.append(f"### 提交数据 (Commits)")
                prompt_parts.append(f"- 总提交数: {commits_metrics.get('total', 0)}")
                prompt_parts.append(f"- 总代码变更: {commits_metrics.get('total_changes', 0)} 行")
                prompt_parts.append(f"- 净变更: {commits_metrics.get('net_changes', 0)} 行")
            
            if 'issues' in key_metrics:
                issues_metrics = key_metrics['issues']
                prompt_parts.append(f"### Issues数据")
                prompt_parts.append(f"- 总Issue数: {issues_metrics.get('total', 0)}")
                prompt_parts.append(f"- 开放Issue: {issues_metrics.get('open', 0)}")
                prompt_parts.append(f"- 关闭Issue: {issues_metrics.get('closed', 0)}")
                prompt_parts.append(f"- 关闭率: {issues_metrics.get('closure_rate', 0):.2%}")
            
            if 'pull_requests' in key_metrics:
                pr_metrics = key_metrics['pull_requests']
                prompt_parts.append(f"### Pull Requests数据")
                prompt_parts.append(f"- 总PR数: {pr_metrics.get('total', 0)}")
                prompt_parts.append(f"- 已合并: {pr_metrics.get('merged', 0)}")
                prompt_parts.append(f"- 合并率: {pr_metrics.get('merge_rate', 0):.2%}")
            
            if 'contributors' in key_metrics:
                contributors_metrics = key_metrics['contributors']
                prompt_parts.append(f"### 贡献者数据")
                prompt_parts.append(f"- 总贡献者数: {contributors_metrics.get('total', 0)}")
                prompt_parts.append(f"- 总贡献数: {contributors_metrics.get('total_contributions', 0)}")
            
            prompt_parts.append("")
        
        # 详细分析数据
        analyzed_data = research_data.get('analyzed_data', {})
        if analyzed_data:
            prompt_parts.append(f"## 详细分析数据")
            
            # 提交分析
            if 'commits' in analyzed_data:
                commits_analysis = analyzed_data['commits']
                prompt_parts.append(f"### 提交分析")
                summary = commits_analysis.get('summary', {})
                prompt_parts.append(f"- 平均每次提交变更: {summary.get('avg_changes_per_commit', 0):.1f} 行")
                
                time_analysis = commits_analysis.get('time_analysis', {})
                if time_analysis:
                    prompt_parts.append(f"- 首次提交: {time_analysis.get('first_commit', 'N/A')}")
                    prompt_parts.append(f"- 最后提交: {time_analysis.get('last_commit', 'N/A')}")
                    prompt_parts.append(f"- 提交跨度: {time_analysis.get('commit_span_days', 0)} 天")
                
                author_analysis = commits_analysis.get('author_analysis', {})
                if author_analysis:
                    prompt_parts.append(f"- 贡献者数量: {author_analysis.get('total_unique_authors', 0)}")
                    top_authors = author_analysis.get('top_authors', [])
                    if top_authors:
                        prompt_parts.append(f"- 主要贡献者:")
                        for author in top_authors[:3]:
                            prompt_parts.append(f"  * {author.get('name', 'Unknown')}: {author.get('commit_count', 0)} 次提交 ({author.get('percentage', 0):.1f}%)")
                
                change_analysis = commits_analysis.get('change_analysis', {})
                if change_analysis:
                    prompt_parts.append(f"- 平均新增代码: {change_analysis.get('avg_additions', 0):.1f} 行")
                    prompt_parts.append(f"- 平均删除代码: {change_analysis.get('avg_deletions', 0):.1f} 行")
                
                prompt_parts.append("")
            
            # Issues分析
            if 'issues' in analyzed_data:
                issues_analysis = analyzed_data['issues']
                prompt_parts.append(f"### Issues分析")
                summary = issues_analysis.get('summary', {})
                prompt_parts.append(f"- 总Issue数: {summary.get('total_issues', 0)}")
                prompt_parts.append(f"- 开放率: {summary.get('open_issues', 0) / max(summary.get('total_issues', 1), 1):.2%}")
                prompt_parts.append(f"- 平均评论数: {summary.get('avg_comments_per_issue', 0):.1f}")
                prompt_parts.append("")
            
            # Pull Requests分析
            if 'pull_requests' in analyzed_data:
                pr_analysis = analyzed_data['pull_requests']
                prompt_parts.append(f"### Pull Requests分析")
                summary = pr_analysis.get('summary', {})
                prompt_parts.append(f"- 总PR数: {summary.get('total_prs', 0)}")
                prompt_parts.append(f"- 合并率: {summary.get('merge_rate', 0):.2%}")
                prompt_parts.append(f"- 平均变更文件数: {summary.get('avg_changes_per_pr', 0):.1f}")
                prompt_parts.append("")
            
            # 贡献者分析
            if 'contributors' in analyzed_data:
                contributors_analysis = analyzed_data['contributors']
                prompt_parts.append(f"### 贡献者分析")
                summary = contributors_analysis.get('summary', {})
                prompt_parts.append(f"- 总贡献者: {summary.get('total_contributors', 0)}")
                prompt_parts.append(f"- 平均贡献数: {summary.get('avg_contributions_per_contributor', 0):.1f}")
                
                level_analysis = contributors_analysis.get('level_analysis', {})
                if level_analysis:
                    prompt_parts.append(f"- 高贡献者: {level_analysis.get('high_contributors', 0)}")
                    prompt_parts.append(f"- 中贡献者: {level_analysis.get('medium_contributors', 0)}")
                    prompt_parts.append(f"- 低贡献者: {level_analysis.get('low_contributors', 0)}")
                
                top_contributors = contributors_analysis.get('top_contributors', [])
                if top_contributors:
                    prompt_parts.append(f"- Top贡献者:")
                    for contributor in top_contributors[:5]:
                        prompt_parts.append(f"  * {contributor.get('login', 'Unknown')}: {contributor.get('contributions', 0)} 次贡献")
                
                prompt_parts.append("")
        
        # 增强的代码质量分析数据
        enhanced_quality = research_data.get('enhanced_quality')
        if enhanced_quality:
            prompt_parts.append(f"## 增强代码质量分析数据")
            
            # 静态分析
            static_analysis = enhanced_quality.get('static_analysis', {})
            if static_analysis:
                prompt_parts.append(f"### 静态代码分析")
                prompt_parts.append(f"- 平均圈复杂度: {static_analysis.get('avg_cyclomatic_complexity', 0):.2f}")
                prompt_parts.append(f"- 最大圈复杂度: {static_analysis.get('max_cyclomatic_complexity', 0)}")
                prompt_parts.append(f"- 高复杂度函数数: {len(static_analysis.get('high_complexity_functions', []))}")
                prompt_parts.append(f"- 代码重复率: {static_analysis.get('code_duplication_rate', 0):.2%}")
                prompt_parts.append(f"- Lint问题数: {len(static_analysis.get('lint_issues', []))}")
                prompt_parts.append("")
            
            # 测试指标
            testing_metrics = enhanced_quality.get('testing_metrics', {})
            if testing_metrics:
                prompt_parts.append(f"### 测试指标")
                prompt_parts.append(f"- 测试覆盖率: {testing_metrics.get('test_coverage', 0):.2%}")
                prompt_parts.append(f"- 测试文件数: {testing_metrics.get('test_files_count', 0)}")
                prompt_parts.append(f"- 测试函数数: {testing_metrics.get('test_functions_count', 0)}")
                prompt_parts.append(f"- 测试通过率: {testing_metrics.get('test_pass_rate', 0):.2%}")
                prompt_parts.append("")
            
            # 代码评审
            code_review = enhanced_quality.get('code_review', {})
            if code_review:
                prompt_parts.append(f"### 代码评审")
                prompt_parts.append(f"- 可读性评分: {code_review.get('readability_score', 0):.2f}/1.0")
                prompt_parts.append(f"- 命名质量评分: {code_review.get('naming_quality_score', 0):.2f}/1.0")
                prompt_parts.append(f"- 检测到的设计模式: {', '.join(code_review.get('design_patterns', []))}")
                prompt_parts.append(f"- 安全问题数: {len(code_review.get('security_issues', []))}")
                prompt_parts.append(f"- 代码异味数: {len(code_review.get('code_smells', []))}")
                prompt_parts.append("")
            
            # 架构评估
            architecture = enhanced_quality.get('architecture', {})
            if architecture:
                prompt_parts.append(f"### 架构评估")
                prompt_parts.append(f"- 耦合度评分: {architecture.get('coupling_score', 0):.2f}/1.0")
                prompt_parts.append(f"- 内聚性评分: {architecture.get('cohesion_score', 0):.2f}/1.0")
                prompt_parts.append(f"- 分层架构评分: {architecture.get('layer_separation_score', 0):.2f}/1.0")
                prompt_parts.append(f"- 依赖健康度: {architecture.get('dependency_health', 0):.2f}/1.0")
                if architecture.get('outdated_dependencies'):
                    prompt_parts.append(f"- 过时依赖: {', '.join(architecture.get('outdated_dependencies', []))}")
                prompt_parts.append("")
            
            # ISO/IEC 25010
            iso25010 = enhanced_quality.get('iso25010', {})
            if iso25010:
                prompt_parts.append(f"### ISO/IEC 25010 质量模型")
                prompt_parts.append(f"- 功能合法性: {iso25010.get('functional_suitability', 0):.2f}/1.0")
                prompt_parts.append(f"- 性能效率: {iso25010.get('performance_efficiency', 0):.2f}/1.0")
                prompt_parts.append(f"- 兼容性: {iso25010.get('compatibility', 0):.2f}/1.0")
                prompt_parts.append(f"- 易用性: {iso25010.get('usability', 0):.2f}/1.0")
                prompt_parts.append(f"- 可靠性: {iso25010.get('reliability', 0):.2f}/1.0")
                prompt_parts.append(f"- 安全性: {iso25010.get('security', 0):.2f}/1.0")
                prompt_parts.append(f"- 可维护性: {iso25010.get('maintainability', 0):.2f}/1.0")
                prompt_parts.append(f"- 可移植性: {iso25010.get('portability', 0):.2f}/1.0")
                prompt_parts.append("")
            
            # SonarQube质量门禁
            sonarqube = enhanced_quality.get('sonarqube', {})
            if sonarqube:
                prompt_parts.append(f"### SonarQube质量门禁")
                prompt_parts.append(f"- 可靠性评级: {sonarqube.get('reliability_rating', 'N/A')} (Bug数: {sonarqube.get('bugs_count', 0)})")
                prompt_parts.append(f"- 安全性评级: {sonarqube.get('security_rating', 'N/A')} (漏洞数: {sonarqube.get('vulnerabilities_count', 0)})")
                prompt_parts.append(f"- 可维护性评级: {sonarqube.get('maintainability_rating', 'N/A')} (代码异味数: {sonarqube.get('code_smells_count', 0)})")
                prompt_parts.append(f"- 技术债务比率: {sonarqube.get('technical_debt_ratio', 0):.2f}")
                prompt_parts.append("")
            
            # 总体评分
            overall_score = enhanced_quality.get('overall_score', 0)
            prompt_parts.append(f"### 代码质量总体评分")
            prompt_parts.append(f"- 综合评分: {overall_score:.2f}/100.0")
            recommendations = enhanced_quality.get('recommendations', [])
            if recommendations:
                prompt_parts.append(f"- 改进建议:")
                for rec in recommendations[:5]:  # 只显示前5条
                    prompt_parts.append(f"  * {rec}")
            prompt_parts.append("")
        
        # 构建最终提示词
        final_prompt = f"""你是一个资深软件架构师 & 代码审计专家，你善于评估代码质量。你正在对一个GitHub开源项目进行深度的代码质量审计。你的目标是提供一份**辛辣、客观、基于证据**的技术尽职调查报告。
对于项目亮点可以给予肯定，但绝不需要客套和废话，请直接指出代码中的痛点、异味（Code Smells）和潜在风险。

{chr(10).join(prompt_parts)}

请从以下维度对项目进行评价（参考ISO/IEC 25010标准和SonarQube质量门禁模型）：
# Critical Instructions (重要指令):
1. **基于证据 (Evidence-Based):** 任何评价必须引用输入中的具体文件名、代码片段、变量名或目录结构作为支撑。严禁使用"可能"、"大概"等模糊词汇。
2. **拒绝幻觉 (No Hallucination):** 
   - 你无法运行代码，不要编造具体的"圈复杂度数值"或"测试覆盖率百分比"。
   - 请通过**推断**代替**测量**。例如：通过观察测试文件的数量和体积来推断"测试覆盖程度"；通过观察缩进层级来推断"复杂度"。
3. **数据不足处理:** 如果提供的 Input Data 中缺少 Git 记录或 CI 日志，对于"项目活跃度"等章节请注明"缺少元数据，无法评估"，不要瞎编。

---

# Evaluation Dimensions (请严格按照以下维度输出):

## 1. 静态代码分析 (Static Analysis Pattern Recognition)

### 1.1 代码规范与风格 (Linting Patterns)
- **命名品味:** 变量/函数命名是否达意？是否存在 `a`, `temp`, `data` 等毫无意义的命名？(请举例)
- **风格一致性:** 缩进、括号风格、文件结构是否统一？
- **语法隐患:** 是否存在废弃语法或易错的编程习惯？

### 1.2 逻辑复杂度 (Complexity Inference)
- **深层嵌套检测:** 扫描代码中是否存在缩进超过 3-4 层的 `if/for/while` 结构？(识别"箭头型代码")
- **上帝函数:** 是否存在行数过长、职责过多的函数？(引用具体函数名)
- **认知复杂度:** 代码逻辑是否反直觉，难以阅读？

### 1.3 DRY原则 (Code Duplication)
- **复制粘贴痕迹:** 是否存在结构高度相似的代码块？
- **抽象缺失:** 是否有多次出现的硬编码或逻辑，本应被封装为常量或工具函数？

## 2. 自动化测试指标 (Testing & QA)

### 2.1 测试覆盖范围 (Coverage Inference)
- **测试存在感:** 根目录下是否有测试目录？测试文件与源文件的比例感官上如何？
- **核心覆盖:** 关键的业务逻辑代码是否有对应的测试文件？
- **盲区风险:** 哪些核心模块明显缺乏测试保护？

### 2.2 测试代码质量 (Test Quality)
- **断言有效性:** 测试用例是真实的验证逻辑，还是仅仅为了跑通（例如只有 `assert true`）？
- **测试语义:** 测试函数的命名是否清晰描述了测试场景（如 `should_return_error_when_invalid_input`）？
- **Mock滥用:** 是否过度Mock导致测试脱离真实环境？

## 3. 代码评审 (Code Review Deep Dive)

### 3.1 设计模式与抽象
- **模式应用:** 设计模式的使用是恰到好处，还是为了用而用的过度设计？
- **抽象泄露:** 高层抽象是否依赖了底层实现细节？

### 3.2 可读性与文档
- **自解释性:** 代码是否能做到"Self-documenting"？
- **注释质量:** 注释是在解释"Why"（意图），还是在解释"What"（翻译代码）？
- **文档完整性:** README是否包含架构图、快速开始和贡献指南？

### 3.3 安全性 (Security Audit)
- **注入风险:** SQL拼接、命令执行等高危操作检测。
- **敏感信息:** 检查代码中是否有硬编码的 Token、Password 或 API Key。
- **输入清洗:** 核心接口是否对用户输入进行了严格校验？

## 4. 架构与设计评估

### 4.1 耦合度与内聚性
- **模块边界:** 模块间的依赖关系是否清晰？是否存在循环依赖的迹象？
- **改动风险:** 修改一个核心功能，是否看起来会引发连锁反应？

### 4.2 架构分层
- **分层违规:** 业务逻辑是否泄露到了 Controller 层或 View 层？
- **技术选型:** 框架和库的使用是否符合现代开发标准？

### 4.3 依赖健康度
- **过时依赖:** (如果提供了 package.json/pom.xml) 依赖库版本是否明显陈旧？
- **依赖臃肿:** 是否引入了过重且无用的第三方库？

## 5. ISO/IEC 25010 质量模型透视 (Architecture Lens)
*(注：请综合上述分析，从架构特性角度总结)*

- **功能性 (Functional Suitability):** 功能实现是否完整？逻辑是否严密？
- **性能效率 (Performance Efficiency):** 是否存在明显的低效算法（如O(n^2)嵌套循环）或资源泄露风险？
- **兼容性与可移植性:** 是否有硬编码的路径或环境依赖（如 `C:\\Users\\`）？
- **可维护性 (Maintainability):** 新人接手该项目的难度评分。

## 6. SonarQube 质量门禁模拟

### 6.1 可靠性 (Reliability)
- **评级预估 (A-E):** 基于Bug风险和异常处理机制给分。
- **关键缺陷:** 列出最可能导致崩溃的代码点。

### 6.2 安全性 (Security)
- **评级预估 (A-E):** 基于漏洞扫描结果给分。
- **安全热点:** 需要人工二次确认的安全疑点。

### 6.3 可维护性 (Maintainability)
- **评级预估 (A-E):** 基于代码异味和技术债务给分。
- **技术债务:** 重构代码所需的预估精力（高/中/低）。

## 7. 项目运营指标 (如果包含Git/Issue数据)
*(若输入数据不包含Git历史，请跳过此节)*
- **活跃度:** 提交频率、最近更新时间。
- **协作:** 是否是单人维护还是多人协作？
- **Issue管理:** 对Bug的响应速度。

## 8. 总结与建议 (Executive Summary)

- **项目整体评分 (1-10分):** [请给出评分并简述理由]
- **质量门禁结论:** [Pass / Fail / Warning]
- **🔴 Top 3 致命问题:** (必须具体)
- **🟢 Top 3 亮点:** (必须具体)
- **🚀 改进路线图:** 针对架构和代码层面的具体重构建议。

请使用Markdown格式输出，保持专业、严谨、客观。对于每个维度，必须提供**具体的评估结果**和**代码证据**。"""
        
        return final_prompt
    
    def generate_evaluation(self, research_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        生成项目评价
        
        Args:
            research_data: 研究数据，如果为None则自动加载
            
        Returns:
            Dict: 评价结果
        """
        if research_data is None:
            # 从文件系统加载本地分析结果
            self.logger.info("从文件系统加载本地分析结果...")
            research_data = self.load_research_data()
            self.logger.info("本地分析数据加载完成，准备提交给AI分析")
        
        self.logger.info("构建评价提示词（基于本地分析结果）...")
        prompt = self.build_evaluation_prompt(research_data)

        # 从研究数据中提取结构化质量指标，用于后续雷达图展示
        quality_metrics = self._extract_quality_metrics(research_data)
        
        self.logger.info("调用大模型API生成评价...")
        
        try:
            # 调用大模型API
            response = client.chat.completions.create(
                model='Qwen/Qwen3-8B',
                messages=[
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ],
                stream=False,  # 不使用流式输出，直接获取完整结果
                extra_body=extra_body
            )
            
            # 获取评价内容
            evaluation_content = response.choices[0].message.content
            
            # 构建评价结果
            evaluation_result = {
                'evaluation_date': datetime.now().isoformat(),
                'repository_info': research_data.get('complete_research', {}).get('repository_name', 'Unknown'),
                'evaluation_content': evaluation_content,
                'model': 'Qwen/Qwen3-8B',
                'prompt_length': len(prompt),
                'response_length': len(evaluation_content),
                'quality_metrics': quality_metrics,  # 用于雷达图的结构化评分
            }
            
            self.logger.info("评价生成成功")
            return evaluation_result
            
        except Exception as e:
            self.logger.error(f"生成评价失败: {str(e)}")
            raise
    
    def save_evaluation(self, evaluation_result: Dict[str, Any], output_file: Optional[str] = None):
        """
        保存评价结果（JSON和MD格式）
        
        Args:
            evaluation_result: 评价结果
            output_file: 输出文件路径，如果为None则自动生成
        """
        if output_file is None:
            repo_name = evaluation_result.get('repository_info', 'unknown')
            safe_repo_name = repo_name.replace('/', '_').replace('\\', '_')
            
            # 尝试保存到项目子目录（使用固定文件名，不包含时间戳）
            project_dir = self.research_data_dir / safe_repo_name
            if project_dir.exists():
                output_file = str(project_dir / f"{safe_repo_name}_ai_evaluation.json")
            else:
                output_file = f"./results/research_data/{safe_repo_name}_ai_evaluation.json"
        
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            # 1. 保存JSON格式
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(evaluation_result, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"评价结果已保存到: {output_path}")
            
            # 2. 先保存雷达图（可选），以便在MD中引用
            radar_file = output_path.with_name(output_path.stem + "_radar.png")
            radar_generated = self._save_radar_chart(evaluation_result, radar_file)
            
            # 4. 保存MD格式（包含雷达图引用）
            md_file = output_path.with_suffix('.md')
            self._save_markdown_report(evaluation_result, md_file, radar_file if radar_generated else None)
            
            self.logger.info(f"评价Markdown报告已保存到: {md_file}")
            
        except Exception as e:
            self.logger.error(f"保存评价结果失败: {str(e)}")
            raise
    
    def _save_markdown_report(self, evaluation_result: Dict[str, Any], md_file: Path, radar_file: Optional[Path] = None):
        """
        保存Markdown格式的报告
        
        Args:
            evaluation_result: 评价结果
            md_file: Markdown文件路径
            radar_file: 雷达图文件路径（可选）
        """
        evaluation_content = evaluation_result.get('evaluation_content', '')
        repo_name = evaluation_result.get('repository_info', 'Unknown')
        evaluation_date = evaluation_result.get('evaluation_date', 'Unknown')
        model = evaluation_result.get('model', 'Unknown')
        
        # 处理评价日期格式（ISO格式转换为可读格式）
        try:
            eval_date_obj = datetime.fromisoformat(evaluation_date.replace('Z', '+00:00'))
            formatted_date = eval_date_obj.strftime('%Y年%m月%d日 %H:%M:%S')
        except:
            formatted_date = evaluation_date
        
        # 构建雷达图部分（如果存在）
        radar_section = ""
        if radar_file and radar_file.exists():
            # 使用相对路径，确保Markdown文件能正确显示图片
            radar_filename = radar_file.name
            radar_section = f"""
---

## 📈 代码质量雷达图

<div align="center">

![代码质量雷达图]({radar_filename})

*代码质量多维度评估雷达图*

</div>
"""
        
        # 构建Markdown内容
        md_content = f"""# 项目AI评价报告

## 📋 基本信息

| 项目 | 内容 |
|------|------|
| **项目名称** | {repo_name} |
| **评价日期** | {formatted_date} |
| **使用模型** | {model} |
| **提示词长度** | {evaluation_result.get('prompt_length', 0):,} 字符 |
| **响应长度** | {evaluation_result.get('response_length', 0):,} 字符 |

---

## 📊 评价内容

{evaluation_content}
{radar_section}
---

## ℹ️ 报告信息

- **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **报告格式**: Markdown
- **数据来源**: research_data目录

---

<div align="center">

*本报告由AI代码质量评估系统自动生成*

</div>
"""
        
        with open(md_file, 'w', encoding='utf-8') as f:
            f.write(md_content)

    def _extract_quality_metrics(self, research_data: Dict[str, Any]) -> Dict[str, float]:
        """
        从研究数据中提取用于雷达图展示的结构化质量指标（0-1 区间）
        优先使用增强代码质量报告中的 ISO25010 / SonarQube / 测试覆盖率等。
        """
        metrics: Dict[str, float] = {}

        enhanced = research_data.get('enhanced_quality') or {}
        iso = enhanced.get('iso25010') or {}
        sonar = enhanced.get('sonarqube') or {}
        testing = enhanced.get('testing_metrics') or {}

        # ISO/IEC 25010 8 个维度（0-1）
        metrics['功能适用性'] = float(iso.get('functional_suitability') or 0.0)
        metrics['性能效率'] = float(iso.get('performance_efficiency') or 0.0)
        metrics['兼容性'] = float(iso.get('compatibility') or 0.0)
        metrics['易用性'] = float(iso.get('usability') or 0.0)
        metrics['可靠性'] = float(iso.get('reliability') or 0.0)
        metrics['安全性'] = float(iso.get('security') or 0.0)
        metrics['可维护性'] = float(iso.get('maintainability') or 0.0)
        metrics['可移植性'] = float(iso.get('portability') or 0.0)

        # SonarQube 质量门禁评级（A-E -> 0-1）
        def _rating_to_score(r: Optional[str]) -> float:
            if not r:
                return 0.5
            r = r.upper()
            mapping = {'A': 1.0, 'B': 0.8, 'C': 0.6, 'D': 0.4, 'E': 0.2}
            return mapping.get(r, 0.5)

        metrics['可靠性门禁'] = _rating_to_score(sonar.get('reliability_rating'))
        metrics['安全性门禁'] = _rating_to_score(sonar.get('security_rating'))
        metrics['可维护性门禁'] = _rating_to_score(sonar.get('maintainability_rating'))

        # 测试覆盖率（0-1）
        metrics['测试覆盖率'] = float(testing.get('test_coverage') or 0.0)

        # 过滤掉全为 0 的情况，避免画出全零雷达图
        if all(v == 0.0 for v in metrics.values()):
            return {}

        return metrics

    def _save_radar_chart(self, evaluation_result: Dict[str, Any], radar_file: Path) -> bool:
        """
        保存质量评估雷达图（可选，依赖 matplotlib）
        
        Returns:
            bool: 是否成功生成雷达图
        """
        if not HAS_MATPLOTLIB:
            self.logger.warning("matplotlib 未安装，跳过雷达图生成")
            return False

        quality_metrics: Dict[str, float] = evaluation_result.get('quality_metrics') or {}
        # 至少需要 3 个维度才有意义
        if not quality_metrics or len(quality_metrics) < 3:
            self.logger.warning("可用于雷达图的质量指标不足，跳过雷达图生成")
            return False

        labels = list(quality_metrics.keys())
        values = [max(0.0, min(1.0, float(v))) for v in quality_metrics.values()]  # 限制在 [0,1]
        num_vars = len(labels)

        # 计算角度
        angles = [2 * math.pi * i / num_vars for i in range(num_vars)]
        # 闭合多边形
        angles += angles[:1]
        values += values[:1]

        # 绘制雷达图
        fig, ax = plt.subplots(subplot_kw=dict(polar=True))

        ax.plot(angles, values, color='tab:blue', linewidth=2)
        ax.fill(angles, values, color='tab:blue', alpha=0.25)

        # 设置刻度
        angles_deg = [a * 180 / math.pi for a in angles[:-1]]
        ax.set_thetagrids(angles_deg, labels, fontproperties="SimHei")  # 使用中文字体名称（需系统支持）
        ax.set_ylim(0, 1.0)

        ax.set_title("代码质量雷达图", fontproperties="SimHei", pad=20)

        radar_file.parent.mkdir(parents=True, exist_ok=True)
        fig.tight_layout()
        fig.savefig(radar_file, dpi=150)
        plt.close(fig)

        self.logger.info(f"质量评估雷达图已保存到: {radar_file}")
        return True


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='AI项目评价生成器')
    parser.add_argument('--data-dir', type=str, default='./research_data',
                       help='研究数据目录')
    parser.add_argument('--project', type=str, default=None,
                       help='项目名称（可选），如果指定则只加载该项目的数据')
    parser.add_argument('--output', type=str, default=None,
                       help='输出文件路径（可选）')
    
    args = parser.parse_args()
    
    # 创建评价器
    evaluator = AIProjectEvaluator(research_data_dir=args.data_dir, project_name=args.project)
    
    # 生成评价
    print("开始生成项目评价...")
    evaluation_result = evaluator.generate_evaluation()
    
    # 保存评价
    evaluator.save_evaluation(evaluation_result, args.output)
    
    # 打印评价内容
    print("\n" + "=" * 80)
    print("项目评价结果")
    print("=" * 80)
    print(evaluation_result.get('evaluation_content', ''))
    print("=" * 80)


if __name__ == "__main__":
    main()

