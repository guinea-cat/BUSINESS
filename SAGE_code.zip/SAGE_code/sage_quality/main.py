"""
SAGE Code Quality Researcher - 主程序
整合数据抓取、分析、代码质量检查和AI评价的完整流程
"""

import json
import logging
import sys
import argparse
from pathlib import Path
from typing import Optional

# 导入主研究模块
from main_researcher import CodeQualityResearcher

# 导入AI评价模块
try:
    from ai_project_evaluator import AIProjectEvaluator
    HAS_AI_EVALUATOR = True
except ImportError:
    HAS_AI_EVALUATOR = False
    import warnings
    warnings.warn("ai_project_evaluator 模块未找到，AI评价功能将不可用")


def main():
    """主函数 - 整合完整流程"""
    parser = argparse.ArgumentParser(
        description='SAGE Code Quality Researcher - 完整的代码质量研究和评价流程',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
完整流程包括：
  1. Git数据抓取（Commits, Issues, PRs, Contributors）
  2. 数据预处理和清洗
  3. 数据分析和统计
  4. 代码质量检查（自动克隆代码并分析）
  5. AI项目评价（基于所有数据生成评价报告）

示例：
  # 完整流程（包含AI评价）
  python main.py --repo https://github.com/user/repo.git --name repo-name
  
  # 仅数据研究（不生成AI评价）
  python main.py --repo https://github.com/user/repo.git --name repo-name --no-ai
  
  # 仅AI评价（基于已有数据）
  python main.py --evaluate-only --project repo-name
        """
    )
    
    # 数据研究参数
    parser.add_argument('--repo', type=str, help='GitHub仓库URL（用于数据抓取）')
    parser.add_argument('--name', type=str, help='仓库名称（可选，用于目录命名）')
    parser.add_argument('--data-dir', type=str, default='./results/research_data',
                       help='研究数据目录（默认: ./results/research_data）')
    
    # AI评价参数
    parser.add_argument('--evaluate-only', action='store_true',
                       help='仅执行AI评价（基于已有数据，不进行数据抓取）')
    parser.add_argument('--no-ai', action='store_true',
                       help='跳过AI评价（仅执行数据研究和代码质量检查）')
    parser.add_argument('--project', type=str, default=None,
                       help='项目名称（用于AI评价，如果指定则只评价该项目）')
    
    # 其他参数
    parser.add_argument('--delay', type=int, default=1,
                       help='API请求间隔（秒，默认: 1）')
    parser.add_argument('--retries', type=int, default=3,
                       help='最大重试次数（默认: 3）')
    
    args = parser.parse_args()
    
    # 设置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    logger = logging.getLogger(__name__)
    
    try:
        # 场景1: 仅AI评价（基于已有数据）
        if args.evaluate_only:
            if not HAS_AI_EVALUATOR:
                logger.error("AI评价模块未找到，无法执行AI评价")
                return 1
            
            logger.info("=" * 80)
            logger.info("执行AI项目评价（基于已有数据）")
            logger.info("=" * 80)
            
            evaluator = AIProjectEvaluator(
                research_data_dir=args.data_dir,
                project_name=args.project
            )
            
            logger.info("开始生成项目评价...")
            evaluation_result = evaluator.generate_evaluation()
            evaluator.save_evaluation(evaluation_result)
            
            logger.info("=" * 80)
            logger.info("AI评价完成！")
            logger.info("=" * 80)
            logger.info(f"评价结果已保存到: {args.data_dir}")
            
            # 显示评价摘要
            overall_score = evaluation_result.get('quality_metrics', {}).get('overall_score', 'N/A')
            if isinstance(overall_score, (int, float)):
                logger.info(f"项目评分: {overall_score:.2f}/100")
            
            return 0
        
        # 场景2: 完整流程（数据研究 + 可选AI评价）
        if not args.repo:
            parser.print_help()
            logger.error("\n错误: 使用完整流程时必须指定 --repo 参数")
            return 1
        
        logger.info("=" * 80)
        logger.info("SAGE Code Quality Researcher - 完整流程")
        logger.info("=" * 80)
        
        # 步骤1: 数据研究和代码质量检查
        logger.info("\n" + "=" * 80)
        logger.info("步骤1: 数据抓取、预处理、分析和代码质量检查")
        logger.info("=" * 80)
        
        researcher = CodeQualityResearcher(
            output_directory=args.data_dir,
            delay_between_requests=args.delay,
            max_retries=args.retries
        )
        
        # 执行研究
        result = researcher.research_repository(
            repository_url=args.repo,
            repository_name=args.name
        )
        
        logger.info("\n" + "=" * 80)
        logger.info("数据研究完成！")
        logger.info("=" * 80)
        logger.info(f"仓库: {result['repository_name']}")
        logger.info(f"状态: {result.get('status', 'success')}")
        
        # 显示代码质量检查结果
        if 'code_quality' in result:
            quality_info = result['code_quality']
            if quality_info.get('status') == 'success':
                logger.info(f"\n代码质量检查结果:")
                logger.info(f"  总体评分: {quality_info.get('overall_score', 0):.2f}/100")
            elif quality_info.get('status') == 'skipped':
                logger.info(f"\n代码质量检查: 已跳过 ({quality_info.get('reason', 'unknown')})")
        
        # 步骤2: AI评价（可选）
        if not args.no_ai:
            if not HAS_AI_EVALUATOR:
                logger.warning("\nAI评价模块未找到，跳过AI评价步骤")
            else:
                logger.info("\n" + "=" * 80)
                logger.info("步骤2: AI项目评价")
                logger.info("=" * 80)
                
                # 确定项目名称
                project_name = args.name or args.project or result['repository_name']
                safe_project_name = project_name.replace('/', '_').replace('\\', '_')
                
                # 确保本地分析文件已保存（检查关键文件是否存在）
                project_dir = Path(args.data_dir) / safe_project_name
                complete_research_file = project_dir / f"{safe_project_name}_complete_research.json"
                
                if not complete_research_file.exists():
                    logger.warning(f"完整研究报告文件不存在: {complete_research_file}")
                    logger.warning("AI评价将基于可用的数据文件进行")
                else:
                    logger.info(f"确认本地分析文件已保存: {complete_research_file.name}")
                
                evaluator = AIProjectEvaluator(
                    research_data_dir=args.data_dir,
                    project_name=project_name
                )
                
                logger.info("开始生成项目评价（基于本地分析结果）...")
                evaluation_result = evaluator.generate_evaluation()
                evaluator.save_evaluation(evaluation_result)
                
                logger.info("=" * 80)
                logger.info("AI评价完成！")
                logger.info("=" * 80)
                
                # 显示评价摘要
                repo_name = evaluation_result.get('repository_info', 'Unknown')
                logger.info(f"项目: {repo_name}")
                logger.info(f"评价日期: {evaluation_result.get('evaluation_date', 'Unknown')}")
                logger.info(f"使用模型: {evaluation_result.get('model', 'Unknown')}")
                
                # 显示评价内容预览
                evaluation_content = evaluation_result.get('evaluation_content', '')
                if evaluation_content:
                    preview_length = min(500, len(evaluation_content))
                    logger.info(f"\n评价内容预览（前{preview_length}字符）:")
                    logger.info("=" * 80)
                    logger.info(evaluation_content[:preview_length] + ("..." if len(evaluation_content) > preview_length else ""))
                    logger.info("=" * 80)
        else:
            logger.info("\n跳过AI评价步骤（--no-ai 参数）")
        
        logger.info("\n" + "=" * 80)
        logger.info("完整流程执行完成！")
        logger.info("=" * 80)
        logger.info(f"所有结果已保存到: {args.data_dir}")
        
        return 0
        
    except KeyboardInterrupt:
        logger.warning("\n用户中断操作")
        return 130
    except Exception as e:
        logger.error(f"\n执行失败: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())

