"""SAGE代码质量评估系统 - Gradio界面

功能：
- Git数据抓取（Commits, Issues, PRs, Contributors）
- 数据预处理和清洗
- 数据分析和统计
- 代码质量检查（自动克隆代码并分析）
- AI项目评价（基于所有数据生成评价报告）
- 评估按钮+进度显示
- 人性化Markdown报告展示
"""
import gradio as gr
from pathlib import Path
import sys
import logging

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from main_researcher import CodeQualityResearcher
from ai_project_evaluator import AIProjectEvaluator

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# 全局实例
researcher = None
evaluator = None

def get_researcher():
    """获取或创建研究器实例"""
    global researcher
    if researcher is None:
        researcher = CodeQualityResearcher(
            output_directory="./results/research_data",
            delay_between_requests=1,
            max_retries=3
        )
    return researcher

def get_evaluator(project_name=None):
    """获取或创建评价器实例"""
    global evaluator
    evaluator = AIProjectEvaluator(
        research_data_dir="./results/research_data",
        project_name=project_name
    )
    return evaluator


def analyze_repo(url: str, 
                 repo_name: str,
                 enable_ai_eval: bool,
                 progress=gr.Progress()):
    """
    分析仓库代码质量（完整流程）
    
    Args:
        url: GitHub仓库URL
        repo_name: 仓库名称（可选）
        enable_ai_eval: 是否启用AI评价
        progress: Gradio进度对象
        
    Returns:
        (状态文本, Markdown报告)
    """
    # 验证URL
    if not url or not url.strip():
        return "❌ 请输入GitHub仓库URL", ""
    
    url = url.strip()
    if "github.com" not in url.lower():
        return "❌ 请输入有效的GitHub仓库URL", ""
    
    # 进度回调
    def progress_callback(prog, message):
        progress(prog, desc=message)
    
    try:
        status_text = ""
        md_report = ""
        
        # 步骤1: 数据研究和代码质量检查
        progress(0.1, desc="初始化研究器...")
        researcher_instance = get_researcher()
        
        progress(0.2, desc="开始数据抓取...")
        status_text += "📊 步骤1: 数据抓取、预处理、分析和代码质量检查\n\n"
        
        # 执行研究（包含数据抓取、预处理、处理、代码质量检查）
        result = researcher_instance.research_repository(
            repository_url=url,
            repository_name=repo_name
        )
        
        progress(0.6, desc="数据研究完成")
        status_text += f"✅ 仓库: {result.get('repository_name', 'Unknown')}\n"
        status_text += f"✅ 状态: {result.get('status', 'success')}\n\n"
        
        # 显示代码质量检查结果
        if 'code_quality' in result:
            quality_info = result['code_quality']
            if quality_info.get('status') == 'success':
                overall_score = quality_info.get('overall_score', 0)
                status_text += f"✅ 代码质量评分: {overall_score:.2f}/100\n\n"
            elif quality_info.get('status') == 'skipped':
                status_text += f"⚠️ 代码质量检查: 已跳过 ({quality_info.get('reason', 'unknown')})\n\n"
        
        # 步骤2: AI评价（可选）
        if enable_ai_eval:
            progress(0.7, desc="初始化AI评价器...")
            status_text += "🤖 步骤2: AI项目评价\n\n"
            
            # 确定项目名称
            project_name = repo_name or result.get('repository_name', 'unknown')
            safe_project_name = project_name.replace('/', '_').replace('\\', '_')
            
            try:
                progress(0.8, desc="生成AI评价...")
                evaluator_instance = get_evaluator(project_name=project_name)
                evaluation_result = evaluator_instance.generate_evaluation()
                evaluator_instance.save_evaluation(evaluation_result)
                
                progress(0.95, desc="生成报告...")
                
                # 构建完整报告：先添加静态分析，再添加AI评价
                project_dir = Path("./results/research_data") / safe_project_name
                
                # 第一部分：静态分析（代码质量检查结果）
                quality_file = project_dir / f"{safe_project_name}_enhanced_quality.json"
                if quality_file.exists():
                    try:
                        import json
                        with open(quality_file, 'r', encoding='utf-8') as f:
                            quality_data = json.load(f)
                        
                        overall_score = quality_data.get('overall_score', 0)
                        md_report = f"# 📊 代码质量评估报告\n\n"
                        md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                        md_report += f"**评估日期**: {evaluation_result.get('evaluation_date', 'Unknown')}\n\n"
                        md_report += f"**使用模型**: {evaluation_result.get('model', 'Unknown')}\n\n"
                        
                        md_report += f"## 🔍 代码质量检查结果（静态分析）\n\n"
                        md_report += f"**总体评分**: {overall_score:.2f}/100\n\n"
                        
                        if overall_score >= 90:
                            level = "优秀 ⭐⭐⭐⭐⭐"
                        elif overall_score >= 75:
                            level = "良好 ⭐⭐⭐⭐"
                        elif overall_score >= 60:
                            level = "中等 ⭐⭐⭐"
                        elif overall_score >= 40:
                            level = "一般 ⭐⭐"
                        else:
                            level = "较差 ⭐"
                        md_report += f"**质量等级**: {level}\n\n"
                        
                        # 添加详细指标
                        static_analysis = quality_data.get('static_analysis', {})
                        testing_metrics = quality_data.get('testing_metrics', {})
                        code_review = quality_data.get('code_review', {})
                        architecture = quality_data.get('architecture', {})
                        
                        if static_analysis:
                            md_report += f"### 静态分析\n\n"
                            md_report += f"- 平均圈复杂度: {static_analysis.get('avg_cyclomatic_complexity', 0):.2f}\n"
                            md_report += f"- 代码重复率: {static_analysis.get('code_duplication_rate', 0):.2f}%\n"
                            md_report += f"- Lint问题数: {len(static_analysis.get('lint_issues', []))}\n\n"
                        
                        if testing_metrics:
                            md_report += f"### 测试指标\n\n"
                            md_report += f"- 测试覆盖率: {testing_metrics.get('test_coverage', 0):.2f}%\n"
                            md_report += f"- 测试通过率: {testing_metrics.get('test_pass_rate', 0):.2f}%\n\n"
                        
                        if code_review:
                            md_report += f"### 代码评审\n\n"
                            md_report += f"- 可读性评分: {code_review.get('readability_score', 0):.2f}/100\n"
                            md_report += f"- 命名质量: {code_review.get('naming_quality_score', 0):.2f}/100\n\n"
                        
                        if architecture:
                            md_report += f"### 架构评估\n\n"
                            md_report += f"- 耦合度评分: {architecture.get('coupling_score', 0):.2f}/100\n"
                            md_report += f"- 内聚度评分: {architecture.get('cohesion_score', 0):.2f}/100\n\n"
                        
                    except Exception as e:
                        logger.warning(f"无法读取质量报告文件: {str(e)}")
                        md_report = f"# 📊 代码质量评估报告\n\n"
                        md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                else:
                    # 如果没有质量报告，至少显示基本信息
                    md_report = f"# 📊 代码质量评估报告\n\n"
                    md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                    md_report += f"**评估日期**: {evaluation_result.get('evaluation_date', 'Unknown')}\n\n"
                    md_report += f"**使用模型**: {evaluation_result.get('model', 'Unknown')}\n\n"
                    md_report += f"⚠️ 代码质量检查报告未找到\n\n"
                
                # 第二部分：AI评价内容
                md_report += f"\n---\n\n"
                md_report += f"## 🤖 AI项目评价\n\n"
                
                # 尝试读取保存的Markdown文件中的AI评价部分
                md_file = project_dir / f"{safe_project_name}_ai_evaluation.md"
                if md_file.exists():
                    try:
                        with open(md_file, 'r', encoding='utf-8') as f:
                            ai_md_content = f.read()
                        # 提取AI评价内容部分（跳过基本信息部分）
                        if "## 📊 评价内容" in ai_md_content:
                            ai_section = ai_md_content.split("## 📊 评价内容")[1]
                            md_report += ai_section
                        elif "## 📝 AI评价内容" in ai_md_content:
                            ai_section = ai_md_content.split("## 📝 AI评价内容")[1]
                            md_report += ai_section
                        else:
                            # 如果找不到特定标记，使用整个文件内容
                            md_report += ai_md_content
                    except Exception as e:
                        logger.warning(f"无法读取AI评价Markdown文件: {str(e)}")
                        # 降级到使用evaluation_result中的内容
                        evaluation_content = evaluation_result.get('evaluation_content', '')
                        md_report += evaluation_content
                else:
                    # 如果文件不存在，使用evaluation_result中的内容
                    evaluation_content = evaluation_result.get('evaluation_content', '')
                    md_report += evaluation_content
                
                status_text += f"✅ AI评价完成！\n"
                status_text += f"✅ 评价结果已保存到: {project_dir}\n\n"
                
            except Exception as e:
                status_text += f"⚠️ AI评价失败: {str(e)}\n"
                status_text += f"💡 将仅显示本地分析结果\n\n"
                enable_ai_eval = False  # 降级到仅本地分析
            else:
                # 仅显示本地分析结果
                project_name = repo_name or result.get('repository_name', 'unknown')
                safe_project_name = project_name.replace('/', '_').replace('\\', '_')
                project_dir = Path("./results/research_data") / safe_project_name
                
                # 尝试读取增强代码质量报告
                quality_file = project_dir / f"{safe_project_name}_enhanced_quality.json"
                if quality_file.exists():
                    try:
                        import json
                        with open(quality_file, 'r', encoding='utf-8') as f:
                            quality_data = json.load(f)
                        
                        overall_score = quality_data.get('overall_score', 0)
                        md_report = f"# 📊 代码质量分析报告\n\n"
                        md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                        md_report += f"**分析日期**: {result.get('research_date', 'Unknown')}\n\n"
                        md_report += f"## 🔍 代码质量检查结果\n\n"
                        md_report += f"**总体评分**: {overall_score:.2f}/100\n\n"
                        
                        if overall_score >= 90:
                            level = "优秀 ⭐⭐⭐⭐⭐"
                        elif overall_score >= 75:
                            level = "良好 ⭐⭐⭐⭐"
                        elif overall_score >= 60:
                            level = "中等 ⭐⭐⭐"
                        elif overall_score >= 40:
                            level = "一般 ⭐⭐"
                        else:
                            level = "较差 ⭐"
                        md_report += f"**质量等级**: {level}\n\n"
                        
                        # 添加详细指标
                        static_analysis = quality_data.get('static_analysis', {})
                        testing_metrics = quality_data.get('testing_metrics', {})
                        code_review = quality_data.get('code_review', {})
                        architecture = quality_data.get('architecture', {})
                        
                        if static_analysis:
                            md_report += f"### 静态分析\n\n"
                            md_report += f"- 平均圈复杂度: {static_analysis.get('avg_cyclomatic_complexity', 0):.2f}\n"
                            md_report += f"- 代码重复率: {static_analysis.get('code_duplication_rate', 0):.2f}%\n"
                            md_report += f"- Lint问题数: {len(static_analysis.get('lint_issues', []))}\n\n"
                        
                        if testing_metrics:
                            md_report += f"### 测试指标\n\n"
                            md_report += f"- 测试覆盖率: {testing_metrics.get('test_coverage', 0):.2f}%\n"
                            md_report += f"- 测试通过率: {testing_metrics.get('test_pass_rate', 0):.2f}%\n\n"
                        
                        if code_review:
                            md_report += f"### 代码评审\n\n"
                            md_report += f"- 可读性评分: {code_review.get('readability_score', 0):.2f}/100\n"
                            md_report += f"- 命名质量: {code_review.get('naming_quality_score', 0):.2f}/100\n\n"
                        
                        if architecture:
                            md_report += f"### 架构评估\n\n"
                            md_report += f"- 耦合度评分: {architecture.get('coupling_score', 0):.2f}/100\n"
                            md_report += f"- 内聚度评分: {architecture.get('cohesion_score', 0):.2f}/100\n\n"
                        
                    except Exception as e:
                        md_report = f"# 📊 代码质量分析报告\n\n"
                        md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                        md_report += f"**错误**: 无法读取质量报告文件: {str(e)}\n\n"
                else:
                    # 生成基础报告
                    md_report = f"# 📊 代码质量分析报告\n\n"
                    md_report += f"**项目**: {result.get('repository_name', 'Unknown')}\n\n"
                    md_report += f"**研究日期**: {result.get('research_date', 'Unknown')}\n\n"
                    
                    # 数据抓取情况
                    scraping = result.get('scraping', {})
                    if scraping:
                        md_report += f"## 📥 数据抓取情况\n\n"
                        md_report += f"- 状态: {scraping.get('status', 'unknown')}\n"
                        md_report += f"- 数据类型: {', '.join(scraping.get('data_types', []))}\n"
                        data_counts = scraping.get('data_counts', {})
                        for data_type, count in data_counts.items():
                            md_report += f"- {data_type}: {count} 条记录\n"
                        md_report += "\n"
                    
                    # 代码质量检查结果
                    if 'code_quality' in result:
                        quality_info = result['code_quality']
                        if quality_info.get('status') == 'success':
                            overall_score = quality_info.get('overall_score', 0)
                            md_report += f"## 🔍 代码质量检查结果\n\n"
                            md_report += f"**总体评分**: {overall_score:.2f}/100\n\n"
                    
                    # 关键指标摘要
                    summary = result.get('summary', {})
                    if summary:
                        md_report += f"## 📈 关键指标摘要\n\n"
                        key_metrics = summary.get('key_metrics', {})
                        for metric_type, metrics in key_metrics.items():
                            md_report += f"### {metric_type}\n\n"
                            for key, value in metrics.items():
                                if isinstance(value, float):
                                    md_report += f"- {key}: {value:.2f}\n"
                                else:
                                    md_report += f"- {key}: {value}\n"
                            md_report += "\n"
                
                status_text += f"✅ 本地分析完成！\n"
                status_text += f"💡 提示: 启用AI评价可获得更详细的评估报告\n\n"
        
        progress(1.0, desc="完成")
        return status_text, md_report
        
    except ValueError as e:
        return f"❌ URL解析错误: {str(e)}", ""
    except Exception as e:
        return f"❌ 分析失败: {str(e)}", ""


# 创建Gradio界面
def create_app():
    """创建Gradio应用"""
    
    custom_css = """
    .status-display {
        font-size: 1em !important;
        padding: 15px;
        background: #f3f4f6;
        border-radius: 8px;
        margin: 10px 0;
    }
    """
    
    with gr.Blocks(title="SAGE代码质量评估系统") as app:
        
        # 标题
        gr.Markdown("""
        # 🔍 SAGE代码质量评估系统
        
        为AI黑客松评委提供自动化的代码质量评估工具，支持完整的代码质量分析流程：
        
        - **📥 数据抓取**：Git Commits, Issues, Pull Requests, Contributors
        - **🔄 数据预处理**：清洗、转换、验证数据
        - **📊 数据分析**：统计分析、趋势分析、关键指标计算
        - **🔍 代码质量检查**：静态分析、测试覆盖、代码评审、架构评估
        - **🤖 AI项目评价**：基于所有数据生成专业的评价报告
        """)
        
        with gr.Row():
            # 左侧：输入区域
            with gr.Column(scale=1):
                # URL输入
                url_input = gr.Textbox(
                    label="GitHub仓库URL",
                    placeholder="https://github.com/owner/repo",
                    info="输入公开的GitHub仓库地址",
                )
                
                # 仓库名称（可选）
                repo_name_input = gr.Textbox(
                    label="仓库名称（可选）",
                    placeholder="repo-name",
                    info="如果不填写，将从URL自动提取",
                )
                
                # AI评价开关
                with gr.Accordion("🤖 AI评价设置", open=True):
                    enable_ai_eval = gr.Checkbox(
                        label="启用AI评价",
                        value=True,
                        info="基于所有分析数据生成AI评价报告（需要ModelScope API）"
                    )
                
                # 分析按钮
                analyze_btn = gr.Button("🚀 开始评估", variant="primary", size="lg")
                
                # 状态显示
                with gr.Group():
                    gr.Markdown("### 📊 执行状态")
                    status_output = gr.Markdown(
                        value="等待开始评估...",
                        elem_classes=["status-display"]
                    )
            
            # 右侧：报告区域
            with gr.Column(scale=2):
                gr.Markdown("### 📝 详细报告")
                report_output = gr.Markdown(
                    value="输入GitHub仓库URL并点击「开始评估」查看详细分析报告。",
                )
        
        # 示例URL
        gr.Markdown("""
        ---
        ### 💡 示例仓库（点击填充）
        """)
        examples = gr.Examples(
            examples=[
                ["https://github.com/langchain-ai/langchain"],
                ["https://github.com/openai/openai-python"],
                ["https://github.com/microsoft/autogen"],
                ["https://github.com/run-llama/llama_index"],
            ],
            inputs=[url_input],
            label="热门AI项目",
            cache_examples=False,
        )
        
        # 使用说明
        with gr.Accordion("📖 使用说明", open=False):
            gr.Markdown("""
            ### 评估流程说明
            
            #### 步骤1: 数据抓取
            - 抓取GitHub仓库的Commits、Issues、Pull Requests、Contributors数据
            - 数据保存到 `results/research_data/<项目名>/raw/` 目录
            
            #### 步骤2: 数据预处理
            - 清洗和转换原始数据
            - 验证数据完整性
            - 数据保存到 `results/research_data/<项目名>/processed/` 目录
            
            #### 步骤3: 数据分析
            - 统计分析、趋势分析
            - 计算关键指标
            - 数据保存到 `results/research_data/<项目名>/analyzed/` 目录
            
            #### 步骤4: 代码质量检查
            - 自动克隆代码到本地 `repo/` 目录
            - 执行静态分析、测试覆盖检查
            - 代码评审、架构评估
            - 生成代码质量报告（100分制）
            
            #### 步骤5: AI评价（可选）
            - 基于所有分析数据生成AI评价报告
            - 使用ModelScope API调用大模型
            - 生成JSON和Markdown格式的报告
            
            ### 输出文件
            
            所有结果保存在 `results/research_data/<项目名>/` 目录：
            - `*_complete_research.json` - 完整研究结果
            - `*_enhanced_quality.json` - 代码质量报告
            - `*_ai_evaluation.json` - AI评价结果（JSON）
            - `*_ai_evaluation.md` - AI评价报告（Markdown）
            - `*_ai_evaluation_radar.png` - 质量雷达图（如果启用）
            
            ### 注意事项
            
            - 本工具仅供参考，评估结果应结合人工判断使用
            - 支持公开的GitHub仓库，私有仓库需提供访问Token
            - 评估时间取决于仓库大小，通常需要1-5分钟
            - 代码质量检查需要自动克隆代码，确保有足够的磁盘空间
            - AI评价需要ModelScope API访问权限
            """)
        
        # 事件绑定
        analyze_btn.click(
            fn=analyze_repo,
            inputs=[url_input, repo_name_input, enable_ai_eval],
            outputs=[status_output, report_output],
            show_progress="full",
        )
        
        # 回车触发分析
        url_input.submit(
            fn=analyze_repo,
            inputs=[url_input, repo_name_input, enable_ai_eval],
            outputs=[status_output, report_output],
            show_progress="full",
        )
    
    return app, custom_css


# 主入口
if __name__ == "__main__":
    app, css = create_app()
    app.launch(
        server_name="0.0.0.0",
        server_port=7863,
        share=False,
        show_error=True,
        enable_queue=True,  # 启用队列以支持进度跟踪
    )
