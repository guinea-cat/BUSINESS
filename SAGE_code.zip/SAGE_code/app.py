"""SAGE统一评估系统 - 整合版

整合三个评估系统到一个统一的Gradio界面：
- 创新性与社会价值评估
- 代码质量评估
- 商业计划书分析
"""
import gradio as gr
from pathlib import Path
import sys
import traceback
import logging
from datetime import datetime
import re
import os

# 添加项目路径
base_dir = Path(__file__).parent
sys.path.insert(0, str(base_dir))

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 导入三个系统的应用
creativity_path = base_dir / "sage_creativity"
quality_path = base_dir / "sage_quality"
business_path = base_dir / "sage_business"

# 导入创新性与社会价值评估系统
CREATIVITY_AVAILABLE = False
creativity_analyze_repo = None
reset_innovation_weights = None
reset_social_value_weights = None
INNOVATION_WEIGHTS = {}
SOCIAL_VALUE_WEIGHTS = {}

try:
    if creativity_path.exists():
        creativity_sys_path = str(creativity_path)
        if creativity_sys_path not in sys.path:
            sys.path.insert(0, creativity_sys_path)
        # 直接导入函数
        import importlib.util
        spec = importlib.util.spec_from_file_location("creativity_app", creativity_path / "app.py")
        creativity_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(creativity_module)
        
        creativity_analyze_repo = creativity_module.analyze_repo
        reset_innovation_weights = creativity_module.reset_innovation_weights
        reset_social_value_weights = creativity_module.reset_social_value_weights
        
        # 导入配置
        config_spec = importlib.util.spec_from_file_location("creativity_config", creativity_path / "config.py")
        config_module = importlib.util.module_from_spec(config_spec)
        config_spec.loader.exec_module(config_module)
        INNOVATION_WEIGHTS = config_module.INNOVATION_WEIGHTS
        SOCIAL_VALUE_WEIGHTS = config_module.SOCIAL_VALUE_WEIGHTS
        
        CREATIVITY_AVAILABLE = True
        logger.info("✅ 创新性与社会价值评估系统加载成功")
    else:
        logger.warning("⚠️ sage_creativity 文件夹不存在")
except Exception as e:
    logger.warning(f"⚠️ 创新性与社会价值评估系统加载失败: {str(e)}")
    traceback.print_exc()

# 导入代码质量评估系统
QUALITY_AVAILABLE = False
quality_analyze_repo = None

try:
    if quality_path.exists():
        quality_sys_path = str(quality_path)
        if quality_sys_path not in sys.path:
            sys.path.insert(0, quality_sys_path)
        # 直接导入函数
        import importlib.util
        spec = importlib.util.spec_from_file_location("quality_app", quality_path / "app.py")
        quality_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(quality_module)
        
        quality_analyze_repo = quality_module.analyze_repo
        QUALITY_AVAILABLE = True
        logger.info("✅ 代码质量评估系统加载成功")
    else:
        logger.warning("⚠️ sage_quality 文件夹不存在")
except Exception as e:
    logger.warning(f"⚠️ 代码质量评估系统加载失败: {str(e)}")
    traceback.print_exc()

# 导入商业计划书分析系统
BUSINESS_AVAILABLE = False
business_run_analysis = None

try:
    if business_path.exists():
        business_sys_path = str(business_path)
        if business_sys_path not in sys.path:
            sys.path.insert(0, business_sys_path)
        # 直接导入函数
        import importlib.util
        spec = importlib.util.spec_from_file_location("business_app", business_path / "app.py")
        business_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(business_module)
        
        business_run_analysis = business_module.run_analysis
        BUSINESS_AVAILABLE = True
        logger.info("✅ 商业计划书分析系统加载成功")
    else:
        logger.warning("⚠️ sage_business 文件夹不存在")
except Exception as e:
    logger.warning(f"⚠️ 商业计划书分析系统加载失败: {str(e)}")
    traceback.print_exc()


# 创建报告保存目录
REPORTS_DIR = base_dir / "reports"
REPORTS_DIR.mkdir(exist_ok=True)
logger.info(f"报告保存目录: {REPORTS_DIR}")


def extract_repo_name(url: str) -> str:
    """从GitHub URL中提取仓库名称"""
    if not url:
        return "unknown"
    # 匹配 github.com/owner/repo 格式
    match = re.search(r"github\.com/([^/]+)/([^/?#]+)", url)
    if match:
        return f"{match.group(1)}_{match.group(2)}"
    # 如果匹配失败，尝试从URL中提取任何可用的名称
    parts = url.strip("/").split("/")
    if len(parts) >= 2:
        return "_".join(parts[-2:])
    return "unknown_repo"


def save_markdown_report(markdown_content: str, system_name: str, project_name: str = None, url: str = None) -> str:
    """
    保存Markdown报告到本地文件
    
    Args:
        markdown_content: Markdown内容
        system_name: 系统名称（creativity/quality/business）
        project_name: 项目名称（可选）
        url: GitHub URL（可选，用于提取项目名）
    
    Returns:
        保存的文件路径，如果失败则返回错误信息
    """
    try:
        if not markdown_content or not markdown_content.strip():
            logger.warning("Markdown内容为空，跳过保存")
            return None
        
        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if project_name:
            safe_name = re.sub(r'[^\w\-_\.]', '_', project_name)
        elif url:
            safe_name = extract_repo_name(url)
        else:
            safe_name = "unknown_project"
        
        filename = f"{system_name}_{safe_name}_{timestamp}.md"
        filepath = REPORTS_DIR / filename
        
        # 保存文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
        
        logger.info(f"报告已保存: {filepath}")
        return str(filepath)
    except Exception as e:
        logger.error(f"保存报告失败: {str(e)}")
        traceback.print_exc()
        return None


def wrap_creativity_analyze(*args, **kwargs):
    """包装创新性评估函数，添加保存功能"""
    result = creativity_analyze_repo(*args, **kwargs)
    if len(result) >= 4:
        score_text, level_text, summary_text, md_report = result[:4]
        # 从第一个参数（url）提取项目名
        url = args[0] if args else ""
        saved_path = save_markdown_report(md_report, "creativity", url=url)
        if saved_path:
            # 在报告末尾添加保存提示
            save_notice = f"\n\n---\n\n💾 **报告已保存到**: `{saved_path}`"
            md_report = md_report + save_notice
            return (score_text, level_text, summary_text, md_report)
    return result


def wrap_quality_analyze(*args, **kwargs):
    """包装代码质量评估函数，添加保存功能"""
    result = quality_analyze_repo(*args, **kwargs)
    if len(result) >= 2:
        status_text, md_report = result[:2]
        # 从第一个参数（url）提取项目名
        url = args[0] if args else ""
        saved_path = save_markdown_report(md_report, "quality", url=url)
        if saved_path:
            # 在状态文本中添加保存提示
            save_notice = f"\n\n💾 **报告已保存到**: `{saved_path}`"
            status_text = status_text + save_notice
            # 在报告末尾也添加保存提示
            md_report = md_report + f"\n\n---\n\n💾 **报告已保存到**: `{saved_path}`"
            return (status_text, md_report)
    return result


def wrap_business_analyze(*args, **kwargs):
    """包装商业计划书分析函数，添加保存功能"""
    # business_run_analysis 使用 yield，需要特殊处理
    # 我们需要拦截生成器的输出，在最终报告时保存
    file_obj = args[0] if args else None
    project_name = None
    if file_obj and hasattr(file_obj, 'name'):
        project_name = Path(file_obj.name).stem
    
    for result in business_run_analysis(*args, **kwargs):
        if isinstance(result, tuple) and len(result) >= 2:
            md_report, json_data = result[0], result[1]
            # 检查是否是最终报告（不是中间进度提示）
            # 最终报告通常以 "# 📊" 开头，或者包含完整的分析内容
            is_final_report = (
                md_report and 
                isinstance(md_report, str) and
                not md_report.startswith("## 📄") and 
                not md_report.startswith("## 🖼️") and 
                not md_report.startswith("## 🎯") and 
                not md_report.startswith("## 🧠") and
                not md_report.startswith("# ⚠️") and
                (md_report.startswith("# 📊") or len(md_report) > 500)  # 最终报告通常较长
            )
            
            if is_final_report:
                # 保存最终报告
                saved_path = save_markdown_report(md_report, "business", project_name=project_name)
                if saved_path:
                    # 在报告末尾添加保存提示
                    save_notice = f"\n\n---\n\n💾 **报告已保存到**: `{saved_path}`"
                    md_report = md_report + save_notice
                    yield (md_report, json_data)
                else:
                    yield result
            else:
                # 中间进度提示，直接yield
                yield result
        else:
            yield result


def create_unified_app():
    """创建统一的Gradio应用，整合三个系统"""
    
    custom_css = """
    .main-header {
        text-align: center;
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .system-card {
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
        background: #f9fafb;
    }
    .score-display {
        font-size: 2.5em !important;
        text-align: center;
        padding: 20px;
    }
    .level-display {
        font-size: 1.5em !important;
        text-align: center;
        color: #2563eb;
    }
    .summary-display {
        font-size: 1em !important;
        text-align: center;
        color: #4b5563;
        font-style: italic;
        padding: 10px;
        background: #f3f4f6;
        border-radius: 8px;
        margin-top: 10px;
    }
    .status-display {
        font-size: 1em !important;
        padding: 15px;
        background: #f3f4f6;
        border-radius: 8px;
        margin: 10px 0;
    }
    """
    
    with gr.Blocks(title="SAGE统一评估系统", theme=gr.themes.Soft(), css=custom_css) as app:
        
        # 主标题
        gr.Markdown("""
        <div class="main-header">
        <h1>🎯 SAGE 统一评估系统</h1>
        <p>Smart AI Grading Engine - 让AI项目评估更智能、更专业、更全面</p>
        </div>
        """)
        
        # 系统介绍
        gr.Markdown("""
        ## 📋 系统概览
        
        SAGE提供三个专业的评估系统，帮助评委全面评估AI项目：
        
        - **🔬 创新性与社会价值评估**：评估项目的创新性和社会价值（6+7维度）
        - **🔍 代码质量评估**：评估代码质量和项目整体质量（静态分析+AI评价）
        - **💼 商业计划书分析**：分析商业计划书，生成VC视角评估报告
        """)
        
        # 使用标签页整合三个系统
        with gr.Tabs() as tabs:
            
            # 标签页1：创新性与社会价值评估
            if CREATIVITY_AVAILABLE:
                with gr.Tab("🔬 创新性与社会价值评估"):
                    try:
                        
                        with gr.Row():
                            with gr.Column(scale=1):
                                url_input = gr.Textbox(
                                    label="GitHub仓库URL",
                                    placeholder="https://github.com/owner/repo",
                                    info="输入公开的GitHub仓库地址",
                                )
                                
                                eval_type = gr.Radio(
                                    choices=[
                                        ("仅创新性评估", "innovation"),
                                        ("仅社会价值评估", "social_value"),
                                        ("同时评估两者", "both")
                                    ],
                                    value="innovation",
                                    label="评估类型",
                                )
                                
                                with gr.Accordion("📎 补充信息（可选）", open=False):
                                    demo_url = gr.Textbox(label="Demo/官网链接", placeholder="https://example.com/demo")
                                    blog_url = gr.Textbox(label="技术博客/设计文档", placeholder="https://blog.example.com")
                                    paper_url = gr.Textbox(label="相关论文链接", placeholder="https://arxiv.org/abs/xxxx")
                                
                                with gr.Accordion("⚙️ 创新性权重配置", open=False):
                                    weight_tech_impl = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["tech_implementation"], step=1, label="技术选型与实现")
                                    weight_arch_design = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["architecture_design"], step=1, label="系统架构与设计")
                                    weight_eng_sustain = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["engineering_sustainability"], step=1, label="工程化与可持续性")
                                    weight_problem_value = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["problem_value"], step=1, label="问题定义与价值")
                                    weight_scenario_innov = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["scenario_innovation"], step=1, label="场景创新性 ⭐")
                                    weight_market_fit = gr.Slider(minimum=0, maximum=100, value=INNOVATION_WEIGHTS["market_fit"], step=1, label="市场与生态契合度")
                                    reset_innovation_btn = gr.Button("🔄 重置创新性权重", size="sm")
                                
                                with gr.Accordion("⚙️ 社会价值权重配置", open=False):
                                    weight_ethics_redline = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["ethics_redline"], step=1, label="伦理红线检查")
                                    weight_privacy = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["privacy_protection"], step=1, label="隐私与数据保护")
                                    weight_fairness = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["algorithm_fairness"], step=1, label="算法公平性意识")
                                    weight_social_impact = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["social_impact"], step=1, label="社会影响深度")
                                    weight_environmental = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["environmental_friendliness"], step=1, label="环境可持续性")
                                    weight_charity = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["charity_orientation"], step=1, label="公益普惠导向")
                                    weight_long_term = gr.Slider(minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["long_term_vision"], step=1, label="长期愿景与变革潜力")
                                    reset_social_btn = gr.Button("🔄 重置社会价值权重", size="sm")
                                
                                with gr.Accordion("🤖 AI报告优化", open=True):
                                    use_deepseek = gr.Checkbox(label="启用DeepSeek模型优化报告", value=True)
                                
                                analyze_btn = gr.Button("🚀 开始评估", variant="primary", size="lg")
                                
                                with gr.Group():
                                    gr.Markdown("### 📊 评估结果")
                                    score_output = gr.Markdown(value="等待评估...", elem_classes=["score-display"])
                                    level_output = gr.Markdown(value="", elem_classes=["level-display"])
                                    summary_output = gr.Markdown(value="", elem_classes=["summary-display"])
                            
                            with gr.Column(scale=2):
                                gr.Markdown("### 📝 详细报告")
                                report_output = gr.Markdown(value="输入GitHub仓库URL并点击「开始评估」查看详细分析报告。")
                        
                        analyze_btn.click(
                            fn=wrap_creativity_analyze,
                            inputs=[url_input, demo_url, blog_url, paper_url, eval_type,
                                    weight_tech_impl, weight_arch_design, weight_eng_sustain,
                                    weight_problem_value, weight_scenario_innov, weight_market_fit,
                                    weight_ethics_redline, weight_privacy, weight_fairness,
                                    weight_social_impact, weight_environmental, weight_charity, weight_long_term,
                                    use_deepseek],
                            outputs=[score_output, level_output, summary_output, report_output],
                            show_progress="full",
                        )
                        
                        reset_innovation_btn.click(
                            fn=reset_innovation_weights,
                            outputs=[weight_tech_impl, weight_arch_design, weight_eng_sustain,
                                     weight_problem_value, weight_scenario_innov, weight_market_fit],
                        )
                        
                        reset_social_btn.click(
                            fn=reset_social_value_weights,
                            outputs=[weight_ethics_redline, weight_privacy, weight_fairness,
                                     weight_social_impact, weight_environmental, weight_charity, weight_long_term],
                        )
                        
                        url_input.submit(
                            fn=wrap_creativity_analyze,
                            inputs=[url_input, demo_url, blog_url, paper_url, eval_type,
                                    weight_tech_impl, weight_arch_design, weight_eng_sustain,
                                    weight_problem_value, weight_scenario_innov, weight_market_fit,
                                    weight_ethics_redline, weight_privacy, weight_fairness,
                                    weight_social_impact, weight_environmental, weight_charity, weight_long_term,
                                    use_deepseek],
                            outputs=[score_output, level_output, summary_output, report_output],
                            show_progress="full",
                        )
                    except Exception as e:
                        logger.error(f"创建创新性评估界面失败: {str(e)}")
                        traceback.print_exc()
                        gr.Markdown(f"## ❌ 系统加载失败\n\n错误信息: {str(e)}\n\n请检查日志获取详细信息。")
            else:
                with gr.Tab("🔬 创新性与社会价值评估"):
                    gr.Markdown("## ⚠️ 系统不可用\n\n创新性与社会价值评估系统加载失败，请检查依赖和配置。")
            
            # 标签页2：代码质量评估
            if QUALITY_AVAILABLE:
                with gr.Tab("🔍 代码质量评估"):
                    try:
                        with gr.Row():
                            with gr.Column(scale=1):
                                quality_url_input = gr.Textbox(
                                    label="GitHub仓库URL",
                                    placeholder="https://github.com/owner/repo",
                                    info="输入公开的GitHub仓库地址",
                                )
                                
                                quality_repo_name_input = gr.Textbox(
                                    label="仓库名称（可选）",
                                    placeholder="repo-name",
                                    info="如果不填写，将从URL自动提取",
                                )
                                
                                with gr.Accordion("🤖 AI评价设置", open=True):
                                    enable_ai_eval = gr.Checkbox(
                                        label="启用AI评价",
                                        value=True,
                                        info="基于所有分析数据生成AI评价报告（需要ModelScope API）"
                                    )
                                
                                quality_analyze_btn = gr.Button("🚀 开始评估", variant="primary", size="lg")
                                
                                with gr.Group():
                                    gr.Markdown("### 📊 执行状态")
                                    quality_status_output = gr.Markdown(
                                        value="等待开始评估...",
                                        elem_classes=["status-display"]
                                    )
                            
                            with gr.Column(scale=2):
                                gr.Markdown("### 📝 详细报告")
                                quality_report_output = gr.Markdown(
                                    value="输入GitHub仓库URL并点击「开始评估」查看详细分析报告。",
                                )
                        
                        quality_analyze_btn.click(
                            fn=wrap_quality_analyze,
                            inputs=[quality_url_input, quality_repo_name_input, enable_ai_eval],
                            outputs=[quality_status_output, quality_report_output],
                            show_progress="full",
                        )
                        
                        quality_url_input.submit(
                            fn=wrap_quality_analyze,
                            inputs=[quality_url_input, quality_repo_name_input, enable_ai_eval],
                            outputs=[quality_status_output, quality_report_output],
                            show_progress="full",
                        )
                    except Exception as e:
                        logger.error(f"创建代码质量评估界面失败: {str(e)}")
                        traceback.print_exc()
                        gr.Markdown(f"## ❌ 系统加载失败\n\n错误信息: {str(e)}\n\n请检查日志获取详细信息。")
            else:
                with gr.Tab("🔍 代码质量评估"):
                    gr.Markdown("## ⚠️ 系统不可用\n\n代码质量评估系统加载失败，请检查依赖和配置。")
            
            # 标签页3：商业计划书分析
            if BUSINESS_AVAILABLE:
                with gr.Tab("💼 商业计划书分析"):
                    try:
                        with gr.Row():
                            with gr.Column(scale=1):
                                pdf_input = gr.File(label="上传 BP (PDF)", file_types=[".pdf"])
                                business_btn = gr.Button("开始全自动分析", variant="primary")
                                gr.Markdown("### ⚙️ 说明\n- 系统将自动识别赛道并进行全网情报检索。\n- 分析耗时预计 45-60 秒。")
                                
                            with gr.Column(scale=2):
                                with gr.Tabs():
                                    with gr.Tab("📝 研报视图"):
                                        business_md_output = gr.Markdown("等待分析...")
                                    with gr.Tab("📊 原始数据"):
                                        business_json_output = gr.JSON()
                        
                        business_btn.click(
                            fn=wrap_business_analyze,
                            inputs=pdf_input,
                            outputs=[business_md_output, business_json_output],
                            api_name=False
                        )
                    except Exception as e:
                        logger.error(f"创建商业计划书分析界面失败: {str(e)}")
                        traceback.print_exc()
                        gr.Markdown(f"## ❌ 系统加载失败\n\n错误信息: {str(e)}\n\n请检查日志获取详细信息。")
            else:
                with gr.Tab("💼 商业计划书分析"):
                    gr.Markdown("## ⚠️ 系统不可用\n\n商业计划书分析系统加载失败，请检查依赖和配置。")
        
        # 使用说明
        with gr.Accordion("📖 使用说明", open=False):
            gr.Markdown("""
            ## SAGE统一评估系统使用指南
            
            ### 🔬 创新性与社会价值评估
            - 输入GitHub仓库URL
            - 选择评估类型（创新性/社会价值/两者）
            - 配置权重（可选）
            - 点击「开始评估」
            
            ### 🔍 代码质量评估
            - 输入GitHub仓库URL
            - 选择是否启用AI评价
            - 点击「开始评估」
            - 系统将自动抓取数据、分析代码质量并生成报告
            
            ### 💼 商业计划书分析
            - 上传PDF格式的商业计划书
            - 点击「开始全自动分析」
            - 系统将自动解析、分析并生成VC视角报告
            
            ## 注意事项
            - 各系统需要相应的API密钥配置
            - 评估时间取决于项目大小，通常需要30秒-2分钟
            - 详细配置说明请查看各子系统的README.md
            
            ## 💾 报告保存
            - 所有评估报告会自动保存为Markdown文件
            - 保存位置：`SAGE_code/reports/` 目录
            - 文件命名格式：`{系统名}_{项目名}_{时间戳}.md`
            - 报告保存成功后，会在报告末尾显示保存路径
            """)
    
    return app, custom_css


if __name__ == "__main__":
    app, css = create_unified_app()
    app.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True,
        enable_queue=True,
    )

