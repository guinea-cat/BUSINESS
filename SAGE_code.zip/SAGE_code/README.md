# SAGE 项目统一目录

## 项目结构

SAGE（Smart AI Grading Engine）项目包含三个主要评估系统：

```
code/
├── sage_creativity/      # 创新性与社会价值评估系统
├── sage_quality/         # 代码质量评估系统
└── sage_business/        # 商业计划书分析系统
```

## 系统说明

### 1. SAGE Creativity（创新性与社会价值评估）

**功能**：评估AI项目的创新性和社会价值
- 创新性评估：6维度（技术创新力40% + 场景创新力60%）
- 社会价值评估：7维度（基础项30% + 加分项70%）

**启动**：
```bash
cd sage_creativity
python start_app.py
# 访问 http://localhost:7862
```

**文档**：详见 `sage_creativity/README.md`

### 2. SAGE Quality（代码质量评估）

**功能**：评估代码质量和项目整体质量
- Git数据抓取和分析
- 代码质量检查（静态分析、测试、架构评估）
- AI项目评价

**启动**：
```bash
cd sage_quality
python start_app.py
# 访问 http://localhost:7863
```

**文档**：详见 `sage_quality/README.md`

### 3. SAGE Business（商业计划书分析）

**功能**：分析商业计划书，生成VC视角评估报告
- PDF解析和视觉分析
- 赛道识别和市场研究
- VC视角深度分析

**启动**：
```bash
cd sage_business
python start_app.py
# 访问 http://localhost:7864
```

**文档**：详见 `sage_business/README.md`

## 统一命名规范

### 文件夹命名
- 使用 `sage_` 前缀：`sage_creativity`, `sage_quality`, `sage_business`
- 小写字母和下划线：`snake_case`

### 主要文件
每个子文件夹应包含：
- `app.py` - Gradio主应用
- `start_app.py` - 启动脚本
- `config.py` - 配置文件
- `README.md` - 项目文档
- `requirements.txt` - 依赖文件

### 端口配置
- `sage_creativity`: 7862
- `sage_quality`: 7863
- `sage_business`: 7864

## 快速开始

### 安装所有依赖

```bash
# 安装创新性评估系统依赖
cd sage_creativity && pip install -r requirements.txt && cd ..

# 安装代码质量评估系统依赖
cd sage_quality && pip install -r requirements.txt && cd ..

# 安装商业分析系统依赖
cd sage_business && pip install -r requirements.txt && cd ..
```

### 环境变量配置

在项目根目录创建 `.env` 文件：

```env
# GitHub API（用于creativity和quality）
GITHUB_TOKEN=your_github_token

# ModelScope API（用于quality）
MODELSCOPE_API_TOKEN=your_modelscope_token

# DeepSeek API（用于creativity，可选）
DEEPSEEK_API_BASE=http://localhost:8000/v1
DEEPSEEK_API_KEY=EMPTY
DEEPSEEK_MODEL=Valdemardi/DeepSeek-R1-Distill-Qwen-32B-AWQ

# Serper API（用于business）
SERPER_API_KEY=your_serper_api_key

# DashScope API（用于business）
DASHSCOPE_API_KEY=your_dashscope_api_key
```

## 文件夹重命名说明

如果文件夹尚未重命名，请手动执行以下操作：

### Windows PowerShell
```powershell
cd code
Rename-Item -Path "creativity" -NewName "sage_creativity"
Rename-Item -Path "quality" -NewName "sage_quality"
Rename-Item -Path "business" -NewName "sage_business"
```

### Linux/Mac
```bash
cd code
mv creativity sage_creativity
mv quality sage_quality
mv business sage_business
```

### 或使用Python脚本
```bash
cd code
python rename_folders.py
```

## 注意事项

- 每个系统使用不同的端口，可以同时运行
- 确保已安装所有依赖
- 根据系统要求配置相应的API密钥
- 详细使用说明请查看各子文件夹的 README.md

---

**SAGE - 让AI项目评估更智能、更专业、更全面**

