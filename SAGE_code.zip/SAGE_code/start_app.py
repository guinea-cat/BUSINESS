"""SAGE统一评估系统 - 启动脚本

整合三个评估系统到一个统一的Gradio界面：
- 创新性与社会价值评估
- 代码质量评估
- 商业计划书分析
"""
import sys
import traceback
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

try:
    print("=" * 60)
    print("=== 启动SAGE统一评估系统 ===")
    print(f"Python版本: {sys.version}")
    print()
    print("系统功能：")
    print("  - 🔬 创新性与社会价值评估（6+7维度）")
    print("  - 🔍 代码质量评估（静态分析+AI评价）")
    print("  - 💼 商业计划书分析（VC视角深度分析）")
    print()
    print("=" * 60)
    
    # 导入模块
    print("正在导入模块...")
    from app import create_unified_app
    print("✅ 模块导入成功!")
    
    # 创建应用
    print("正在创建统一应用...")
    app, css = create_unified_app()
    print("✅ 应用创建成功!")
    
    # 启动应用
    print()
    print("=" * 60)
    print("正在启动应用服务器...")
    print("访问地址: http://localhost:7860")
    print("按 Ctrl+C 停止服务器")
    print("=" * 60)
    print()
    
    app.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True,
        debug=True,  # 启用调试模式
    )
    
except Exception as e:
    print(f"\n{'=' * 60}")
    print("=== 启动失败 ===")
    print(f"错误类型: {type(e).__name__}")
    print(f"错误信息: {str(e)}")
    print("\n详细错误:")
    traceback.print_exc()
    print(f"\n{'=' * 60}")
    print("\n请检查上述错误信息并解决问题后重试。")
    print("提示：")
    print("  1. 确保已安装所有依赖：pip install -r requirements.txt")
    print("  2. 检查各子系统的配置文件是否正确")
    print("  3. 确保API密钥已正确配置")
