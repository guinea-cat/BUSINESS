"""报告优化模块 - 使用DeepSeek模型优化报告输出

通过大语言模型将结构化评估数据转化为人性化、易读的报告文本。
"""
import os
import sys
from pathlib import Path
from typing import Dict, Any, Optional
import json
from datetime import datetime

sys.path.append(str(Path(__file__).parent.parent))
from config import DEEPSEEK_API_BASE, DEEPSEEK_API_KEY, DEEPSEEK_MODEL


class ReportOptimizer:
    """报告优化器 - 使用DeepSeek模型生成人性化报告"""
    
    SYSTEM_PROMPT = """你是一位资深的AI应用评审专家和技术分析师，负责将项目评估数据转化为**极其详尽、深入、专业**的评审报告。

## 核心要求
1. **深度思考模式**：在生成报告前，先对项目进行深度思考，分析其本质、创新点和潜在价值
2. **去模板化**：摆脱固定格式的限制，根据项目特点自由组织内容结构，突出项目的独特性
3. **深度分析**：每个维度分析必须**充分展开**，包含：
   - 现状详细描述（具体技术/特性）
   - 优点分析（2-3个具体优点，要有数据或事实支持）
   - 不足分析（1-2个具体不足，要切中要害）
   - 与同类项目的深度对比
   - 具体可行的改进方向建议
4. **针对性**：报告内容必须紧密结合项目本身的特点，避免泛泛而谈，要有具体的项目细节和案例
5. **AI幻觉防护**：基于事实和数据进行分析，避免产生AI幻觉，对于不确定的信息要明确标注

## 报告风格
- 语言专业严谨，但易于理解
- 评价客观公正，引用具体数据和事实
- 分析要**深入透彻**，不能流于表面
- 建议要**具体可操作**，有明确的实施路径
- 突出项目的实际价值和社会影响
- 结构清晰，逻辑连贯，层层递进

## 内容要求
- **项目本质分析**：深入理解项目的核心价值和创新本质
- **技术深度分析**：分析技术实现的创新点和技术选型的合理性
- **场景深度分析**：分析应用场景的创新性和社会价值
- **市场深度分析**：分析市场定位和竞争优势
- **风险深度分析**：分析项目面临的技术和商业风险
- **发展潜力分析**：分析项目的长期发展潜力和扩展空间

## 格式建议
- 使用Markdown格式，但不要拘泥于固定模板
- 善用表格、列表等形式增强可读性
- 每个章节都要有实质内容，禁止空泛描述
- 根据项目特点灵活组织内容结构"""

    def __init__(self, api_base: str = None, api_key: str = None, model: str = None):
        """初始化报告优化器
        
        Args:
            api_base: OpenAI兼容API的base URL
            api_key: API密钥
            model: 模型名称
        """
        self.api_base = api_base or DEEPSEEK_API_BASE
        self.api_key = api_key or DEEPSEEK_API_KEY
        self.model = model or DEEPSEEK_MODEL
        self.client = None
        self._init_client()
    
    def _init_client(self):
        """初始化OpenAI客户端"""
        try:
            from openai import OpenAI
            self.client = OpenAI(
                base_url=self.api_base,
                api_key=self.api_key,
            )
        except ImportError:
            print("Warning: openai package not installed, report optimization disabled")
            self.client = None
        except Exception as e:
            print(f"Warning: Failed to init OpenAI client: {e}")
            self.client = None
    
    def optimize_report(self, report_data: Dict[str, Any], prompt_data: Optional[Dict[str, Any]] = None, timeout: int = 300) -> Optional[str]:
        """优化报告输出
        
        Args:
            report_data: 评估报告的结构化数据
            prompt_data: 提示词数据，包含预构建的提示词内容
            timeout: 超时时间（秒）
            
        Returns:
            优化后的Markdown报告，失败返回None
        """
        if not self.client:
            return None
        
        # 构建提示词
        prompt = self._build_prompt(report_data, prompt_data)
        
        try:
            # 深度思考模式：使用更低的温度，让模型更加理性和深入
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,  # 降低温度，提高思考深度和一致性
                max_tokens=16384,
                timeout=timeout,
                top_p=0.9,  # 控制生成的多样性
                frequency_penalty=0.1,  # 减少重复内容
                presence_penalty=0.1,  # 鼓励新内容
            )
            
            # 处理模型输出，添加AI幻觉防护提示
            output = response.choices[0].message.content
            return self._add_ai_hallucination_warning(output)
        except Exception as e:
            print(f"Report optimization failed: {e}")
            return None
    
    def _build_prompt(self, data: Dict[str, Any], prompt_data: Optional[Dict[str, Any]] = None) -> str:
        """构建优化提示词"""
        
        # 如果提供了提示词数据，使用它
        if prompt_data:
            return f"""# 项目评估数据

## 基本信息
| 属性 | 值 |
|------|------|
| 项目名称 | {prompt_data.get('repo_name', 'Unknown')} |
| 项目描述 | {prompt_data.get('description', '无描述')} |
| 主要语言 | {prompt_data.get('language', 'Unknown')} |
| GitHub Star数 | {prompt_data.get('stars', 0):,} |
| 项目URL | {prompt_data.get('repo_url', '')} |

## 评估得分概览
| 指标 | 得分 | 满分 |
|------|------|------|
| **总分** | **{prompt_data.get('total_score', 0):.1f}** | 100 |
| 创新等级 | {prompt_data.get('level', '未知')} {prompt_data.get('level_stars', '')} | - |
| 技术创新力 | {prompt_data.get('tech_innovation_score', 0):.1f} | 40 |
| 场景创新力 | {prompt_data.get('scenario_innovation_score', 0):.1f} | 60 |

## 六维度详细得分
{prompt_data.get('dim_table', '')}

## 雷达图分析
{prompt_data.get('radar_analysis', '无分析')}

## 各维度详细分析数据
{prompt_data.get('analyses_text', '')}

## 现有改进建议
### 技术加固
{prompt_data.get('tech_suggestions', '无')}

### 场景深化  
{prompt_data.get('scenario_suggestions', '无')}

### 产品化推进
{prompt_data.get('product_suggestions', '无')}

## 评委关注点
{prompt_data.get('judge_focus_points', '无')}

---

# 报告生成要求

**重要：你必须生成一份极其详细、专业的评审报告，总字数不少于4000字！**

## 深度思考要求
在生成报告前，请先进行深度思考：
1. 这个项目的本质是什么？它真正解决了什么问题？
2. 项目的核心创新点在哪里？与同类项目有何不同？
3. 项目的技术实现有哪些独特之处？技术选型是否合理？
4. 项目的应用场景是否有深度？是否服务于特定的高价值人群？
5. 项目的市场定位是否清晰？商业化潜力如何？
6. 项目面临的主要风险和挑战是什么？
7. 项目的长期发展潜力如何？有哪些扩展空间？

## 报告生成指南
请基于以上深度思考，自由组织报告结构，突出项目的独特性和价值。报告应包含但不限于以下内容：

1. **项目概览**：项目简介、核心价值主张、创新类型判断
2. **创新性总评**：总分解读、主要亮点、主要不足
3. **深度维度分析**：根据项目特点，重点分析最相关的维度
4. **技术深度分析**：技术选型、架构设计、工程化水平
5. **场景深度分析**：应用场景、目标用户、社会价值
6. **市场与生态分析**：市场定位、竞争优势、生态契合度
7. **改进建议**：具体可行的改进方向和措施
8. **评委关注点**：核心追问问题、潜在风险点、关键考察维度
9. **总结与建议**：总体评价、核心优势、最需改进之处

## 风格要求
- **去模板化**：摆脱固定格式限制，根据项目特点自由组织内容
- **深度分析**：每个分析都要切中要害，有具体的数据和事实支持
- **针对性强**：紧密结合项目本身的特点，避免泛泛而谈
- **专业严谨**：语言专业但易于理解，评价客观公正
- **具体可行**：建议要具体可操作，有明确的实施路径

## 格式建议
- 使用Markdown格式，但不要拘泥于固定模板
- 善用表格、列表等形式增强可读性
- 可以根据项目特点添加自定义章节
- 重点内容可以使用加粗、高亮等方式突出

---

# {prompt_data.get('repo_name', '项目')} - AI应用创新性评审报告

**报告生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**评审系统**：SAGE AI创新性评估系统 v4.0（深度思考优化版）

**核心评估数据**：
- 总分：{prompt_data.get('total_score', 0):.1f}/100
- 创新等级：{prompt_data.get('level', '未知')} {prompt_data.get('level_stars', '')}
- 技术创新力：{prompt_data.get('tech_innovation_score', 0):.1f}/40
- 场景创新力：{prompt_data.get('scenario_innovation_score', 0):.1f}/60

**项目深度分析数据**：
### 技术细节
- 核心技术栈：{', '.join(prompt_data.get('project_depth_data', {}).get('tech_details', {}).get('packages', []))[:100]}...
- 前沿技术：{', '.join(prompt_data.get('project_depth_data', {}).get('tech_details', {}).get('cutting_edge', []))[:100]}...
- 代码复杂度：{prompt_data.get('project_depth_data', {}).get('code_details', {}).get('avg_complexity', '未知')}
- 架构模式：{', '.join(prompt_data.get('project_depth_data', {}).get('arch_details', {}).get('patterns', []))[:100]}...

### 工程化水平
- CI/CD配置：{prompt_data.get('project_depth_data', {}).get('eng_details', {}).get('has_ci_cd', '未知')}
- Docker支持：{prompt_data.get('project_depth_data', {}).get('eng_details', {}).get('has_docker', '未知')}
- 测试覆盖：{prompt_data.get('project_depth_data', {}).get('eng_details', {}).get('has_tests', '未知')}

### 解决方案分析
- 问题清晰度：{prompt_data.get('project_depth_data', {}).get('solution_details', {}).get('problem_clarity', '未知')}
- 跨领域融合：{prompt_data.get('project_depth_data', {}).get('solution_details', {}).get('cross_domain', '未知')}
- 核心价值：{prompt_data.get('project_depth_data', {}).get('core_value_summary', '未知')}
- 创新类型：{prompt_data.get('project_depth_data', {}).get('innovation_type', '未知')}

### 社区与生态
- GitHub Stars：{prompt_data.get('stars', 0)}
- 贡献者：{prompt_data.get('project_depth_data', {}).get('community_health', {}).get('contributors', 0)}
- 开放问题：{prompt_data.get('project_depth_data', {}).get('community_health', {}).get('issues', 0)}

---

## 深度思考与报告内容

（基于深度思考和以上详细数据，自由组织报告内容，突出项目的独特性和价值。请确保分析切中肯綮，具体且有深度，避免模板化内容。）

---

**报告完**
"""
        
        # 否则使用默认方式构建提示词
        # 构建维度得分表格
        dim_table = "| 维度 | 得分 | 权重 | 加权得分 | 评价摘要 |\n|------|------|------|----------|----------|\n"
        dimensions = data.get('dimensions', [])
        for dim in dimensions:
            if isinstance(dim, dict):
                dim_table += f"| {dim.get('name_cn', '')} | {dim.get('score', 0):.0f} | {dim.get('weight', 0):.0f}% | {dim.get('score', 0) * dim.get('weight', 0) / 100:.1f} | {dim.get('details', '')[:50]}... |\n"
        
        # 构建维度分析详情
        analyses_text = ""
        analyses = data.get('dimension_analyses', {})
        dim_name_map = {
            'tech_implementation': '技术选型与实现',
            'architecture_design': '系统架构与设计',
            'engineering_sustainability': '工程化与可持续性',
            'problem_value': '问题定义与价值',
            'scenario_innovation': '场景创新性',
            'market_fit': '市场与生态契合度'
        }
        for name, analysis in analyses.items():
            cn_name = dim_name_map.get(name, name)
            analyses_text += f"### {cn_name}\n{analysis}\n\n"
        
        prompt = f"""# 项目评估数据

## 基本信息
| 属性 | 值 |
|------|------|
| 项目名称 | {data.get('repo_name', 'Unknown')} |
| 项目描述 | {data.get('description', '无描述')} |
| 主要语言 | {data.get('language', 'Unknown')} |
| GitHub Star数 | {data.get('stars', 0):,} |
| 项目URL | {data.get('repo_url', '')} |

## 评估得分概览
| 指标 | 得分 | 满分 |
|------|------|------|
| **总分** | **{data.get('total_score', 0):.1f}** | 100 |
| 创新等级 | {data.get('level', '未知')} {data.get('level_stars', '')} | - |
| 技术创新力 | {data.get('tech_innovation_score', 0):.1f} | 40 |
| 场景创新力 | {data.get('scenario_innovation_score', 0):.1f} | 60 |

## 六维度详细得分
{dim_table}

## 雷达图分析
{data.get('radar_analysis', '无分析')}

## 各维度详细分析数据
{analyses_text}

## 现有改进建议
### 技术加固
{chr(10).join(['- ' + s for s in data.get('tech_suggestions', ['无'])])}

### 场景深化  
{chr(10).join(['- ' + s for s in data.get('scenario_suggestions', ['无'])])}

### 产品化推进
{chr(10).join(['- ' + s for s in data.get('product_suggestions', ['无'])])}

## 评委关注点
{chr(10).join(['- ' + p for p in data.get('judge_focus_points', ['无'])])}

---

# 报告生成要求

**重要：你必须生成一份极其详细、专业的评审报告，总字数不少于4000字！**

请严格按照以下格式和要求输出报告：

---

# {data.get('repo_name', '项目')} - AI应用创新性评审报告

## 一、项目概览与核心定位

### 1.1 项目简介
（详细描述项目是什么、解决什么问题、目标用户是谁，4-5句话）

### 1.2 创新类型判断
（判断是技术驱动型、场景驱动型还是综合型创新，说明判断依据，3-4句话）

### 1.3 核心价值主张
（项目的独特价值是什么，与竞品的差异化，3-4句话）

---

## 二、创新性总评

### 2.1 总分解读
（详细解读{data.get('total_score', 0):.1f}分意味着什么，在同类项目中处于什么水平，4-5句话）

### 2.2 双轨分析：技术创新力 vs 场景创新力
（对比分析技术创新力{data.get('tech_innovation_score', 0):.1f}/40和场景创新力{data.get('scenario_innovation_score', 0):.1f}/60的表现，哪个更突出，为什么，5-6句话）

### 2.3 主要亮点（3个）
1. **亮点一**：（具体描述，2-3句话）
2. **亮点二**：（具体描述，2-3句话）
3. **亮点三**：（具体描述，2-3句话）

### 2.4 主要不足（2个）
1. **不足一**：（具体描述，2-3句话）
2. **不足二**：（具体描述，2-3句话）

---

## 三、六维能力雷达分析

### 3.1 维度得分可视化
（用ASCII进度条展示6个维度得分，格式如：技术选型：████████░░ 80分）

### 3.2 优势维度深度分析
（选择得分最高的2个维度，详细分析为什么表现好，有哪些具体体现，每个维度4-5句话）

### 3.3 短板维度深度分析
（选择得分最低的2个维度，详细分析为什么表现不佳，原因是什么，每个维度4-5句话）

### 3.4 维度均衡性评价
（分析6个维度是否均衡，是否存在明显的"木桶效应"，3-4句话）

---

## 四、详细维度分析

### 技术创新力板块（满分40分，得分{data.get('tech_innovation_score', 0):.1f}分）

#### 4.1 技术选型与实现
**得分**：X/100 | **权重**：13%

**现状分析**：
（详细描述项目使用了哪些技术栈、框架、库，技术选型的特点，5-6句话）

**优点**：
- 优点1：（具体描述）
- 优点2：（具体描述）

**不足**：
- 不足1：（具体描述）

**与同类项目对比**：
（与同类AI应用的技术选型对比，2-3句话）

**改进方向**：
（具体的技术改进建议，2-3句话）

---

#### 4.2 系统架构与设计
**得分**：X/100 | **权重**：13%

**现状分析**：
（详细描述项目的架构模式、模块划分、代码组织，5-6句话）

**优点**：
- 优点1：（具体描述）
- 优点2：（具体描述）

**不足**：
- 不足1：（具体描述）

**架构评估**：
| 评估项 | 评价 |
|--------|------|
| 模块化程度 | 高/中/低 |
| 耦合度 | 高/中/低 |
| 可扩展性 | 好/中/差 |
| 代码复用性 | 好/中/差 |

**改进方向**：
（具体的架构改进建议，2-3句话）

---

#### 4.3 工程化与可持续性
**得分**：X/100 | **权重**：14%

**现状分析**：
（详细描述项目的工程化配置：CI/CD、测试、文档、部署，5-6句话）

**工程化检查清单**：
| 检查项 | 状态 |
|--------|------|
| CI/CD配置 | ✓/✗ |
| 自动化测试 | ✓/✗ |
| Docker支持 | ✓/✗ |
| 文档完善度 | 好/中/差 |
| 代码规范 | 好/中/差 |

**优点**：
- 优点1：（具体描述）

**不足**：
- 不足1：（具体描述）

**改进方向**：
（具体的工程化改进建议，2-3句话）

---

### 场景创新力板块（满分60分，得分{data.get('scenario_innovation_score', 0):.1f}分）

#### 4.4 问题定义与价值
**得分**：X/100 | **权重**：18%

**现状分析**：
（详细描述项目定义的问题、目标用户、价值主张，5-6句话）

**问题定义评估**：
| 评估项 | 评价 |
|--------|------|
| 问题清晰度 | 高/中/低 |
| 用户画像清晰度 | 高/中/低 |
| 痛点挖掘深度 | 深/中/浅 |
| 价值主张独特性 | 高/中/低 |

**优点**：
- 优点1：（具体描述）

**不足**：
- 不足1：（具体描述）

**改进方向**：
（具体的改进建议，2-3句话）

---

#### 4.5 场景创新性（核心评估维度）
**得分**：X/100 | **权重**：24%（重点）

**⭐ 这是本报告的核心评估维度，需要重点关注 ⭐**

**现状分析**：
（详细描述项目的应用场景、创新点、服务的用户群体，6-8句话）

**场景创新性评估**：
| 评估项 | 评价 | 说明 |
|--------|------|------|
| 场景新颖性 | 高/中/低 | （说明） |
| 目标人群特殊性 | 高/中/低 | （说明） |
| 跨领域融合 | 有/无 | （说明） |
| 社会价值 | 高/中/低 | （说明） |
| 可落地性 | 高/中/低 | （说明） |

**亮点分析**：
（详细分析场景创新的亮点，4-5句话）

**不足分析**：
（详细分析场景创新的不足，3-4句话）

**与同类产品对比**：
（与市场上同类产品的场景定位对比，3-4句话）

**改进方向**：
（具体的场景深化建议，3-4句话）

---

#### 4.6 市场与生态契合度
**得分**：X/100 | **权重**：18%

**现状分析**：
（详细描述项目与市场趋势、技术生态的契合程度，5-6句话）

**市场契合度评估**：
| 评估项 | 评价 |
|--------|------|
| 技术趋势契合度 | 高/中/低 |
| 社区认可度 | 高/中/低 |
| 生态集成能力 | 好/中/差 |
| 商业化潜力 | 高/中/低 |

**优点**：
- 优点1：（具体描述）

**不足**：
- 不足1：（具体描述）

**改进方向**：
（具体的改进建议，2-3句话）

---

## 五、改进建议

### 5.1 技术加固建议（优先级排序）

#### 建议1：（标题）
- **问题**：（当前存在什么问题）
- **措施**：（具体应该怎么做）
- **效果**：（预期能带来什么改善）
- **优先级**：高/中/低

#### 建议2：（标题）
（同上格式）

#### 建议3：（标题）
（同上格式）

---

### 5.2 场景深化建议（优先级排序）

#### 建议1：（标题）
- **问题**：（当前存在什么问题）
- **措施**：（具体应该怎么做）
- **效果**：（预期能带来什么改善）
- **优先级**：高/中/低

#### 建议2：（标题）
（同上格式）

#### 建议3：（标题）
（同上格式）

---

### 5.3 产品化推进建议（优先级排序）

#### 建议1：（标题）
- **问题**：（当前存在什么问题）
- **措施**：（具体应该怎么做）
- **效果**：（预期能带来什么改善）
- **优先级**：高/中/低

#### 建议2：（标题）
（同上格式）

#### 建议3：（标题）
（同上格式）

---

## 六、评委关注点

### 6.1 核心追问问题（5个）

#### 问题1：（问题内容）
- **追问目的**：（为什么要问这个问题）
- **期望回答**：（希望团队能提供什么信息）
- **评分参考**：（好的回答和差的回答分别是什么样的）

#### 问题2：（问题内容）
（同上格式）

#### 问题3：（问题内容）
（同上格式）

#### 问题4：（问题内容）
（同上格式）

#### 问题5：（问题内容）
（同上格式）

---

### 6.2 潜在风险点
（列出评委需要关注的潜在风险，3-4个，每个2句话说明）

### 6.3 关键考察维度
（列出评委应重点考察的3个维度，说明为什么）

---

## 七、总结与评委建议

### 7.1 总体评价
（对项目的整体定性评价，4-5句话，包括创新程度、完成度、潜力）

### 7.2 核心优势总结
（用3个关键词概括项目的核心优势，并分别说明）

### 7.3 最需改进之处
（指出项目最需要改进的1-2个方面，说明理由）

### 7.4 评委建议
（给评委的评审建议：应该重点关注什么、如何打分、需要追问什么）

---

**报告完**
"""
        return prompt
    
    def _add_ai_hallucination_warning(self, content: str) -> str:
        """添加AI幻觉防护提示
        
        Args:
            content: 模型生成的报告内容
            
        Returns:
            添加了幻觉防护提示的报告内容
        """
        # 添加AI幻觉防护提示
        warning = """
---

## 🛡️ AI幻觉防护与报告使用说明

### 重要提醒
- **数据来源**：本报告基于GitHub仓库的公开信息和代码分析生成
- **AI生成**：报告内容由AI模型生成，可能存在一定的主观性和局限性
- **事实核查**：对于关键信息，建议团队进行事实核查和确认
- **谨慎参考**：报告中的建议和分析仅供参考，具体决策请结合实际情况

### 防止AI幻觉的注意事项
1. **数据支撑**：报告中的分析应基于具体的数据和事实，避免空泛的主观判断
2. **逻辑一致性**：分析逻辑应保持一致，避免前后矛盾的结论
3. **可验证性**：关键信息应可通过公开渠道验证
4. **边界清晰**：明确说明报告的适用范围和局限性
5. **团队反馈**：鼓励团队提供反馈，持续改进报告质量

### 深度思考模式的优势
- **理性分析**：基于事实和数据进行深入分析，减少情绪化判断
- **系统性思考**：从整体角度分析项目，考虑各维度的相互影响
- **前瞻性**：不仅关注当前状态，还分析项目的长期发展潜力
- **针对性强**：紧密结合项目特点，提供具体可行的建议

---
"""
        
        # 在报告末尾添加警告
        return content + warning
    
    def optimize_section(self, section_name: str, section_data: Dict[str, Any]) -> Optional[str]:
        """优化报告的某个章节
        
        Args:
            section_name: 章节名称
            section_data: 章节数据
            
        Returns:
            优化后的章节文本
        """
        if not self.client:
            return None
        
        prompt = f"""请优化以下评审报告章节，使其更加人性化和专业：

章节：{section_name}
原始内容：
{json.dumps(section_data, ensure_ascii=False, indent=2)}

请用流畅的中文重写这个章节，保持专业性的同时增加可读性。"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一位专业的技术评审报告撰写专家。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1024,
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Section optimization failed: {e}")
            return None


def test_optimizer():
    """测试报告优化器"""
    optimizer = ReportOptimizer()
    
    test_data = {
        "repo_name": "test-project",
        "description": "一个面向阿尔茨海默症患者的AI陪伴聊天机器人",
        "language": "Python",
        "stars": 150,
        "total_score": 72.5,
        "level": "中等创新",
        "level_stars": "⭐⭐⭐",
        "tech_innovation_score": 28.5,
        "scenario_innovation_score": 44.0,
        "dimensions": [
            {"name": "tech_implementation", "name_cn": "技术选型与实现", "score": 65, "details": "使用了LangChain等现代框架"},
            {"name": "scenario_innovation", "name_cn": "场景创新性", "score": 80, "details": "聚焦阿尔茨海默症患者"},
        ],
        "radar_analysis": "场景创新性表现突出，技术实现有提升空间",
        "tech_suggestions": ["引入更多前沿AI框架", "增加单元测试"],
        "scenario_suggestions": ["深入调研目标用户需求"],
        "product_suggestions": ["创建在线Demo"],
        "judge_focus_points": ["如何理解阿尔茨海默症患者的需求？", "与市场同类产品的差异化？"],
    }
    
    result = optimizer.optimize_report(test_data)
    if result:
        print("优化后的报告：")
        print(result)
    else:
        print("报告优化失败，请检查API配置")


if __name__ == "__main__":
    test_optimizer()
