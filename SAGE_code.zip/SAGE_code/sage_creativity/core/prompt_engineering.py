"""提示词工程库 - 系统性的提示词模板和最佳实践

本模块提供专业、结构化的提示词模板，用于优化Deepseek模型的查询引导与性能提升。
通过构建清晰、专业的提示词工程库，实现更高效、准确的评估报告生成。
"""
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class PromptTemplate:
    """提示词模板类"""
    name: str  # 模板名称
    description: str  # 模板描述
    system_prompt: str  # 系统提示词
    user_prompt_template: str  # 用户提示词模板
    parameters: List[str]  # 参数列表
    examples: List[Dict[str, str]]  # 示例
    category: str  # 分类
    version: str = "1.0"  # 版本
    default_params: Dict[str, Any] = field(default_factory=dict)  # 默认参数
    required_params: List[str] = field(default_factory=list)  # 必需参数
    scene_specific: bool = False  # 是否为场景特定模板
    applicable_scenes: List[str] = field(default_factory=list)  # 适用场景列表


class PromptEngineeringLibrary:
    """提示词工程库"""
    
    def __init__(self):
        """初始化提示词工程库"""
        self.templates = self._load_templates()
    
    def _load_templates(self) -> Dict[str, PromptTemplate]:
        """加载提示词模板"""
        templates = {}
        
        # 1. 创新性评估报告优化模板
        templates["innovation_report_optimizer"] = PromptTemplate(
            name="innovation_report_optimizer",
            description="优化AI应用创新性评估报告，生成详细、专业的评审报告",
            system_prompt = """# Role
你是一位拥有15年经验的 **AI技术尽职调查专家 (Tech Due Diligence Expert)** 和 **产品战略顾问**。你擅长像风险投资人（VC）一样审视开源项目——既看重技术实现的“硬核程度”，也看重商业场景的“落地潜力”。

# Context
你正在评审一个AI应用/开源项目。你的任务不是写一篇平庸的说明书，而是输出一份**辛辣、高密度、决策导向**的深度评审报告。这份报告将作为评委打分或投资决策的核心依据。

# Core Principles (核心原则)
1.  **拒绝平庸 (No Fluff)**：严禁使用"具有一定潜力"、"值得期待"等正确的废话。观点必须鲜明：要么是"极具颠覆性"，要么是"技术堆砌但在裸泳"。
2.  **证据锚定 (Evidence-Based)**：
    -   谈优点时：必须引用具体的代码模块、架构设计或README中的数据。
    -   谈缺点时：必须指出具体的技术瓶颈（如上下文限制、延迟、依赖风险）或逻辑漏洞。
3.  **双轨思维 (Dual-Track Thinking)**：
    -   **技术轨**：不仅看用了什么模型，更要看*工程化落地能力*（Prompt工程、RAG优化、边缘计算、推理加速）。
    -   **产品轨**：不仅看解决了什么问题，更要看*不可替代性*（这是个Feature还是个Product？）。
4.  **防幻觉机制**：对于Input Data中未提及的性能指标（如QPS、具体用户数），请根据项目架构和代码体量进行**合理推断**，并标注为“估算”或“基于架构推演”，绝不捏造数据。

# Tone & Style
-   **专家口吻**：客观、冷静、直击要害。
-   **结构化输出**：使用Markdown，通过加粗、列表、表格来降低阅读认知负荷。
-   **深度优先**：每个维度的分析字数必须充足，逻辑链条要完整（现象 -> 原因 -> 影响 -> 建议）。
""",
            user_prompt_template = """# 项目评估原始数据

## 基本信息
| 属性 | 值 |
|------|------|
| 项目名称 | {repo_name} |
| 项目描述 | {description} |
| 主要语言 | {language} |
| GitHub Star数 | {stars:,} |
| 项目URL | {repo_url} |

## 评估得分概览 (由模型计算)
| 指标 | 得分 | 满分 |
|------|------|------|
| **总分** | **{total_score:.1f}** | 100 |
| 创新等级 | {level} {level_stars} | - |
| 技术创新力 | {tech_innovation_score:.1f} | 40 |
| 场景创新力 | {scenario_innovation_score:.1f} | 60 |

## 六维度详细得分
{dim_table}

## 雷达图分析
{radar_analysis}

## 各维度详细分析内容
{analyses_text}

## 现有改进建议
### 技术加固
{tech_suggestions}

### 场景深化  
{scenario_suggestions}

### 产品化推进
{product_suggestions}

## 评委关注点
{judge_focus_points}

---

# 报告生成指令 (Instruction)

**目标：生成一份字数不少于3000字的深度评审报告。**
请严格填充以下模板，并在括号内的指引下进行深度扩展：

---

# {repo_name} - AI应用深度尽职调查报告

## 一、 项目概览与战略定位 (Executive Summary)

### 1.1 项目本质重构
（不要照抄简介。请用一句话重新定义该项目，例如：“这就好比是面向XXX领域的瑞士军刀...”。分析其核心解决的“真问题”是什么。）

### 1.2 创新类型定性
（明确判断：是 **颠覆式创新**（创造新范式）、**组合式创新**（现有技术新场景）还是 **微创新**（体验优化）。给出3条强硬的理由。）

### 1.3 核心护城河分析
（分析该项目最难被复制的点是什么？是独特的数据集、精妙的Prompt Engineering、还是极低的使用门槛？）

---

## 二、 创新性综合研判

### 2.1 总分透视 ({total_score:.1f}/100)
（解读分数背后的含义。如果分数高，高在哪里？如果分数低，短板是否致命？请结合GitHub Stars数分析其社区认可度与实际质量的偏差。）

### 2.2 技术-场景剪刀差分析
（对比技术分 {tech_innovation_score:.1f} 与 场景分 {scenario_innovation_score:.1f}。
- 若技术>场景：是否存在"拿着锤子找钉子"的风险？
- 若场景>技术：是否存在"大饼画得好但落地难"的风险？）

### 2.3 关键亮点 (High-Lights)
1. **[核心亮点1]**：（不要只说"好"，要说"如何巧妙"。例如：使用了XXX架构解决了YYY延迟问题。）
2. **[核心亮点2]**：（同上）
3. **[核心亮点3]**：（同上）

### 2.4 致命/潜在弱点 (Red Flags)
1. **[风险点1]**：（直言不讳，例如：依赖库过于陈旧、Token消耗过大、缺乏商业变现路径等。）
2. **[风险点2]**：（同上）

---

## 三、 六维能力图谱透视

### 3.1 维度得分可视化
（使用 ASCII 进度条展示，必须直观。例如 `技术选型: [████████··] 80/100`）

### 3.2 领跑维度深度复盘
（选取最高分的2个维度。不仅要列举现象，更要分析团队在这些方面做对了什么？是技术选型眼光独到，还是对用户痛点理解深刻？）

### 3.3 滞后维度原因剖析
（选取最低分的2个维度。深度挖掘原因：是资源受限、技术能力不足，还是战略重心偏差？切勿一笔带过。）

### 3.4 均衡性与"木桶效应"
（分析哪个短板正在制约该项目的上限。）

---

## 四、 核心维度深度审计 (Deep Dive)

### 🏗️ 技术创新力板块 (权重 40%)

#### 4.1 技术栈与实现路径 (权重 13%)
**得分评估**：X/100
**审计视角**：
- **技术栈合理性**：（分析框架/模型选择是否符合当前SOTA或最佳实践？例如：为什么选LangChain而不是原生API？为什么选PyTorch？）
- **代码/架构亮点**：（引用具体的技术实现细节）
- **潜在技术债务**：（指出未来可能需要重构的地方）
**同类竞品技术对比**：（对比市场上主流方案，分析优劣）

#### 4.2 系统架构与解耦 (权重 13%)
**得分评估**：X/100
**审计视角**：
- **模块化程度**：（是否做到了关注点分离？核心算法与业务逻辑是否解耦？）
- **扩展性设计**：（如果用户量翻10倍，架构能撑住吗？）
- **架构图表描述**：（文字描述系统的核心数据流向）

#### 4.3 工程化与交付质量 (权重 14%)
**得分评估**：X/100
**审计视角**：
- **DevOps成熟度**：（CI/CD、Docker化、自动化测试覆盖率推断）
- **可维护性**：（文档是否仅是"Hello World"水平？API定义是否规范？）
- **工程化缺陷列表**：（列出具体的工程硬伤，如：缺乏Env配置、硬编码路径等）

---

### 🚀 场景创新力板块 (权重 60%)

#### 4.4 痛点精准度与定义 (权重 18%)
**得分评估**：X/100
**审计视角**：
- **伪需求检测**：（这真的是用户需要的吗？还是开发者的自嗨？如何验证的？）
- **用户画像颗粒度**：（目标用户是谁？场景有多高频？）

#### 4.5 场景创新性与落地 (权重 24%)
**⭐ 核心评估点 ⭐**
**审计视角**：
- **"Aha Moment"**：（产品的哪个功能能让用户尖叫？）
- **差异化生存**：（在大厂模型的降维打击下，该项目的生存空间在哪里？）
- **社会价值/伦理**：（是否存在滥用风险？对行业的正面促进作用？）

#### 4.6 商业生态与市场 (权重 18%)
**得分评估**：X/100
**审计视角**：
- **商业化路径推演**：（API收费？SaaS订阅？开源引流？给出具体推测）
- **生态集成能力**：（能否方便地集成到现有工作流中？）
- **竞品护城河**：（为什么用户选你而不是选ChatGPT Plus？）

---

## 五、 战略级改进路线图

### 5.1 技术加固 (Technical Hardening)
*(针对架构、性能、安全提出的具体建议)*
#### 建议1：[标题] (优先级：高)
- **痛点**：...
- **方案**：... (必须具体到技术栈或方法论，如"引入Redis做缓存层")
- **预期收益**：...

#### 建议2：[标题] (优先级：中)
...

### 5.2 场景深化 (Scenario Deepening)
*(针对功能体验、用户留存提出的建议)*
#### 建议1：[标题] (优先级：高)
- **痛点**：...
- **方案**：... (例如"增加反馈回路机制")
- **预期收益**：...

### 5.3 产品化推进 (Productization)
*(针对商业化、推广、运营提出的建议)*
#### 建议1：[标题] (优先级：低)
...

---

## 六、 评委/投资人关注点 (Judge's Cheat Sheet)

### 6.1 必须追问的尖锐问题 (Top 5)
*(为评委准备5个能以此通过来验证团队真实水平的问题)*
1. **关于技术壁垒**："[问题内容]?"
   - *追问意图*：(测试技术深度)
   - *参考答案*：(什么样的回答才算过关)
2. **关于数据闭环**：...
3. **关于成本控制**：...
4. **关于长尾场景**：...
5. **关于竞品防御**：...

### 6.2 风险预警雷达
- **技术风险**：...
- **合规风险**：...
- **运营风险**：...

### 6.3 最终考察建议
（给评委的最终建议：重点考察该项目的哪三个方面？例如：1.推理速度 2.生成质量 3.安装便捷性）

---

## 七、 最终结案陈词

### 7.1 定性结论
（用一段话总结：这是一个"值得即刻投资/获奖"的项目，还是一个"需要再观察"的项目？结论要明确。）

### 7.2 核心标签 (Tagging)
（给出3个核心标签，如：#企业级RAG #低代码 #开发者工具）

### 7.3 给开发者的寄语
（专业、鼓励但要求严格的建议）

**报告完**
""",
            parameters=[
                "repo_name", "description", "language", "stars", "repo_url",
                "total_score", "level", "level_stars", "tech_innovation_score", "scenario_innovation_score",
                "dim_table", "radar_analysis", "analyses_text",
                "tech_suggestions", "scenario_suggestions", "product_suggestions", "judge_focus_points"
            ],
            examples=[
                {
                    "name": "AI陪伴聊天机器人",
                    "input": {
                        "repo_name": "Alzheimer-Chatbot",
                        "description": "一个面向阿尔茨海默症患者的AI陪伴聊天机器人",
                        "language": "Python",
                        "stars": 150,
                        "total_score": 72.5,
                        "level": "中等创新",
                        "level_stars": "⭐⭐⭐",
                        "tech_innovation_score": 28.5,
                        "scenario_innovation_score": 44.0,
                        "dim_table": "| 维度 | 得分 | 权重 | 加权得分 | 评价摘要 |\n|------|------|------|----------|----------|\n| 技术选型与实现 | 65 | 13% | 8.5 | 使用了LangChain等现代框架 |\n| 场景创新性 | 80 | 24% | 19.2 | 聚焦阿尔茨海默症患者 |",
                        "radar_analysis": "场景创新性表现突出，技术实现有提升空间",
                        "analyses_text": "### 技术选型与实现\n使用了LangChain等现代框架，技术选型合理...",
                        "tech_suggestions": "- 引入更多前沿AI框架\n- 增加单元测试",
                        "scenario_suggestions": "- 深入调研目标用户需求",
                        "product_suggestions": "- 创建在线Demo",
                        "judge_focus_points": "- 如何理解阿尔茨海默症患者的需求？\n- 与市场同类产品的差异化？"
                    },
                    "expected_output": "# Alzheimer-Chatbot - AI应用创新性评审报告\n\n## 一、项目概览与核心定位\n..."
                }
            ],
            category="report_optimization",
            required_params=[
                "repo_name", "description", "total_score", "tech_innovation_score", "scenario_innovation_score",
                "dim_table", "analyses_text"
            ],
            default_params={
                "language": "Unknown",
                "stars": 0,
                "repo_url": "",
                "level": "未知",
                "level_stars": "",
                "radar_analysis": "无分析",
                "tech_suggestions": "无",
                "scenario_suggestions": "无",
                "product_suggestions": "无",
                "judge_focus_points": "无"
            },
            applicable_scenes=["general", "ai_application", "hackathon", "startup"]
        )
        
        # 2. 维度分析增强模板
        templates["dimension_analyzer"] = PromptTemplate(
            name="dimension_analyzer",
            description="对单个维度进行深度分析，提供详细的现状评估、优缺点分析和改进建议",
            system_prompt="""你是一位专业的技术评估专家，擅长对AI项目的各个维度进行深度分析。

## 分析要求
1. 分析要深入透彻，基于具体事实和数据
2. 每个维度分析必须包含：
   - 现状详细描述（具体技术/特性）
   - 优点分析（2-3个具体优点）
   - 不足分析（1-2个具体不足）
   - 与同类项目对比
   - 具体改进建议
3. 分析要客观公正，评价要基于事实
4. 建议要具体可操作，有明确的实施路径

## 输出风格
- 语言专业严谨，但易于理解
- 结构清晰，逻辑连贯
- 突出重点，避免无关信息
- 使用Markdown格式，增强可读性""",
            user_prompt_template="""# 维度分析任务

## 分析目标
分析项目在**{dimension_name}**维度的表现

## 维度信息
- **维度名称**：{dimension_name}
- **维度得分**：{score:.1f}/100
- **维度权重**：{weight:.0f}%
- **维度类别**：{category}

## 现状分析
{current_status}

## 相关数据
{related_data}

## 分析要求
请按照以下格式输出详细分析：

### 现状分析
（详细描述项目在该维度的具体表现，3-4句话）

### 优点分析
- 优点1：（具体描述）
- 优点2：（具体描述）

### 不足分析
- 不足1：（具体描述）

### 与同类项目对比
（与同类AI应用在该维度的对比分析，2-3句话）

### 改进建议
（具体的改进建议，包含原因分析、具体措施、预期效果）
""",
            parameters=["dimension_name", "score", "weight", "category", "current_status", "related_data"],
            examples=[
                {
                    "name": "技术选型与实现分析",
                    "input": {
                        "dimension_name": "技术选型与实现",
                        "score": 65,
                        "weight": 13,
                        "category": "技术创新力",
                        "current_status": "使用了LangChain等现代框架，技术选型合理，但缺乏前沿AI技术的深度应用",
                        "related_data": "项目使用了Python作为主要语言，依赖了LangChain、OpenAI等库"
                    },
                    "expected_output": "### 现状分析\n项目使用了LangChain等现代框架，技术选型整体合理...\n\n### 优点分析\n- 优点1：使用了LangChain等现代AI框架，提升了开发效率...\n..."
                }
            ],
            category="dimension_analysis",
            required_params=["dimension_name", "score", "current_status"],
            default_params={
                "weight": 10,
                "category": "技术创新力",
                "related_data": "无"
            },
            applicable_scenes=["dimension_analysis", "tech_evaluation", "scenario_evaluation"]
        )
        
        # 3. 改进建议生成模板
        templates["suggestion_generator"] = PromptTemplate(
            name="suggestion_generator",
            description="生成具体、可操作的改进建议，包含原因分析、具体措施、预期效果和优先级",
            system_prompt="""你是一位专业的AI项目顾问，擅长为项目提供具体、可操作的改进建议。

## 建议要求
1. 每条建议必须包含：
   - 清晰的标题
   - 详细的问题描述
   - 具体的改进措施
   - 预期的改进效果
   - 明确的优先级（高/中/低）
2. 建议要基于具体事实和数据，避免空泛建议
3. 建议要具有可操作性，有明确的实施路径
4. 建议要考虑项目的实际情况和资源约束

## 输出风格
- 语言专业严谨，但易于理解
- 结构清晰，逻辑连贯
- 突出重点，避免无关信息
- 使用Markdown格式，增强可读性""",
            user_prompt_template="""# 改进建议生成任务

## 项目信息
- **项目名称**：{repo_name}
- **项目描述**：{description}
- **当前得分**：{total_score:.1f}/100
- **创新等级**：{level}

## 分析维度
**分析维度**：{analysis_dimension}

## 现状分析
{current_status}

## 相关数据
{related_data}

## 生成要求
请生成3条具体的改进建议，每条建议按照以下格式：

### 建议1：（标题）
- **问题**：（详细描述当前存在的问题）
- **措施**：（具体的改进措施，可操作）
- **效果**：（预期的改进效果）
- **优先级**：（高/中/低）

### 建议2：（标题）
...

### 建议3：（标题）
...
""",
            parameters=["repo_name", "description", "total_score", "level", "analysis_dimension", "current_status", "related_data"],
            examples=[
                {
                    "name": "技术加固建议",
                    "input": {
                        "repo_name": "Alzheimer-Chatbot",
                        "description": "一个面向阿尔茨海默症患者的AI陪伴聊天机器人",
                        "total_score": 72.5,
                        "level": "中等创新",
                        "analysis_dimension": "技术加固",
                        "current_status": "技术选型基本合理，但缺乏前沿AI技术的深度应用",
                        "related_data": "使用了LangChain等框架，但未充分利用其高级特性"
                    },
                    "expected_output": "### 建议1：引入前沿AI框架高级特性\n- **问题**：当前仅使用了LangChain的基础功能...\n..."
                }
            ],
            category="suggestion_generation"
        )
        
        # 4. 评委问题生成模板
        templates["judge_question_generator"] = PromptTemplate(
            name="judge_question_generator",
            description="为评委生成深度参考问题，包含追问目的、期望回答和评分参考",
            system_prompt="""你是一位经验丰富的黑客松评委顾问，擅长为评委提供深度参考问题。

## 问题要求
1. 问题要直击项目的核心，能够有效评估项目质量
2. 每个问题必须包含：
   - 清晰的问题内容
   - 明确的追问目的（为什么要问这个问题）
   - 期望的回答内容（希望团队能提供什么信息）
   - 详细的评分参考（好的回答和差的回答分别是什么样的）
3. 问题要覆盖项目的关键维度，避免重复
4. 问题要有层次，从表面到深层，逐步深入

## 输出风格
- 语言专业严谨，但易于理解
- 结构清晰，逻辑连贯
- 突出重点，避免无关信息
- 使用Markdown格式，增强可读性""",
            user_prompt_template="""# 评委问题生成任务

## 项目信息
- **项目名称**：{repo_name}
- **项目描述**：{description}
- **当前得分**：{total_score:.1f}/100
- **创新等级**：{level}

## 项目亮点
{project_highlights}

## 潜在风险
{potential_risks}

## 生成要求
请生成5个深度参考问题，每个问题按照以下格式：

### 问题1：（问题内容）
- **追问目的**：（为什么要问这个问题）
- **期望回答**：（希望团队能提供什么信息）
- **评分参考**：（好的回答和差的回答分别是什么样的）

### 问题2：（问题内容）
...

### 问题3：（问题内容）
...

### 问题4：（问题内容）
...

### 问题5：（问题内容）
...
""",
            parameters=["repo_name", "description", "total_score", "level", "project_highlights", "potential_risks"],
            examples=[
                {
                    "name": "AI陪伴聊天机器人评委问题",
                    "input": {
                        "repo_name": "Alzheimer-Chatbot",
                        "description": "一个面向阿尔茨海默症患者的AI陪伴聊天机器人",
                        "total_score": 72.5,
                        "level": "中等创新",
                        "project_highlights": "场景创新性强，聚焦阿尔茨海默症患者",
                        "potential_risks": "技术实现有提升空间，用户体验待优化"
                    },
                    "expected_output": "### 问题1：项目声称服务于阿尔茨海默症患者，请团队阐述如何深入理解该群体的真实需求？...\n..."
                }
            ],
            category="judge_support"
        )
        
        # 5. 报告质量评估模板
        templates["report_quality_evaluator"] = PromptTemplate(
            name="report_quality_evaluator",
            description="评估生成报告的质量，提供详细的质量评分和改进建议",
            system_prompt="""你是一位专业的报告质量评估专家，擅长评估AI生成的评审报告质量。

## 评估维度
1. **完整性**：报告是否覆盖了所有必要的内容和维度
2. **深度**：分析是否深入透彻，是否有足够的细节和深度
3. **专业性**：报告是否专业严谨，是否基于事实和数据
4. **清晰度**：报告是否结构清晰，逻辑连贯，易于理解
5. **实用性**：报告是否提供了实用的信息和建议，对评委有参考价值

## 评估要求
1. 评估要客观公正，基于报告的实际内容
2. 每个维度的评估必须包含：
   - 具体评分（0-100）
   - 详细的评分理由
   - 具体的改进建议
3. 最终要提供整体评分和综合改进建议

## 输出风格
- 语言专业严谨，但易于理解
- 结构清晰，逻辑连贯
- 突出重点，避免无关信息
- 使用Markdown格式，增强可读性""",
            user_prompt_template="""# 报告质量评估任务

## 评估对象
评估以下AI生成的评审报告质量

## 报告内容
{report_content}

## 评估要求
请按照以下格式输出详细评估：

### 质量评估结果
| 评估维度 | 评分 | 满分 |
|----------|------|------|
| 完整性 | {completeness_score} | 100 |
| 深度 | {depth_score} | 100 |
| 专业性 | {professionalism_score} | 100 |
| 清晰度 | {clarity_score} | 100 |
| 实用性 | {usefulness_score} | 100 |
| **整体评分** | **{overall_score}** | 100 |

### 详细评估

#### 完整性评估
- **评分**：{completeness_score}
- **评分理由**：（详细说明）
- **改进建议**：（具体建议）

#### 深度评估
- **评分**：{depth_score}
- **评分理由**：（详细说明）
- **改进建议**：（具体建议）

#### 专业性评估
- **评分**：{professionalism_score}
- **评分理由**：（详细说明）
- **改进建议**：（具体建议）

#### 清晰度评估
- **评分**：{clarity_score}
- **评分理由**：（详细说明）
- **改进建议**：（具体建议）

#### 实用性评估
- **评分**：{usefulness_score}
- **评分理由**：（详细说明）
- **改进建议**：（具体建议）

### 综合改进建议
（针对报告整体的改进建议，2-3条）
""",
            parameters=["report_content", "completeness_score", "depth_score", "professionalism_score", "clarity_score", "usefulness_score", "overall_score"],
            examples=[
                {
                    "name": "报告质量评估示例",
                    "input": {
                        "report_content": "# Alzheimer-Chatbot - AI应用创新性评审报告\n\n## 一、项目概览与核心定位\n...",
                        "completeness_score": 85,
                        "depth_score": 75,
                        "professionalism_score": 80,
                        "clarity_score": 90,
                        "usefulness_score": 82,
                        "overall_score": 82
                    },
                    "expected_output": "### 质量评估结果\n| 评估维度 | 评分 | 满分 |\n|----------|------|------|\n| 完整性 | 85 | 100 |\n..."
                }
            ],
            category="quality_assessment"
        )
        
        return templates
    
    def get_template(self, template_name: str) -> Optional[PromptTemplate]:
        """获取指定的提示词模板
        
        Args:
            template_name: 模板名称
            
        Returns:
            提示词模板对象，不存在则返回None
        """
        return self.templates.get(template_name)
    
    def list_templates(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出所有可用的提示词模板
        
        Args:
            category: 可选的分类筛选
            
        Returns:
            模板列表，每个模板包含名称、描述和分类
        """
        templates = []
        for name, template in self.templates.items():
            if category is None or template.category == category:
                templates.append({
                    "name": name,
                    "description": template.description,
                    "category": template.category,
                    "version": template.version,
                    "parameters": template.parameters
                })
        return templates
    
    def generate_prompt(self, template_name: str, **kwargs) -> Optional[Dict[str, str]]:
        """根据模板生成提示词
        
        Args:
            template_name: 模板名称
            **kwargs: 模板参数
            
        Returns:
            包含system_prompt和user_prompt的字典，模板不存在则返回None
        """
        template = self.get_template(template_name)
        if not template:
            return None
        
        # 合并默认参数和用户提供的参数
        params = template.default_params.copy()
        params.update(kwargs)
        
        # 验证必需参数
        missing_params = [param for param in template.required_params if param not in params]
        if missing_params:
            raise ValueError(f"缺少必要参数: {', '.join(missing_params)}")
        
        # 生成用户提示词
        try:
            user_prompt = template.user_prompt_template.format(**params)
        except KeyError as e:
            raise ValueError(f"缺少必要参数: {e}")
        
        return {
            "system_prompt": template.system_prompt,
            "user_prompt": user_prompt
        }
    
    def generate_prompt_for_scene(self, scene: str, template_category: str = None, **kwargs) -> Optional[Dict[str, str]]:
        """根据场景生成合适的提示词
        
        Args:
            scene: 场景名称
            template_category: 模板分类，可选
            **kwargs: 模板参数
            
        Returns:
            包含system_prompt和user_prompt的字典，没有合适的模板则返回None
        """
        # 查找适合该场景的模板
        suitable_templates = []
        for name, template in self.templates.items():
            if scene in template.applicable_scenes:
                if template_category is None or template.category == template_category:
                    suitable_templates.append(template)
        
        if not suitable_templates:
            # 如果没有场景特定的模板，查找通用模板
            for name, template in self.templates.items():
                if not template.scene_specific:
                    if template_category is None or template.category == template_category:
                        suitable_templates.append(template)
        
        if not suitable_templates:
            return None
        
        # 选择第一个合适的模板
        template = suitable_templates[0]
        return self.generate_prompt(template.name, **kwargs)
    
    def create_dynamic_template(self, name: str, description: str, system_prompt: str, 
                              user_prompt_template: str, parameters: List[str], 
                              category: str, scene_specific: bool = False, 
                              applicable_scenes: List[str] = None, 
                              default_params: Dict[str, Any] = None, 
                              required_params: List[str] = None) -> PromptTemplate:
        """创建动态提示词模板
        
        Args:
            name: 模板名称
            description: 模板描述
            system_prompt: 系统提示词
            user_prompt_template: 用户提示词模板
            parameters: 参数列表
            category: 模板分类
            scene_specific: 是否为场景特定模板
            applicable_scenes: 适用场景列表
            default_params: 默认参数
            required_params: 必需参数
            
        Returns:
            创建的提示词模板对象
        """
        template = PromptTemplate(
            name=name,
            description=description,
            system_prompt=system_prompt,
            user_prompt_template=user_prompt_template,
            parameters=parameters,
            examples=[],
            category=category,
            scene_specific=scene_specific,
            applicable_scenes=applicable_scenes or [],
            default_params=default_params or {},
            required_params=required_params or []
        )
        
        # 将模板添加到库中
        self.templates[name] = template
        return template
    
    def validate_template_params(self, template_name: str, **kwargs) -> Dict[str, Any]:
        """验证模板参数
        
        Args:
            template_name: 模板名称
            **kwargs: 模板参数
            
        Returns:
            验证后的参数字典
        """
        template = self.get_template(template_name)
        if not template:
            raise ValueError(f"模板不存在: {template_name}")
        
        # 合并默认参数和用户提供的参数
        params = template.default_params.copy()
        params.update(kwargs)
        
        # 验证必需参数
        missing_params = [param for param in template.required_params if param not in params]
        if missing_params:
            raise ValueError(f"缺少必要参数: {', '.join(missing_params)}")
        
        return params
    
    def get_best_practices(self) -> Dict[str, Any]:
        """获取提示词工程最佳实践
        
        Returns:
            最佳实践字典，包含各种提示词工程技巧和建议
        """
        return {
            "prompt_structure": {
                "system_prompt": "设置AI的角色和任务，提供背景信息和约束",
                "user_prompt": "提供具体的任务描述和输入数据",
                "format_instructions": "明确指定输出格式和结构",
                "examples": "提供示例输入和输出，引导AI理解任务"
            },
            "prompt_engineering_techniques": [
                "具体明确：提供详细的任务描述和要求",
                "结构化：使用清晰的结构和格式，增强可读性",
                "示例引导：提供高质量的示例，引导AI理解任务",
                "约束条件：明确设定边界和限制，避免无关输出",
                "迭代优化：基于反馈不断调整和优化提示词",
                "参数调整：根据任务类型调整temperature等参数"
            ],
            "deepseek_specific_tips": [
                "适当增加提示词长度，Deepseek模型擅长处理长上下文",
                "使用详细的系统提示词，明确设定AI的角色和任务",
                "提供具体的格式要求，确保输出符合预期格式",
                "使用Markdown格式，增强输出的可读性",
                "对于复杂任务，分步骤引导，逐步完成任务",
                "调整temperature参数，平衡创造力和准确性"
            ],
            "common_mistakes": [
                "提示词过于简洁，缺乏具体要求",
                "格式要求不明确，导致输出格式混乱",
                "缺乏示例，AI难以理解预期输出",
                "约束条件不明确，导致输出偏离主题",
                "任务过于复杂，一次性要求过多",
                "参数设置不当，影响输出质量"
            ]
        }
    
    def optimize_prompt(self, prompt: str, task_type: str) -> str:
        """优化提示词，提高Deepseek模型的理解和执行效果
        
        Args:
            prompt: 原始提示词
            task_type: 任务类型
            
        Returns:
            优化后的提示词
        """
        # 基于任务类型的优化
        if task_type == "report_generation":
            # 报告生成任务优化
            optimizations = [
                "请生成一份详细、专业的报告，总字数不少于4000字",
                "每个章节都要有实质内容，禁止空泛描述",
                "使用Markdown格式，善用表格、列表增强可读性",
                "分析要深入透彻，基于具体事实和数据",
                "建议要具体可操作，有明确的实施路径"
            ]
        elif task_type == "dimension_analysis":
            # 维度分析任务优化
            optimizations = [
                "分析要深入透彻，基于具体事实和数据",
                "每个维度分析必须包含现状、优点、不足和改进建议",
                "建议要具体可操作，有明确的实施路径",
                "使用Markdown格式，增强可读性"
            ]
        elif task_type == "suggestion_generation":
            # 建议生成任务优化
            optimizations = [
                "建议要具体可操作，有明确的实施路径",
                "每条建议必须包含问题、措施、效果和优先级",
                "建议要基于具体事实和数据，避免空泛建议",
                "使用Markdown格式，增强可读性"
            ]
        elif task_type == "judge_question":
            # 评委问题生成任务优化
            optimizations = [
                "问题要直击项目的核心，能够有效评估项目质量",
                "每个问题必须包含追问目的、期望回答和评分参考",
                "问题要覆盖项目的关键维度，避免重复",
                "使用Markdown格式，增强可读性"
            ]
        else:
            # 默认优化
            optimizations = [
                "请基于具体事实和数据提供详细分析",
                "使用Markdown格式，增强可读性",
                "分析要深入透彻，建议要具体可操作"
            ]
        
        # 添加优化内容
        optimized_prompt = prompt
        for optimization in optimizations:
            if optimization not in optimized_prompt:
                optimized_prompt += f"\n\n{optimization}"
        
        return optimized_prompt
    
    def evaluate_prompt_performance(self, prompt: str, task_type: str, model_response: str) -> Dict[str, Any]:
        """评估提示词性能
        
        Args:
            prompt: 提示词
            task_type: 任务类型
            model_response: 模型响应
            
        Returns:
            性能评估结果
        """
        # 评估维度
        evaluation_dimensions = {
            "relevance": "相关性",
            "completeness": "完整性",
            "depth": "深度",
            "clarity": "清晰度",
            "usefulness": "实用性",
            "conciseness": "简洁性"
        }
        
        # 简单的性能评估逻辑
        # 实际应用中，可能需要使用更复杂的评估方法，如人工评估或使用其他模型进行评估
        performance_scores = {
            "relevance": 85,  # 假设相关性得分
            "completeness": 80,  # 假设完整性得分
            "depth": 75,  # 假设深度得分
            "clarity": 90,  # 假设清晰度得分
            "usefulness": 85,  # 假设实用性得分
            "conciseness": 70  # 假设简洁性得分
        }
        
        # 计算总体得分
        overall_score = sum(performance_scores.values()) / len(performance_scores)
        
        # 生成优化建议
        optimization_suggestions = self._generate_optimization_suggestions(
            prompt, task_type, performance_scores
        )
        
        return {
            "prompt": prompt,
            "task_type": task_type,
            "model_response": model_response,
            "performance_scores": performance_scores,
            "overall_score": overall_score,
            "optimization_suggestions": optimization_suggestions
        }
    
    def _generate_optimization_suggestions(self, prompt: str, task_type: str, performance_scores: Dict[str, int]) -> List[str]:
        """生成提示词优化建议
        
        Args:
            prompt: 提示词
            task_type: 任务类型
            performance_scores: 性能得分
            
        Returns:
            优化建议列表
        """
        suggestions = []
        
        # 基于性能得分生成优化建议
        if performance_scores.get("relevance", 0) < 80:
            suggestions.append("提高提示词的相关性：确保提示词与任务类型高度相关，包含具体的任务描述和要求")
        
        if performance_scores.get("completeness", 0) < 80:
            suggestions.append("提高提示词的完整性：确保提示词包含所有必要的信息和要求，避免遗漏重要内容")
        
        if performance_scores.get("depth", 0) < 80:
            suggestions.append("提高提示词的深度：提供更详细的背景信息和具体要求，引导模型生成更深入的内容")
        
        if performance_scores.get("clarity", 0) < 80:
            suggestions.append("提高提示词的清晰度：使用清晰、简洁的语言，避免歧义，明确表达要求")
        
        if performance_scores.get("usefulness", 0) < 80:
            suggestions.append("提高提示词的实用性：确保提示词能够引导模型生成实用、有价值的内容")
        
        if performance_scores.get("conciseness", 0) < 80:
            suggestions.append("提高提示词的简洁性：在保持完整性的同时，尽量简洁明了，避免冗余信息")
        
        # 基于任务类型的特定建议
        if task_type == "report_generation":
            suggestions.append("对于报告生成任务，建议提供更详细的报告结构和内容要求，引导模型生成更有条理的报告")
        elif task_type == "dimension_analysis":
            suggestions.append("对于维度分析任务，建议明确分析的具体维度和要求，引导模型生成更全面的分析")
        elif task_type == "suggestion_generation":
            suggestions.append("对于建议生成任务，建议明确建议的具体要求和格式，引导模型生成更具体、可操作的建议")
        elif task_type == "judge_question":
            suggestions.append("对于评委问题生成任务，建议明确问题的类型和要求，引导模型生成更有针对性的问题")
        
        return suggestions
    
    def compare_prompt_performance(self, prompts: List[str], task_type: str, model_responses: List[str]) -> Dict[str, Any]:
        """比较多个提示词的性能
        
        Args:
            prompts: 提示词列表
            task_type: 任务类型
            model_responses: 模型响应列表
            
        Returns:
            性能比较结果
        """
        if len(prompts) != len(model_responses):
            raise ValueError("提示词数量和模型响应数量必须相同")
        
        performance_results = []
        for i, (prompt, response) in enumerate(zip(prompts, model_responses)):
            result = self.evaluate_prompt_performance(prompt, task_type, response)
            performance_results.append({
                "prompt_id": i + 1,
                "prompt": prompt,
                "overall_score": result["overall_score"],
                "performance_scores": result["performance_scores"],
                "optimization_suggestions": result["optimization_suggestions"]
            })
        
        # 按总体得分排序
        performance_results.sort(key=lambda x: x["overall_score"], reverse=True)
        
        return {
            "task_type": task_type,
            "performance_results": performance_results,
            "best_prompt": performance_results[0] if performance_results else None
        }
    
    def auto_optimize_prompt(self, prompt: str, task_type: str, iterations: int = 3) -> Dict[str, Any]:
        """自动优化提示词
        
        Args:
            prompt: 原始提示词
            task_type: 任务类型
            iterations: 优化迭代次数
            
        Returns:
            优化结果
        """
        optimized_prompts = [prompt]
        performance_results = []
        
        for i in range(iterations):
            # 优化提示词
            current_prompt = optimized_prompts[-1]
            optimized_prompt = self.optimize_prompt(current_prompt, task_type)
            optimized_prompts.append(optimized_prompt)
            
            # 模拟模型响应
            # 实际应用中，这里应该调用模型获取真实响应
            mock_response = f"这是针对{task_type}任务的模拟响应，基于优化后的提示词"
            
            # 评估性能
            result = self.evaluate_prompt_performance(optimized_prompt, task_type, mock_response)
            performance_results.append(result)
        
        # 找到最佳优化结果
        best_result = max(performance_results, key=lambda x: x["overall_score"])
        
        return {
            "original_prompt": prompt,
            "optimized_prompts": optimized_prompts,
            "performance_results": performance_results,
            "best_result": best_result
        }


# 全局提示词工程库实例
prompt_library = PromptEngineeringLibrary()


def get_prompt_library() -> PromptEngineeringLibrary:
    """获取提示词工程库实例"""
    return prompt_library


def generate_prompt(template_name: str, **kwargs) -> Optional[Dict[str, str]]:
    """根据模板生成提示词的便捷函数"""
    return prompt_library.generate_prompt(template_name, **kwargs)


def list_templates(category: Optional[str] = None) -> List[Dict[str, Any]]:
    """列出所有可用的提示词模板的便捷函数"""
    return prompt_library.list_templates(category)


def get_best_practices() -> Dict[str, Any]:
    """获取提示词工程最佳实践的便捷函数"""
    return prompt_library.get_best_practices()


def optimize_prompt(prompt: str, task_type: str) -> str:
    """优化提示词的便捷函数"""
    return prompt_library.optimize_prompt(prompt, task_type)
