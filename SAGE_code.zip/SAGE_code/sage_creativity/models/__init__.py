"""模型相关模块"""
from .similarity import SimilarityCalculator

__all__ = ["SimilarityCalculator"]
