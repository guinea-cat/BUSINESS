"""SAGE统一评估系统 - Gradio界面（整合版 v4.0）

功能：
- 创新性评估：6维度权重配置（技术创新力40% + 场景创新力60%）
- 社会价值评估：7维度权重配置（基础项30% + 加分项70%）
- 支持单独评估或同时评估两种维度
- 评估按钮+进度显示
- 人性化Markdown报告展示
"""
import gradio as gr
from pathlib import Path
import sys
import traceback
import logging

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

from config import INNOVATION_WEIGHTS, SOCIAL_VALUE_WEIGHTS
from core.innovation_scorer import InnovationScorer
from core.social_value_scorer import SocialValueScorer


# 全局评分器实例
innovation_scorer = None
social_value_scorer = None

def get_innovation_scorer(use_deepseek: bool = True):
    """获取或创建创新性评分器实例"""
    global innovation_scorer
    try:
        if innovation_scorer is None:
            logger.info("创建创新性评分器实例...")
            innovation_scorer = InnovationScorer(use_modelscope=False, use_deepseek=use_deepseek)
            logger.info("创新性评分器创建成功")
        return innovation_scorer
    except Exception as e:
        logger.error(f"创建创新性评分器失败: {str(e)}")
        logger.error(traceback.format_exc())
        raise

def get_social_value_scorer(use_deepseek: bool = True):
    """获取或创建社会价值评分器实例"""
    global social_value_scorer
    try:
        if social_value_scorer is None:
            logger.info("创建社会价值评分器实例...")
            # SocialValueScorer 不接受 use_modelscope 参数
            social_value_scorer = SocialValueScorer(use_deepseek=use_deepseek)
            logger.info("社会价值评分器创建成功")
        return social_value_scorer
    except Exception as e:
        logger.error(f"创建社会价值评分器失败: {str(e)}")
        logger.error(traceback.format_exc())
        raise


def analyze_repo(url: str, 
                 demo_url: str,
                 blog_url: str,
                 paper_url: str,
                 eval_type: str,  # "innovation", "social_value", "both"
                 # 创新性权重
                 weight_tech_impl: float,
                 weight_arch_design: float,
                 weight_eng_sustain: float,
                 weight_problem_value: float,
                 weight_scenario_innov: float,
                 weight_market_fit: float,
                 # 社会价值权重
                 weight_ethics_redline: float,
                 weight_privacy: float,
                 weight_fairness: float,
                 weight_social_impact: float,
                 weight_environmental: float,
                 weight_charity: float,
                 weight_long_term: float,
                 use_deepseek: bool,
                 progress=gr.Progress()):
    """
    分析仓库（整合版：支持创新性和/或社会价值评估）
    
    Args:
        url: GitHub仓库URL
        demo_url: Demo/官网链接
        blog_url: 技术博客链接
        paper_url: 论文链接
        eval_type: 评估类型 ("innovation", "social_value", "both")
        创新性权重参数...
        社会价值权重参数...
        use_deepseek: 是否使用DeepSeek优化
        progress: Gradio进度对象
        
    Returns:
        (总分文本, 等级文本, 一句话结论, Markdown报告)
    """
    # 验证URL
    if not url or not url.strip():
        return "❌ 请输入GitHub仓库URL", "", "", ""
    
    url = url.strip()
    if "github.com" not in url.lower():
        return "❌ 请输入有效的GitHub仓库URL", "", "", ""
    
    # 进度回调
    def progress_callback(prog, message):
        try:
            progress(prog, desc=message)
        except Exception as e:
            logger.warning(f"进度回调失败: {str(e)}")
    
    try:
        logger.info(f"开始评估仓库: {url}, 评估类型: {eval_type}")
        md_report = ""
        score_text = ""
        level_text = ""
        summary_text = ""
        
        # 执行创新性评估
        if eval_type in ["innovation", "both"]:
            logger.info("执行创新性评估...")
            innovation_weights = {
                "tech_implementation": weight_tech_impl,
                "architecture_design": weight_arch_design,
                "engineering_sustainability": weight_eng_sustain,
                "problem_value": weight_problem_value,
                "scenario_innovation": weight_scenario_innov,
                "market_fit": weight_market_fit,
            }
            
            try:
                logger.info("初始化创新性评分器...")
                innovation_scorer = get_innovation_scorer(use_deepseek=use_deepseek)
                logger.info("开始分析仓库...")
                innovation_report = innovation_scorer.analyze(url, weights=innovation_weights, progress_callback=progress_callback)
                logger.info("生成Markdown报告...")
                innovation_md = innovation_scorer.generate_markdown_report(innovation_report, use_llm=use_deepseek)
                logger.info("创新性评估完成")
            except Exception as e:
                logger.error(f"创新性评估失败: {str(e)}")
                logger.error(traceback.format_exc())
                raise
            
            if eval_type == "both":
                md_report += "# 🔬 创新性评估报告\n\n"
                score_text += f"**创新性: {innovation_report.total_score:.1f}** / 100  "
                level_text += f"{innovation_report.level} {innovation_report.level_stars}  "
                summary_text += f"{innovation_report.core_value_summary or ''}  "
            else:
                score_text = f"**{innovation_report.total_score:.1f}** / 100"
                level_text = f"{innovation_report.level} {innovation_report.level_stars}"
                summary_text = innovation_report.core_value_summary or ""
            
            md_report += innovation_md
        
        # 执行社会价值评估
        if eval_type in ["social_value", "both"]:
            logger.info("执行社会价值评估...")
            social_weights = {
                "ethics_redline": weight_ethics_redline,
                "privacy_protection": weight_privacy,
                "algorithm_fairness": weight_fairness,
                "social_impact": weight_social_impact,
                "environmental_friendliness": weight_environmental,
                "charity_orientation": weight_charity,
                "long_term_vision": weight_long_term,
            }
            
            try:
                logger.info("初始化社会价值评分器...")
                social_scorer = get_social_value_scorer(use_deepseek=use_deepseek)
                logger.info("开始分析仓库...")
                social_report = social_scorer.analyze(url, weights=social_weights, progress_callback=progress_callback)
                logger.info("生成Markdown报告...")
                social_md = social_scorer.generate_markdown_report(social_report, use_llm=use_deepseek)
                logger.info("社会价值评估完成")
            except Exception as e:
                logger.error(f"社会价值评估失败: {str(e)}")
                logger.error(traceback.format_exc())
                raise
            
            if eval_type == "both":
                md_report += "\n\n---\n\n# 🌍 社会价值评估报告\n\n"
                score_text += f"**社会价值: {social_report.total_score:.1f}** / 100"
                level_text += f" | {social_report.level} {social_report.level_stars}"
                if social_report.core_value_summary:
                    summary_text += f" | {social_report.core_value_summary}"
            else:
                score_text = f"**{social_report.total_score:.1f}** / 100"
                level_text = f"{social_report.level} {social_report.level_stars}"
                summary_text = social_report.core_value_summary or ""
            
            md_report += social_md
        
        # 添加补充链接到报告末尾
        supplementary_links = []
        if demo_url and demo_url.strip():
            supplementary_links.append(f"- [Demo/官网]({demo_url.strip()})")
        if blog_url and blog_url.strip():
            supplementary_links.append(f"- [技术博客/设计文档]({blog_url.strip()})")
        if paper_url and paper_url.strip():
            supplementary_links.append(f"- [相关论文]({paper_url.strip()})")
        
        if supplementary_links:
            md_report += "\n\n### 团队提供的补充资料\n\n"
            md_report += "\n".join(supplementary_links)
        
        logger.info("评估完成")
        return score_text, level_text, summary_text, md_report
        
    except ValueError as e:
        error_msg = f"❌ URL解析错误: {str(e)}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        return error_msg, "", "", f"## 错误详情\n\n```\n{str(e)}\n{traceback.format_exc()}\n```"
    except ImportError as e:
        error_msg = f"❌ 模块导入错误: {str(e)}\n\n请检查依赖是否已安装：\npip install -r requirements.txt"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        return error_msg, "", "", f"## 错误详情\n\n```\n{str(e)}\n{traceback.format_exc()}\n```\n\n**解决方案**: 请运行 `pip install -r requirements.txt` 安装依赖"
    except Exception as e:
        error_msg = f"❌ 分析失败: {str(e)}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        # 返回详细的错误信息
        error_details = f"## 错误详情\n\n**错误类型**: {type(e).__name__}\n\n**错误信息**: {str(e)}\n\n**详细堆栈**:\n```\n{traceback.format_exc()}\n```"
        return error_msg, "", "", error_details


def reset_innovation_weights():
    """重置创新性权重为默认值"""
    return (
        INNOVATION_WEIGHTS["tech_implementation"],
        INNOVATION_WEIGHTS["architecture_design"],
        INNOVATION_WEIGHTS["engineering_sustainability"],
        INNOVATION_WEIGHTS["problem_value"],
        INNOVATION_WEIGHTS["scenario_innovation"],
        INNOVATION_WEIGHTS["market_fit"],
    )

def reset_social_value_weights():
    """重置社会价值权重为默认值"""
    return (
        SOCIAL_VALUE_WEIGHTS["ethics_redline"],
        SOCIAL_VALUE_WEIGHTS["privacy_protection"],
        SOCIAL_VALUE_WEIGHTS["algorithm_fairness"],
        SOCIAL_VALUE_WEIGHTS["social_impact"],
        SOCIAL_VALUE_WEIGHTS["environmental_friendliness"],
        SOCIAL_VALUE_WEIGHTS["charity_orientation"],
        SOCIAL_VALUE_WEIGHTS["long_term_vision"],
    )


# 创建Gradio界面
def create_app():
    """创建Gradio应用"""
    
    custom_css = """
    .score-display {
        font-size: 2.5em !important;
        text-align: center;
        padding: 20px;
    }
    .level-display {
        font-size: 1.5em !important;
        text-align: center;
        color: #2563eb;
    }
    .summary-display {
        font-size: 1em !important;
        text-align: center;
        color: #4b5563;
        font-style: italic;
        padding: 10px;
        background: #f3f4f6;
        border-radius: 8px;
        margin-top: 10px;
    }
    """
    
    with gr.Blocks(title="SAGE统一评估系统") as app:
        
        # 标题
        gr.Markdown("""
        # 🎯 SAGE统一评估系统（整合版 v4.0）
        
        为AI黑客松评委提供自动化的项目评估工具，支持**创新性**和**社会价值**两个维度的评估：
        
        - **🔬 创新性评估（6维度）**：技术创新力（40%）+ 场景创新力（60%）
        - **🌍 社会价值评估（7维度）**：基础项（30%）+ 加分项（70%）
        """)
        
        with gr.Row():
            # 左侧：输入区域
            with gr.Column(scale=1):
                # URL输入
                url_input = gr.Textbox(
                    label="GitHub仓库URL",
                    placeholder="https://github.com/owner/repo",
                    info="输入公开的GitHub仓库地址",
                )
                
                # 评估类型选择
                eval_type = gr.Radio(
                    choices=[
                        ("仅创新性评估", "innovation"),
                        ("仅社会价值评估", "social_value"),
                        ("同时评估两者", "both")
                    ],
                    value="innovation",
                    label="评估类型",
                    info="选择要执行的评估类型"
                )
                
                # 补充信息（可折叠）
                with gr.Accordion("📎 补充信息（可选）", open=False):
                    gr.Markdown("*提供额外链接可以丰富评估报告*")
                    
                    demo_url = gr.Textbox(
                        label="Demo/官网链接",
                        placeholder="https://example.com/demo",
                        info="在线演示或产品官网",
                    )
                    blog_url = gr.Textbox(
                        label="技术博客/设计文档",
                        placeholder="https://blog.example.com/tech-design",
                        info="详细的技术说明文档",
                    )
                    paper_url = gr.Textbox(
                        label="相关论文链接",
                        placeholder="https://arxiv.org/abs/xxxx.xxxxx",
                        info="arXiv或其他学术论文",
                    )
                
                # 创新性权重配置（可折叠）
                with gr.Accordion("⚙️ 创新性权重配置", open=False):
                    gr.Markdown("""
                    调整各维度在总分中的权重占比（总和自动归一化为100%）
                    
                    **技术创新力（默认40%）**：技术选型13% + 架构设计13% + 工程化14%
                    
                    **场景创新力（默认60%）**：问题价值18% + 场景创新24% + 市场契合18%
                    """)
                    
                    gr.Markdown("##### 技术创新力维度")
                    weight_tech_impl = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["tech_implementation"],
                        step=1, label="技术选型与实现",
                        info="评估使用的技术框架和库的前沿程度、代码实现质量"
                    )
                    weight_arch_design = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["architecture_design"],
                        step=1, label="系统架构与设计",
                        info="评估项目代码结构、设计模式和模块化程度"
                    )
                    weight_eng_sustain = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["engineering_sustainability"],
                        step=1, label="工程化与可持续性",
                        info="评估CI/CD、容器化、测试等工程实践"
                    )
                    
                    gr.Markdown("##### 场景创新力维度")
                    weight_problem_value = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["problem_value"],
                        step=1, label="问题定义与价值",
                        info="评估问题定义清晰度和解决方案的价值主张"
                    )
                    weight_scenario_innov = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["scenario_innovation"],
                        step=1, label="场景创新性 ⭐",
                        info="【重点】评估应用场景的新颖性、是否服务特定人群（如阿尔茨海默症患者）"
                    )
                    weight_market_fit = gr.Slider(
                        minimum=0, maximum=100, value=INNOVATION_WEIGHTS["market_fit"],
                        step=1, label="市场与生态契合度",
                        info="评估与技术趋势的契合度、社区认可度和生态集成能力"
                    )
                    
                    reset_innovation_btn = gr.Button("🔄 重置创新性权重", size="sm")
                
                # 社会价值权重配置（可折叠）
                with gr.Accordion("⚙️ 社会价值权重配置", open=False):
                    gr.Markdown("""
                    调整各维度在总分中的权重占比（总和自动归一化为100%）
                    
                    **基础项（默认30%）**：伦理红线10% + 隐私保护10% + 算法公平10%
                    
                    **加分项（默认70%）**：社会影响25% + 环境友好15% + 公益导向15% + 长期愿景15%
                    """)
                    
                    gr.Markdown("##### 基础项（伦理安全合规性）")
                    weight_ethics_redline = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["ethics_redline"],
                        step=1, label="伦理红线检查",
                        info="评估是否违反AI伦理基本原则"
                    )
                    weight_privacy = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["privacy_protection"],
                        step=1, label="隐私与数据保护",
                        info="评估数据隐私保护措施和合规性"
                    )
                    weight_fairness = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["algorithm_fairness"],
                        step=1, label="算法公平性意识",
                        info="评估算法设计中的公平性考虑"
                    )
                    
                    gr.Markdown("##### 加分项（价值亮点）")
                    weight_social_impact = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["social_impact"],
                        step=1, label="社会影响深度",
                        info="评估对社会的积极影响和改变"
                    )
                    weight_environmental = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["environmental_friendliness"],
                        step=1, label="环境可持续性",
                        info="评估对环境的影响和可持续性"
                    )
                    weight_charity = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["charity_orientation"],
                        step=1, label="公益普惠导向",
                        info="评估公益性和普惠性"
                    )
                    weight_long_term = gr.Slider(
                        minimum=0, maximum=100, value=SOCIAL_VALUE_WEIGHTS["long_term_vision"],
                        step=1, label="长期愿景与变革潜力",
                        info="评估长期愿景和社会变革潜力"
                    )
                    
                    reset_social_btn = gr.Button("🔄 重置社会价值权重", size="sm")
                
                # DeepSeek优化开关
                with gr.Accordion("🤖 AI报告优化", open=True):
                    use_deepseek = gr.Checkbox(
                        label="启用DeepSeek模型优化报告",
                        value=True,
                        info="使用DeepSeek-R1模型生成更人性化的评审报告（需要本地vLLM服务）"
                    )
                
                # 分析按钮
                analyze_btn = gr.Button("🚀 开始评估", variant="primary", size="lg")
                
                # 分数显示
                with gr.Group():
                    gr.Markdown("### 📊 评估结果")
                    score_output = gr.Markdown(
                        value="等待评估...",
                        elem_classes=["score-display"]
                    )
                    level_output = gr.Markdown(
                        value="",
                        elem_classes=["level-display"]
                    )
                    # 评委一句话结论
                    summary_output = gr.Markdown(
                        value="",
                        elem_classes=["summary-display"]
                    )
            
            # 右侧：报告区域
            with gr.Column(scale=2):
                gr.Markdown("### 📝 详细报告")
                report_output = gr.Markdown(
                    value="输入GitHub仓库URL并点击「开始评估」查看详细分析报告。",
                )
        
        # 示例URL
        gr.Markdown("""
        ---
        ### 💡 示例仓库（点击填充）
        """)
        examples = gr.Examples(
            examples=[
                ["https://github.com/langchain-ai/langchain"],
                ["https://github.com/openai/openai-python"],
                ["https://github.com/microsoft/autogen"],
                ["https://github.com/run-llama/llama_index"],
            ],
            inputs=[url_input],
            label="热门AI项目",
            cache_examples=False,
        )
        
        # 使用说明
        with gr.Accordion("📖 使用说明", open=False):
            gr.Markdown("""
            ### 创新性评估维度说明（6维度框架）
            
            #### 技术创新力（默认权重40%）
            | 维度 | 权重 | 评分依据 |
            |------|------|----------|
            | 技术选型与实现 | 13% | 使用vLLM、LangChain等前沿库得分高；代码质量、实现规范性 |
            | 系统架构与设计 | 13% | 自定义架构模式得分高，清晰的模块化设计，低耦合高内聚 |
            | 工程化与可持续性 | 14% | CI/CD、Docker、测试覆盖等工程实践完善度 |
            
            #### 场景创新力（默认权重60%）
            | 维度 | 权重 | 评分依据 |
            |------|------|----------|
            | 问题定义与价值 | 18% | 问题定义清晰度、目标用户明确性、价值主张独特性 |
            | **场景创新性** | **24%** | 应用场景新颖性、是否服务特定人群（如阿尔茨海默症患者、残障人士）、跨领域融合 |
            | 市场与生态契合度 | 18% | 技术趋势契合度、社区认可度（Star数）、生态集成能力 |
            
            ### 社会价值评估维度说明（7维度框架）
            
            #### 基础项（默认权重30%）
            | 维度 | 权重 | 评分依据 |
            |------|------|----------|
            | 伦理红线检查 | 10% | 是否违反AI伦理基本原则，是否存在安全隐患 |
            | 隐私与数据保护 | 10% | 数据隐私保护措施、合规性、数据安全 |
            | 算法公平性意识 | 10% | 算法设计中的公平性考虑、避免歧视 |
            
            #### 加分项（默认权重70%）
            | 维度 | 权重 | 评分依据 |
            |------|------|----------|
            | 社会影响深度 | 25% | 对社会的积极影响、改变程度、受益人群 |
            | 环境可持续性 | 15% | 对环境的影响、资源消耗、可持续性 |
            | 公益普惠导向 | 15% | 公益性、普惠性、是否服务弱势群体 |
            | 长期愿景与变革潜力 | 15% | 长期愿景、社会变革潜力、影响力 |
            
            ### 评估等级
            
            #### 创新等级
            | 分数范围 | 等级 | 说明 |
            |---------|------|------|
            | 90-100 | 突破性创新 ⭐⭐⭐⭐⭐ | 在多个维度展现出卓越的创新性 |
            | 75-89 | 显著创新 ⭐⭐⭐⭐ | 有明确的创新点和技术亮点 |
            | 60-74 | 中等创新 ⭐⭐⭐ | 有一定创新，但仍有提升空间 |
            | 40-59 | 渐进改进 ⭐⭐ | 基于现有方案的小幅改进 |
            | <40 | 常规实现 ⭐ | 标准实现，创新性较低 |
            
            #### 社会价值等级
            | 分数范围 | 等级 | 说明 |
            |---------|------|------|
            | 90-100 | 卓越社会价值 ⭐⭐⭐⭐⭐ | 在多个维度展现出卓越的社会价值 |
            | 75-89 | 显著社会价值 ⭐⭐⭐⭐ | 有明确的社会价值亮点 |
            | 60-74 | 良好社会价值 ⭐⭐⭐ | 有一定社会价值，但仍有提升空间 |
            | 40-59 | 一般社会价值 ⭐⭐ | 社会价值有限 |
            | <40 | 社会价值有限 ⭐ | 社会价值较低 |
            
            ### 注意事项
            
            - 本工具仅供参考，评估结果应结合人工判断使用
            - **场景创新性**是创新性评估的重点维度，聚焦于应用的实际价值和社会影响
            - **社会影响深度**是社会价值评估的重点维度，关注对社会的积极影响
            - 支持公开的GitHub仓库，私有仓库需提供访问Token
            - 评估时间取决于仓库大小，通常需要30秒-2分钟
            - 同时评估两种维度时，会生成两份独立的报告
            """)
        
        # 事件绑定
        analyze_btn.click(
            fn=analyze_repo,
            inputs=[url_input, demo_url, blog_url, paper_url, eval_type,
                    weight_tech_impl, weight_arch_design, weight_eng_sustain,
                    weight_problem_value, weight_scenario_innov, weight_market_fit,
                    weight_ethics_redline, weight_privacy, weight_fairness,
                    weight_social_impact, weight_environmental, weight_charity, weight_long_term,
                    use_deepseek],
            outputs=[score_output, level_output, summary_output, report_output],
            show_progress="full",
        )
        
        reset_innovation_btn.click(
            fn=reset_innovation_weights,
            outputs=[weight_tech_impl, weight_arch_design, weight_eng_sustain,
                     weight_problem_value, weight_scenario_innov, weight_market_fit],
        )
        
        reset_social_btn.click(
            fn=reset_social_value_weights,
            outputs=[weight_ethics_redline, weight_privacy, weight_fairness,
                     weight_social_impact, weight_environmental, weight_charity, weight_long_term],
        )
        
        # 回车触发分析
        url_input.submit(
            fn=analyze_repo,
            inputs=[url_input, demo_url, blog_url, paper_url, eval_type,
                    weight_tech_impl, weight_arch_design, weight_eng_sustain,
                    weight_problem_value, weight_scenario_innov, weight_market_fit,
                    weight_ethics_redline, weight_privacy, weight_fairness,
                    weight_social_impact, weight_environmental, weight_charity, weight_long_term,
                    use_deepseek],
            outputs=[score_output, level_output, summary_output, report_output],
            show_progress="full",
        )
    
    return app, custom_css


# 主入口
if __name__ == "__main__":
    app, css = create_app()
    app.launch(
        server_name="0.0.0.0",
        server_port=7862,
        share=False,
        show_error=True,
        enable_queue=True,  # 启用队列以支持进度跟踪
    )
